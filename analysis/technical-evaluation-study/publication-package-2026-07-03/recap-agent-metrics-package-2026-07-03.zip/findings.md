# Technical Evaluation Findings

Generated from immutable evaluation artifacts. This dossier reports technical behavior only; it does not include user testing or baseline comparison.

## Reproducibility

- Manifest: technical-evaluation-50-v4
- Transition registry: decision-flow-v1-2026-07-01
- Raw summary: [summary.json](summary.json)
- Conversation table: [conversations.csv](conversations.csv)
- Grounding audit population: [grounding.csv](grounding.csv)

## Findings

```json
{
  "studyId": "technical-study-2026-07-03T00-36-35-880Z",
  "dryRun": false,
  "manifestId": "technical-evaluation-50-v4",
  "manifestVersion": 4,
  "frozenAt": "2026-07-02T09:55:00-05:00",
  "repetitions": 3,
  "distinctScenarios": 50,
  "executedConversations": 150,
  "completed": 133,
  "completionRate": 0.8866666666666667,
  "completionWilson95": {
    "lower": 0.825997250162395,
    "upper": 0.928025760859626
  },
  "outcomes": {
    "completed": 133,
    "failed_assertion": 17
  },
  "eventGroups": {
    "wedding": 30,
    "birthday": 30,
    "baby_shower": 30,
    "corporate": 30,
    "social": 30
  },
  "routeFamilies": {
    "recommendation": 15,
    "clarification": 15,
    "multi_need": 15,
    "refinement": 15,
    "selection": 15,
    "pause_resume": 15,
    "closure": 15,
    "faq": 15,
    "no_results": 15,
    "error_recovery": 15
  },
  "outcomesByEventGroup": {
    "wedding": {
      "completed": 28,
      "failed_assertion": 2
    },
    "birthday": {
      "completed": 25,
      "failed_assertion": 5
    },
    "baby_shower": {
      "completed": 27,
      "failed_assertion": 3
    },
    "corporate": {
      "completed": 26,
      "failed_assertion": 4
    },
    "social": {
      "completed": 27,
      "failed_assertion": 3
    }
  },
  "outcomesByRouteFamily": {
    "recommendation": {
      "completed": 15
    },
    "clarification": {
      "completed": 15
    },
    "multi_need": {
      "completed": 15
    },
    "refinement": {
      "completed": 15
    },
    "selection": {
      "completed": 14,
      "failed_assertion": 1
    },
    "pause_resume": {
      "completed": 3,
      "failed_assertion": 12
    },
    "closure": {
      "completed": 15
    },
    "faq": {
      "completed": 15
    },
    "no_results": {
      "failed_assertion": 1,
      "completed": 14
    },
    "error_recovery": {
      "completed": 12,
      "failed_assertion": 3
    }
  },
  "expectationPassRates": {
    "expected-node-path": {
      "passed": 138,
      "total": 150,
      "rate": 0.92
    },
    "terminal-node": {
      "passed": 137,
      "total": 150,
      "rate": 0.9133333333333333
    },
    "persistence": {
      "passed": 149,
      "total": 150,
      "rate": 0.9933333333333333
    },
    "search-state": {
      "passed": 114,
      "total": 150,
      "rate": 0.76
    },
    "shortlist": {
      "passed": 48,
      "total": 48,
      "rate": 1
    },
    "event-type": {
      "passed": 148,
      "total": 150,
      "rate": 0.9866666666666667
    },
    "need-0": {
      "passed": 129,
      "total": 132,
      "rate": 0.9772727272727273
    },
    "token-usage": {
      "passed": 150,
      "total": 150,
      "rate": 1
    },
    "turn-budget": {
      "passed": 150,
      "total": 150,
      "rate": 1
    },
    "need-1": {
      "passed": 15,
      "total": 15,
      "rate": 1
    },
    "need-2": {
      "passed": 12,
      "total": 12,
      "rate": 1
    },
    "need-3": {
      "passed": 3,
      "total": 3,
      "rate": 1
    }
  },
  "repeatability": {
    "stableCompletedCount": 42,
    "stableFailedCount": 4,
    "flakyCount": 4,
    "flakyRate": 0.08,
    "stableCompleted": [
      "study.wedding.01",
      "study.wedding.02",
      "study.wedding.03",
      "study.wedding.04",
      "study.wedding.05",
      "study.wedding.07",
      "study.wedding.08",
      "study.wedding.10",
      "study.birthday.01",
      "study.birthday.02",
      "study.birthday.03",
      "study.birthday.04",
      "study.birthday.05",
      "study.birthday.07",
      "study.birthday.08",
      "study.birthday.09",
      "study.baby_shower.01",
      "study.baby_shower.02",
      "study.baby_shower.03",
      "study.baby_shower.04",
      "study.baby_shower.05",
      "study.baby_shower.07",
      "study.baby_shower.08",
      "study.baby_shower.09",
      "study.baby_shower.10",
      "study.corporate.01",
      "study.corporate.02",
      "study.corporate.03",
      "study.corporate.04",
      "study.corporate.07",
      "study.corporate.08",
      "study.corporate.09",
      "study.corporate.10",
      "study.social.01",
      "study.social.02",
      "study.social.03",
      "study.social.04",
      "study.social.05",
      "study.social.07",
      "study.social.08",
      "study.social.09",
      "study.social.10"
    ],
    "stableFailed": [
      "study.birthday.10",
      "study.baby_shower.06",
      "study.corporate.06",
      "study.social.06"
    ],
    "flaky": [
      "study.wedding.06",
      "study.wedding.09",
      "study.birthday.06",
      "study.corporate.05"
    ]
  },
  "uniqueObservedRoutes": 17,
  "nodeCoverage": {
    "observed": 18,
    "total": 26,
    "rate": 0.6923076923076923,
    "nodes": [
      "aclarar_pedir_faltante",
      "anadir_a_proveedores_recomendados",
      "buscar_proveedores",
      "busqueda_exitosa",
      "consultar_faq",
      "contacto_inicial",
      "crear_lead_cerrar",
      "deteccion_intencion",
      "elicitacion_necesidades",
      "entrevista",
      "existe_plan_guardado",
      "guardar_cerrar_temporalmente",
      "hay_resultados",
      "minimos_para_buscar",
      "recomendar",
      "refinar_criterios",
      "seguir_refinando_guardar_plan",
      "usuario_elige_proveedor"
    ]
  },
  "transitionCoverage": {
    "registryVersion": "decision-flow-v1-2026-07-01",
    "observed": 32,
    "total": 49,
    "rate": 0.6530612244897959
  },
  "latencyMs": {
    "mean": 16613.773333333334,
    "median": 16547,
    "p95": 26294,
    "min": 5038,
    "max": 35370
  },
  "nodeLatencyMs": {
    "recomendar": {
      "visits": 87,
      "meanMs": 11468.241379310344,
      "p95Ms": 15790
    },
    "aclarar_pedir_faltante": {
      "visits": 49,
      "meanMs": 6541.897959183673,
      "p95Ms": 8775
    },
    "elicitacion_necesidades": {
      "visits": 19,
      "meanMs": 15210.473684210527,
      "p95Ms": 19772
    },
    "seguir_refinando_guardar_plan": {
      "visits": 38,
      "meanMs": 6531.5526315789475,
      "p95Ms": 9604
    },
    "guardar_cerrar_temporalmente": {
      "visits": 15,
      "meanMs": 6009.666666666667,
      "p95Ms": 14749
    },
    "crear_lead_cerrar": {
      "visits": 15,
      "meanMs": 6773.2,
      "p95Ms": 8372
    },
    "consultar_faq": {
      "visits": 15,
      "meanMs": 7594.333333333333,
      "p95Ms": 8456
    },
    "refinar_criterios": {
      "visits": 15,
      "meanMs": 10979.533333333333,
      "p95Ms": 13074
    },
    "entrevista": {
      "visits": 17,
      "meanMs": 9778.058823529413,
      "p95Ms": 12330
    }
  },
  "tokensPerConversation": {
    "mean": 34268.63333333333,
    "median": 33953,
    "p95": 64037,
    "min": 16084,
    "max": 71954
  },
  "toolCallsPerConversation": {
    "mean": 1.6066666666666667,
    "median": 1,
    "p95": 5,
    "min": 0,
    "max": 8
  },
  "pricedCostUsdPerConversation": {
    "mean": 0.007027621709348003,
    "median": 0.006056482158899999,
    "p95": 0.013715714312200002,
    "min": 0.0020939268526,
    "max": 0.0178799142715
  },
  "totalPricedCostUsd": 1.0541432564022004,
  "grounding": {
    "requiredTurns": 180,
    "groundedTurns": 180
  },
  "recommendationQuality": {
    "displayedProviders": 704,
    "uniqueProviders": 21,
    "meanShortlistSize": 4.190476190476191,
    "locationConstraint": {
      "applicable": 704,
      "satisfied": 632,
      "unknown": 72,
      "mismatched": 0,
      "strictSatisfactionRate": 0.8977272727272727,
      "mismatchRate": 0
    },
    "categoryConstraint": {
      "applicable": 704,
      "satisfied": 704,
      "satisfactionRate": 1
    },
    "budgetCompatibility": {
      "applicable": 124,
      "compatible": 124,
      "rate": 1
    },
    "eventServiceApplicability": {
      "applicable": 10,
      "supported": 10,
      "rate": 1
    },
    "needRecommendationCoverage": {
      "needsObserved": 201,
      "needsWithRecommendations": 130,
      "rate": 0.6467661691542289
    },
    "expectedNeedEvaluation": {
      "expected": 162,
      "extracted": 159,
      "extractionRecall": 0.9814814814814815,
      "extractedAndRecommended": 111,
      "retrievalCoverageGivenExtraction": 0.6981132075471698,
      "endToEndCoverage": 0.6851851851851852,
      "unexpectedExtractedNeeds": 42
    },
    "exposure": {
      "hhi": 0.06043791967975208,
      "topProviderShare": 0.10227272727272728
    }
  },
  "runtimeErrors": [],
  "pricing": {
    "version": "2026-07-01",
    "effectiveDate": "2026-07-01",
    "sources": [
      "https://developers.openai.com/api/docs/models/gpt-5.4-mini",
      "https://openai.com/index/introducing-gpt-5-4-mini-and-nano/",
      "https://aws.amazon.com/lambda/pricing/"
    ],
    "models": {
      "gpt-5.4-mini": {
        "inputPerMillionUsd": 0.75,
        "cachedInputPerMillionUsd": 0.075,
        "outputPerMillionUsd": 4.5
      },
      "gpt-5.4-nano": {
        "inputPerMillionUsd": 0.2,
        "cachedInputPerMillionUsd": 0.02,
        "outputPerMillionUsd": 1.25
      }
    },
    "lambda": {
      "requestUsd": 2e-7,
      "gbSecondUsd": 0.0000166667,
      "memoryGb": 1
    }
  }
}
```

## Limitations

- Results describe the development deployment and marketplace snapshot at execution time.
- Internal marketplace API calls are counted but not assigned an invented monetary price.
- Deterministic grounding verifies structured provenance and attributes; free-text recommendation rationales still require the separate manual audit rubric.
- No claims about user satisfaction, adoption, or superiority over a baseline are supported by this study.
