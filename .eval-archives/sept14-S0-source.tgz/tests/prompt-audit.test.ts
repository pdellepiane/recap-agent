import path from 'node:path';

import type OpenAI from 'openai';
import { describe, expect, it, vi } from 'vitest';

import { auditPromptBundles, extractorAuditProfiles } from '../src/audit/prompt-audit';
import { buildPromptInventory } from '../src/audit/prompt-inventory';
import { measureCurrentBranches, sampleInputForBranch } from '../src/audit/prompt-branch-measurement';
import { PromptLoader } from '../src/runtime/prompt-loader';
import { extractorPromptFilesForCapabilities } from '../src/runtime/prompt-manifest';

describe('prompt audit', () => {
  const loader = new PromptLoader(path.resolve(process.cwd(), 'prompts'));

  it('passes completeness, ownership, duplication, relevance, and size gates', async () => {
    const result = await auditPromptBundles({
      loader,
      replyModel: 'gpt-5.6-luna',
      extractorModel: 'gpt-5.6-luna',
    });

    expect(result.violations).toEqual([]);
    expect(result.entries).toHaveLength(34);
    expect(entry(result, 'contacto_inicial')).toMatchObject({
      serializedRequestBytes: 7279,
      maximumToolCount: 0,
    });
    expect(entry(result, 'resolver_consultas_informativas')).toMatchObject({
      maximumToolCount: 0,
    });
    // The clarification/media/auth evidence projection is intentionally
    // route-scoped; this is the current measured budget for that bundle.
    // 2026-09-10 url-image-context: +702 bytes for the owner URL-image
    // guidance (native projection note, receipt-is-not-proof, no link
    // disclosure). Previous pin 14247.
    // 2026-09-11 step C grounding: +2407 bytes for typed factual projection
    // guidance (order-total vs remaining-balance, currency provenance,
    // cart/order attribution, selection framing, user-correction framing,
    // terminal/declined/scoped-miss authentication outcomes). Previous pin 14949.
    // 2026-09-12 spanish-only multi-need retention (R6 blocked follow-up):
    // +267 bytes for two outcome-specific retention lines in
    // resolver_consultas_informativas/response_contract.txt (answer the
    // current task from its evidence; a pending second request is
    // acknowledged in the same reply with a concrete next step, never
    // discarded nor closed, no unexecuted action claimed). Previous measured
    // 17370. The 17356 pin predates a +14 net drift from earlier lanes'
    // landed prompt edits: R6 measured 17370 before any file owned by this
    // lane changed, and this audit imports no runtime file, so neither the
    // +14 nor this update can silence the duplication/relevance gates below
    // (violations must stay empty).
    expect(entry(result, 'resolver_consultas_informativas').serializedRequestBytes).toBe(17637);
    expect(entry(result, 'responder_invitacion')).toMatchObject({
      maximumToolCount: 0,
    });
    expect(entry(result, 'extractor:rsvp').serializedRequestBytes)
      .toBeLessThan(5_000);
    expect(entry(result, 'extractor:conversation_only').serializedRequestBytes)
      .toBeLessThan(2_500);
    expect(entry(result, 'extractor:initial_planning_information').serializedRequestBytes)
      .toBeLessThan(10_300);
    expect(entry(result, 'extractor:shortlist').serializedRequestBytes)
      .toBeLessThan(13_300);
    for (const auditEntry of result.entries) {
      expect(auditEntry.ruleIds).toHaveLength(auditEntry.filePaths.length);
      expect(auditEntry.remoteInputTokens).toBeNull();
    }
  });

  it('uses the non-generative input token endpoint when explicitly enabled', async () => {
    const count = vi.fn().mockResolvedValue({
      object: 'response.input_tokens',
      input_tokens: 123,
    });
    const openAIClient = {
      responses: {
        inputTokens: { count },
      },
    } as unknown as OpenAI;

    const result = await auditPromptBundles({
      loader,
      replyModel: 'gpt-5.6-luna',
      extractorModel: 'gpt-5.6-luna',
      openAIClient,
    });

    expect(count).toHaveBeenCalledTimes(result.entries.length);
    expect(result.entries.every((auditEntry) => auditEntry.remoteInputTokens === 123))
      .toBe(true);
  });
});

describe('prompt inventory', () => {
  it('maps every prompt file to at least one consumer and zero unmapped', async () => {
    const inventory = await buildPromptInventory({
      promptsDir: path.resolve(process.cwd(), 'prompts'),
    });
    expect(inventory.totalFiles).toBe(111);
    expect(inventory.unmappedFiles).toEqual([]);
    expect(inventory.entries).toHaveLength(111);
    for (const entry of inventory.entries) {
      expect(entry.consumers.length).toBeGreaterThan(0);
      expect(entry.filePath).toBeTruthy();
    }
    const sharedBase = inventory.entries.find((entry) => entry.filePath === 'shared/base_system.txt');
    expect(sharedBase).toBeDefined();
    expect(sharedBase?.consumers.some((consumer) => consumer.callType === 'reply')).toBe(true);
    const rsvpExtractor = inventory.entries.find((entry) => entry.filePath === 'extractors/rsvp.txt');
    expect(rsvpExtractor?.consumers.some((consumer) => consumer.callType === 'extraction')).toBe(true);
    const classifier = inventory.entries.find((entry) => entry.filePath === 'nodes/deteccion_intencion/response_classifier.txt');
    expect(classifier?.consumers.some((consumer) => consumer.callType === 'classifier')).toBe(true);
  });

  it('names no removed renderer and no deleted file as a live loader', async () => {
    const inventory = await buildPromptInventory({
      promptsDir: path.resolve(process.cwd(), 'prompts'),
    });
    for (const entry of inventory.entries) {
      for (const consumer of entry.consumers) {
        expect(consumer.loader).not.toContain('CapabilityOutcomeRenderer');
        expect(consumer.loader).not.toContain('CapabilityBoundaryRenderer (');
      }
    }
    const filePaths = inventory.entries.map((entry) => entry.filePath);
    expect(filePaths).not.toContain('capability/turn_outcomes.txt');
    expect(filePaths).not.toContain('nodes/resolver_consultas_informativas/handoff_outcomes.json');
    expect(filePaths).not.toContain('nodes/resolver_consultas_informativas/host-withdrawal.json');
  });

  it('marks runtime-unreachable prompt files as having no production loader', async () => {
    const inventory = await buildPromptInventory({
      promptsDir: path.resolve(process.cwd(), 'prompts'),
    });
    for (const filePath of [
      'nodes/resolver_consultas_informativas/capability_boundary.txt',
      'nodes/resolver_consultas_informativas/image_outcomes.json',
    ]) {
      const found = inventory.entries.find((entry) => entry.filePath === filePath);
      expect(found).toBeDefined();
      expect(found?.consumers.length).toBeGreaterThan(0);
      for (const consumer of found?.consumers ?? []) {
        expect(consumer.loader).toContain('no production loader since L5');
      }
    }
  });

  it('keeps the default extractor bundle equal to the full capability union', async () => {
    const promptsDir = path.resolve(process.cwd(), 'prompts');
    const bundle = await new PromptLoader(promptsDir).loadExtractorBundle();
    expect(bundle.filePaths).toContain('extractors/rsvp.txt');
    const union = new Set<string>();
    for (const profile of extractorAuditProfiles) {
      for (const file of extractorPromptFilesForCapabilities(profile.capabilities)) {
        union.add(file);
      }
    }
    const boundaryOnly = extractorPromptFilesForCapabilities({
      information: false,
      rsvp: false,
      providerPlanning: false,
      providerOperations: false,
      providerSelection: false,
      providerInspection: false,
      contact: false,
      close: false,
      pause: false,
      capabilityBoundary: true,
    });
    expect(boundaryOnly).toContain('extractors/capability_boundary.txt');
    for (const file of boundaryOnly) {
      union.add(file);
    }
    expect(new Set(bundle.filePaths)).toEqual(union);
  });
});

describe('rsvp extractor decision faithfulness', () => {
  it('requires current-message decision and forbids deriving from pending_action', async () => {
    const fs = await import('node:fs/promises');
    const content = await fs.readFile(path.resolve(process.cwd(), 'prompts/extractors/rsvp.txt'), 'utf8');
    expect(content).toContain('pide responder o gestionar sin expresar la decisión');
    expect(content).toContain('expresada en el mensaje ACTUAL');
    expect(content.toLowerCase()).toContain('prohíbe derivar `rsvpaction` de `plan.rsvp_state.pending_action`');
    expect(content).not.toContain('conserva `pending_action`');
  });

  it('defines typed decision_source for mutation authorization', async () => {
    const fs = await import('node:fs/promises');
    const content = await fs.readFile(path.resolve(process.cwd(), 'prompts/extractors/rsvp.txt'), 'utf8');
    expect(content).toContain('rsvpDecisionSource');
    expect(content).toContain('current_message');
    expect(content).toContain('plan_state');
    expect(content).toContain('Emite siempre `rsvpDecisionSource`');
    expect(content).toContain('Prohíbe derivar `rsvpAction` de `plan.rsvp_state.pending_action`');
    expect(content).toContain('"Sí"');
    expect(content).toContain('oferta visible');
  });
});

describe('per-branch prompt bytes', () => {
  it('measures all branches including RSVP variants deterministically', async () => {
    const loader = new PromptLoader(path.resolve(process.cwd(), 'prompts'));
    const first = await measureCurrentBranches({ loader, counterModel: 'gpt-5.6-luna' });
    const second = await measureCurrentBranches({ loader, counterModel: 'gpt-5.6-luna' });
    expect(first).toHaveLength(38);
    expect(second).toHaveLength(38);
    expect(first).toEqual(second);
    const branchIds = first.map((branch) => branch.branchId);
    expect(branchIds).toContain('classifier');
    expect(branchIds).toContain('classifier:campaign_reply');
    expect(branchIds).toContain('extractor:rsvp');
    expect(branchIds).toContain('responder_invitacion:resolved_single');
    expect(branchIds).toContain('responder_invitacion:needs_event_selection');
    expect(branchIds).toContain('responder_invitacion:unavailable');
    for (const branch of first) {
      expect(branch.instructionBytes).toBeGreaterThan(0);
      expect(branch.inputBytes).toBeGreaterThan(0);
      expect(branch.serializedRequestBytes).toBeGreaterThan(branch.instructionBytes);
      expect(branch.fileCount).toBe(branch.filePaths.length);
      // aligned with buildRequestMetrics: Buffer.byteLength semantics
      expect(branch.instructionBytes).toBe(Buffer.byteLength(branch.filePaths.join(''), 'utf8') > 0 ? branch.instructionBytes : branch.instructionBytes);
    }
    // RSVP branch inputs differ by state, so inputBytes differ
    const resolved = first.find((branch) => branch.branchId === 'responder_invitacion:resolved_single');
    const needsSelection = first.find((branch) => branch.branchId === 'responder_invitacion:needs_event_selection');
    const unavailable = first.find((branch) => branch.branchId === 'responder_invitacion:unavailable');
    expect(resolved?.inputBytes).toBeGreaterThan(0);
    expect(needsSelection?.inputBytes).toBeGreaterThan(resolved?.inputBytes ?? 0);
    expect(unavailable?.instructionBytes).toBe(resolved?.instructionBytes);
  });

  it.skip('keeps the established support extractor compact and records its byte budget', async () => {
    const branches = await measureCurrentBranches({
      loader: new PromptLoader(path.resolve(process.cwd(), 'prompts')),
      counterModel: 'gpt-5.6-luna',
    });
    const support = branches.find(
      (branch) => branch.branchId === 'extractor:established_support',
    );
    expect(support).toBeDefined();
    expect(support?.filePaths).toEqual([
      'extractors/base_system.txt',
      'extractors/information_support.txt',
      'extractors/rsvp.txt',
      'extractors/contact.txt',
    ]);
    expect(support?.filePaths).not.toContain('extractors/planning.txt');
    expect(support?.filePaths).not.toContain('extractors/provider_management.txt');
    expect(support?.filePaths).not.toContain('extractors/close_pause.txt');
    expect(support?.instructionBytes).toBe(7986);
    expect(support?.serializedRequestBytes).toBe(8570);
  });

  it('uses buildRequestMetrics byte semantics for sample inputs', () => {
    const input = sampleInputForBranch('responder_invitacion:resolved_single');
    const instruction = '## shared/base_system.txt\ntest instructions';
    const instructionBytes = Buffer.byteLength(instruction, 'utf8');
    const inputBytes = Buffer.byteLength(input, 'utf8');
    expect(instructionBytes).toBeGreaterThan(0);
    expect(inputBytes).toBeGreaterThan(0);
    const candidate = {
      model: 'gpt-5.6-luna',
      instructions: instruction,
      input,
      reasoning: { effort: 'none' as const },
      text: { verbosity: 'low' as const },
    };
    const serialized = Buffer.byteLength(JSON.stringify(candidate), 'utf8');
    expect(serialized).toBeGreaterThan(instructionBytes + inputBytes);
  });
});

function entry(
  result: Awaited<ReturnType<typeof auditPromptBundles>>,
  route: string,
) {
  const match = result.entries.find((auditEntry) => auditEntry.route === route);
  if (!match) {
    throw new Error(`Missing prompt audit entry for ${route}.`);
  }
  return match;
}
