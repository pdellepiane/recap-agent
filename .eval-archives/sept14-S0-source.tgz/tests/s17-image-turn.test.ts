import path from 'node:path';

import { beforeEach, describe, expect, it, vi } from 'vitest';

import type { NormalizedInboundMessage } from '../src/core/messages';
import type { InboundImage } from '../src/core/inbound-image';
import { normalizeInboundImage } from '../src/core/inbound-image';
import { createEmptyPlan, mergePlan } from '../src/core/plan';
import type { PersistedPlan } from '../src/core/plan';
import { ImageFileUploadError } from '../src/runtime/image-file-store';
import type {
  AgentRuntime,
  ComposeReplyRequest,
  ComposeReplyResult,
  ExtractRequest,
  ExtractionResult,
} from '../src/runtime/contracts';
import type { ImageFileStore } from '../src/runtime/image-file-store';
import type {
  AgentConversationMessage,
  AgentConversationGateway,
  AgentGatewayResult,
} from '../src/runtime/agent-conversation-gateway';
import type {
  MessageResponseClassifier,
  MessageResponseClassifierResult,
} from '../src/runtime/message-response-classifier';
import { AgentService } from '../src/runtime/agent-service';
import { PromptLoader } from '../src/runtime/prompt-loader';
import type { ProviderGateway } from '../src/runtime/provider-gateway';
import { WhatsAppMessageRenderer } from '../src/runtime/message-renderer';
import { InMemoryPlanStore } from '../src/storage/in-memory-plan-store';

const PNG_1X1 =
  'iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mP8z8BQDwAEhQGAhKmMIQAAAABJRU5ErkJggg==';
const JPEG_MINIMAL = Buffer.from([0xff, 0xd8, 0xff, 0xe0, 0x00, 0x10, 0xff, 0xd9]).toString('base64');

// Delivery preserves model text: only documented transport transforms apply
// (filecite markers, whitespace collapse).

type InspectionOutcome = 'readable' | 'unreadable' | 'human_help';

class ImageStubRuntime implements AgentRuntime {
  public extractCalls = 0;
  public inspectCalls = 0;
  public lastCaption: string | null = null;
  public outcome: InspectionOutcome = 'readable';
  public answer = 'En la imagen se ve un comprobante con el monto indicado.';
  public readonly composeRequests: ComposeReplyRequest[] = [];
  public scripted: Partial<ExtractionResult> = {};
  public extractFailure: unknown = null;
  public composeFailure: unknown = null;
  public failComposeTimes = 0;
  private composeFailuresSeen = 0;

  async extract(request: ExtractRequest): Promise<ExtractionResult> {
    this.extractCalls += 1;
    if (this.extractFailure !== null) throw this.extractFailure as Error;
    return {
      actionIntent: null,
      informationRequests: [],
      intentConfidence: 1,
      eventType: null,
      vendorCategory: null,
      vendorCategories: [],
      activeNeedCategory: null,
      location: null,
      budgetSignal: null,
      guestRange: null,
      preferences: [],
      hardConstraints: [],
      assumptions: [],
      conversationSummary: `Caption recibida: ${request.userMessage}`,
      selectedProviderHints: [],
      selectedProviderReferences: [],
      closeAction: null,
      pauseRequested: false,
      contactName: null,
      contactEmail: null,
      contactPhone: null,
      providerFitCriteria: {
        eventType: null,
        needCategory: null,
        location: null,
        budgetAmount: null,
        budgetCurrency: null,
        mustHave: [],
        shouldAvoid: [],
        rankingNotes: 'Sin criterios.',
      },
      providerQueryIntents: [],
      providerPlanOperations: [],
      providerExplanationRequest: null,
      providerDetailRequest: null,
      ...this.scripted,
    };
  }

  async composeReply(request: ComposeReplyRequest): Promise<ComposeReplyResult> {
    if (this.composeFailure !== null && this.composeFailuresSeen < this.failComposeTimes) {
      this.composeFailuresSeen += 1;
      throw this.composeFailure as Error;
    }
    this.composeRequests.push(request);
    const text = `caption:${request.userMessage}`;
    return {
      text,
      structuredMessage: { type: 'generic', paragraphs_es: [text] },
    };
  }

  async inspectImage(request: {
    image: Extract<InboundImage, { status: 'available' }>;
    caption: string;
  }): Promise<{
    outcome: InspectionOutcome;
    answer: string;
    tokenUsage: null;
    openAiCall: null;
    promptBundleId: string;
  }> {
    this.inspectCalls += 1;
    this.lastCaption = request.caption;
    return {
      outcome: this.outcome,
      answer: this.answer,
      tokenUsage: null,
      openAiCall: null,
      promptBundleId: 'test:image_inspection',
    };
  }
}

function serviceWith(
  runtime: ImageStubRuntime,
  gateway?: AgentConversationGateway,
  responseClassifier?: MessageResponseClassifier,
): {
  service: AgentService;
  planStore: InMemoryPlanStore;
  imageStore: StubImageFileStore;
} {
  const planStore = new InMemoryPlanStore();
  const imageStore = new StubImageFileStore();
  const service = new AgentService({
    planStore,
    runtime,
    providerGateway: {} as unknown as ProviderGateway,
    ...(gateway ? { agentConversationGateway: gateway } : {}),
    ...(responseClassifier ? { responseClassifier } : {}),
    promptLoader: new PromptLoader(path.resolve(process.cwd(), 'prompts')),
    renderers: { whatsapp: new WhatsAppMessageRenderer() },
    imageFileStore: imageStore,
  });
  return { service, planStore, imageStore };
}

class StubImageFileStore implements ImageFileStore {
  public uploads = 0;
  public deletions: string[] = [];
  public failUpload: unknown = null;

  async uploadImage(input: { bytes: Uint8Array; mimeType: 'image/jpeg' | 'image/png' | 'image/webp' }): Promise<{
    fileId: string;
    expiresAt: string;
    byteLength: number;
  }> {
    this.uploads += 1;
    if (this.failUpload !== null) throw this.failUpload as Error;
    return {
      fileId: 'file-test-image-1',
      expiresAt: new Date(Date.now() + 30 * 24 * 3600 * 1000).toISOString(),
      byteLength: input.bytes.length,
    };
  }

  async deleteImage(fileId: string): Promise<void> {
    this.deletions.push(fileId);
  }
}

function inboundWithImage(
  image: NormalizedInboundMessage['image'],
  text: string,
  receivedAt = '2026-09-08T14:30:00Z',
): NormalizedInboundMessage {
  return {
    channel: 'whatsapp',
    externalUserId: 'whatsapp:+51987654321',
    text,
    messageId: 'wamid.HBgLNTE5ODc2NTQzMjE',
    receivedAt,
    contactPhone: '+51987654321',
    image,
  };
}

function textTurn(text: string, messageId: string, receivedAt: string): NormalizedInboundMessage {
  return {
    channel: 'whatsapp',
    externalUserId: 'whatsapp:+51987654321',
    text,
    messageId,
    receivedAt,
    contactPhone: '+51987654321',
  };
}

function handoffGateway(result: AgentGatewayResult): AgentConversationGateway {
  return {
    requestHumanTakeover: async () => result,
  } as unknown as AgentConversationGateway;
}

beforeEach(() => {
  vi.restoreAllMocks();
  vi.spyOn(console, 'info').mockImplementation(() => undefined);
  vi.spyOn(console, 'error').mockImplementation(() => undefined);
});

describe('S17 image turns', () => {
  it('persists an image-only turn silently when no task is outstanding', async () => {
    const runtime = new ImageStubRuntime();
    const { service, planStore } = serviceWith(runtime);
    const image = normalizeInboundImage({ data: JPEG_MINIMAL, mime_type: 'image/jpeg' });
    const response = await service.handleTurn(inboundWithImage(image, ''));

    expect(image.status).toBe('available');
    // No generation and no inspection: extraction runs once for task
    // evidence, the owner composes zero replies.
    expect(runtime.inspectCalls).toBe(0);
    expect(runtime.extractCalls).toBe(1);
    expect(runtime.composeRequests).toHaveLength(0);
    // Typed silence carries a reason, never assistant text.
    expect(response.outbound.text).toBeNull();
    expect(response.outbound.delivery).toMatchObject({
      action: 'suppress',
      reason: 'image_only_no_outstanding_task',
    });
    // The reference persists before the ack: reload sees it (cold-start safe).
    const reloaded = await planStore.getByExternalUser('whatsapp', 'whatsapp:+51987654321');
    expect(reloaded?.image_attachments).toHaveLength(1);
    expect(reloaded?.image_attachments[0]).toMatchObject({ kind: 'file', fileId: 'file-test-image-1' });
    expect(response.trace.plan_persist_reason).toBe('image_file_silence');
    const traceJson = JSON.stringify(response.trace);
    expect(traceJson).not.toContain(JPEG_MINIMAL);
    expect(traceJson).not.toContain('base64,');
    expect(traceJson).not.toContain('file-test-image-1');
    expect(traceJson).toContain('silent_persisted');
  });

  it('preserves the caption with the image in a single owner turn', async () => {
    const runtime = new ImageStubRuntime();
    const { service } = serviceWith(runtime);
    const image = normalizeInboundImage({ data: PNG_1X1, mime_type: 'image/png' });
    const response = await service.handleTurn(inboundWithImage(image, 'Cuanto dice aqui?'));

    expect(image.status).toBe('available');
    expect(runtime.inspectCalls).toBe(0);
    expect(runtime.composeRequests).toHaveLength(1);
    const request = runtime.composeRequests[0];
    expect(request?.userMessage).toBe('Cuanto dice aqui?');
    expect(request?.imageFileAttachments).toHaveLength(1);
    expect(request?.imageEvidence).toMatchObject({
      status: 'available',
      source: 'file',
      captionPresent: true,
      refStored: true,
    });
    expect(response.outbound.text).toBe('caption:Cuanto dice aqui?');
    expect(response.outbound.outputOrigin).toMatchObject({
      status: 'verified',
      transformationVersion: 'transport-v1',
      mismatchFields: [],
    });
  });

  it('sends the smaller-image fallback for image_too_large without inspecting', async () => {
    const runtime = new ImageStubRuntime();
    const { service } = serviceWith(runtime);
    const response = await service.handleTurn(
      inboundWithImage({ status: 'unavailable', reason: 'image_too_large', mimeType: 'image/jpeg' }, ''),
    );

    expect(runtime.inspectCalls).toBe(0);
    expect(runtime.extractCalls).toBe(0);
    expect(response.outbound.text).toBe('caption:');
    expect(runtime.composeRequests.at(-1)?.imageEvidence).toMatchObject({
      status: 'unavailable',
      reason: 'image_too_large',
      captionPresent: false,
    });
  });

  it('sends the resend fallback for media_unavailable without inspecting', async () => {
    const runtime = new ImageStubRuntime();
    const { service } = serviceWith(runtime);
    const response = await service.handleTurn(
      inboundWithImage({ status: 'unavailable', reason: 'media_unavailable', mimeType: 'image/jpeg' }, ''),
    );

    expect(runtime.inspectCalls).toBe(0);
    expect(response.outbound.text).toBe('caption:');
    expect(runtime.composeRequests.at(-1)?.imageEvidence).toMatchObject({
      status: 'unavailable',
      reason: 'media_unavailable',
      captionPresent: false,
    });
  });

  it('answers the caption through the model pipeline without appending a fallback', async () => {
    const runtime = new ImageStubRuntime();
    const { service } = serviceWith(runtime);
    const response = await service.handleTurn(
      inboundWithImage(
        { status: 'unavailable', reason: 'media_unavailable', mimeType: 'image/jpeg' },
        'Mi pedido sigue pendiente?',
      ),
    );

    expect(runtime.inspectCalls).toBe(0);
    expect(runtime.extractCalls).toBe(0);
    expect(response.outbound.text).toBe('caption:Mi pedido sigue pendiente?');
    expect(runtime.composeRequests.at(-1)?.imageEvidence).toMatchObject({
      status: 'unavailable',
      reason: 'media_unavailable',
      captionPresent: true,
    });
  });

  it('keeps an unavailable-image caption in the image fallback evidence path', async () => {
    const runtime = new ImageStubRuntime();
    const gateway = {
      ...handoffGateway({ status: 'skipped', reason: 'disabled', message: 'disabled' }),
      async getRecentMessages() {
        return {
          status: 'success' as const,
          messages: [{
            id: 1,
            direction: 'outbound' as const,
            source: 'frontend_followup',
            body: 'Te ayudamos con tu evento.',
            status: 'sent',
            sentAt: '2026-09-08T14:29:00Z',
            createdAt: '2026-09-08T14:29:00Z',
          }],
        };
      },
      async logMessage() {
        return { status: 'success' as const, message: null };
      },
    } as unknown as AgentConversationGateway;
    const { service } = serviceWith(runtime, gateway);
    const response = await service.handleTurn(inboundWithImage(
      { status: 'unavailable', reason: 'media_unavailable', mimeType: 'image/jpeg' },
      'Hola',
    ));

    expect(response.plan.current_node).toBe('deteccion_intencion');
    expect(runtime.inspectCalls).toBe(0);
    expect(runtime.extractCalls).toBe(0);
    expect(runtime.composeRequests.at(-1)?.currentNode).toBe('deteccion_intencion');
    expect(runtime.composeRequests.at(-1)?.imageEvidence).toMatchObject({
      status: 'unavailable',
      reason: 'media_unavailable',
      captionPresent: true,
    });
  });

  it('treats mismatched bytes as unavailable instead of inspecting', async () => {
    const image = normalizeInboundImage({ data: PNG_1X1, mime_type: 'image/jpeg' });
    expect(image.status).toBe('unavailable');
    const runtime = new ImageStubRuntime();
    const { service } = serviceWith(runtime);
    const response = await service.handleTurn(inboundWithImage(image, ''));

    expect(runtime.inspectCalls).toBe(0);
    expect(response.outbound.text).toBe('caption:');
    expect(runtime.composeRequests.at(-1)?.imageEvidence?.reason).toBe('media_unavailable');
  });

  it('routes an action caption through the owner with the persisted file instead of human help', async () => {
    const runtime = new ImageStubRuntime();
    runtime.outcome = 'human_help';
    runtime.answer = '';
    const { service } = serviceWith(runtime, handoffGateway({ status: 'success', message: 'ok' }));
    const image = normalizeInboundImage({ data: JPEG_MINIMAL, mime_type: 'image/jpeg' });
    const response = await service.handleTurn(inboundWithImage(image, 'Confirma mi pago con este voucher'));

    // No separate inspection/handoff flow: the established owner sees the
    // persisted file together with task evidence and decides.
    expect(runtime.inspectCalls).toBe(0);
    expect(runtime.composeRequests).toHaveLength(1);
    expect(runtime.composeRequests[0]?.imageFileAttachments).toHaveLength(1);
    expect(response.outbound.text).toBe('caption:Confirma mi pago con este voucher');
    expect(response.plan.image_attachments).toHaveLength(1);
  });

  it('keeps the file ref when the owner answers without human registration', async () => {
    const runtime = new ImageStubRuntime();
    runtime.outcome = 'human_help';
    runtime.answer = '';
    const { service } = serviceWith(
      runtime,
      handoffGateway({ status: 'failed', error: 'boom', retryable: false }),
    );
    const image = normalizeInboundImage({ data: JPEG_MINIMAL, mime_type: 'image/jpeg' });
    const response = await service.handleTurn(inboundWithImage(image, 'Confirma mi pago'));

    expect(runtime.inspectCalls).toBe(0);
    expect(response.outbound.text).toBe('caption:Confirma mi pago');
    expect(response.plan.image_attachments).toHaveLength(1);
  });

  it('continues a persisted outstanding request on an image-only turn instead of silencing', async () => {
    const runtime = new ImageStubRuntime();
    const { service, planStore } = serviceWith(runtime);
    // Earlier question persisted by a previous invocation: a pending faq
    // request waits for evidence the image can supply.
    const seed = createEmptyPlan({
      planId: 'seed-question',
      channel: 'whatsapp',
      externalUserId: 'whatsapp:+51987654321',
    });
    await planStore.save({
      plan: mergePlan(seed, {
        information_state: {
          resume_node: null,
          pending_requests: [{ kind: 'faq', query: 'Que monto ves ahi?', requestId: 'information-1' }],
          selection_candidates: [],
          last_completed_request: null,
        },
      }),
      reason: 'test-seed',
    });
    const image = normalizeInboundImage({ data: JPEG_MINIMAL, mime_type: 'image/jpeg' });
    const response = await service.handleTurn(inboundWithImage(image, '', '2026-09-08T14:30:10Z'));

    // Empty text does not suppress a task-fulfilling image: the owner runs
    // with the persisted file projected natively.
    expect(runtime.inspectCalls).toBe(0);
    expect(runtime.composeRequests).toHaveLength(1);
    expect(runtime.composeRequests[0]?.imageFileAttachments).toEqual([
      { fileId: 'file-test-image-1', messageId: 'wamid.HBgLNTE5ODc2NTQzMjE' },
    ]);
    expect(response.outbound.delivery.action).toBe('send');
    expect(response.plan.image_attachments).toHaveLength(1);
  });

  it('answers an image-only turn from model-extracted task evidence, not receipt keywords', async () => {
    const runtime = new ImageStubRuntime();
    runtime.scripted = {
      informationRequests: [{ kind: 'faq', query: 'Que dice el comprobante?' }],
    };
    const { service } = serviceWith(runtime);
    const image = normalizeInboundImage({ data: JPEG_MINIMAL, mime_type: 'image/jpeg' });
    const response = await service.handleTurn(inboundWithImage(image, ''));

    expect(runtime.inspectCalls).toBe(0);
    expect(runtime.composeRequests).toHaveLength(1);
    expect(response.outbound.delivery.action).toBe('send');
    expect(response.plan.image_attachments).toHaveLength(1);
  });

  it('reloads a silently persisted image for a later text question in another invocation', async () => {
    const runtime = new ImageStubRuntime();
    const { service, planStore } = serviceWith(runtime);
    const image = normalizeInboundImage({ data: PNG_1X1, mime_type: 'image/png' });
    const first = await service.handleTurn(inboundWithImage(image, '', '2026-09-08T14:30:00Z'));

    // First invocation persists silently with no generation.
    expect(first.outbound.delivery.action).toBe('suppress');
    expect(runtime.composeRequests).toHaveLength(0);

    // Ten seconds later a text-only invocation references the persisted
    // image through structured extraction evidence (never keywords).
    runtime.scripted = {
      informationRequests: [{ kind: 'faq', query: 'Que monto ves ahi?' }],
      imageReference: { status: 'prior_single', referencedMessageIds: ['wamid.HBgLNTE5ODc2NTQzMjE'] },
    };
    const second = await service.handleTurn(
      textTurn('Que monto ves ahi?', 'wamid.followup1', '2026-09-08T14:30:10Z'),
    );

    expect(second.outbound.delivery.action).toBe('send');
    const request = runtime.composeRequests.at(-1);
    expect(request?.imageFileAttachments).toEqual([
      { fileId: 'file-test-image-1', messageId: 'wamid.HBgLNTE5ODc2NTQzMjE' },
    ]);
    const reloaded = await planStore.getByExternalUser('whatsapp', 'whatsapp:+51987654321');
    expect(reloaded?.image_attachments).toHaveLength(1);
  });

  it('clears an unrelated image from projected context without deleting its ref', async () => {
    const runtime = new ImageStubRuntime();
    const { service, planStore } = serviceWith(runtime);
    const image = normalizeInboundImage({ data: PNG_1X1, mime_type: 'image/png' });
    await service.handleTurn(inboundWithImage(image, '', '2026-09-08T14:30:00Z'));

    runtime.scripted = {
      informationRequests: [{ kind: 'faq', query: 'Cual es el horario?' }],
      imageReference: { status: 'none', referencedMessageIds: [] },
    };
    await service.handleTurn(textTurn('Cual es el horario?', 'wamid.faq1', '2026-09-08T14:30:10Z'));

    const request = runtime.composeRequests.at(-1);
    expect(request?.imageFileAttachments ?? []).toEqual([]);
    // Projection cleared, reference retained for a later linked question.
    const reloaded = await planStore.getByExternalUser('whatsapp', 'whatsapp:+51987654321');
    expect(reloaded?.image_attachments).toHaveLength(1);
  });

  it('maps a provider file-access 404 to unavailable evidence with both attempts recorded', async () => {
    const runtime = new ImageStubRuntime();
    runtime.composeFailure = Object.assign(new Error('file not found'), {
      name: 'NotFoundError',
      status: 404,
    });
    runtime.failComposeTimes = 1;
    const { service } = serviceWith(runtime);
    const image = normalizeInboundImage({ data: JPEG_MINIMAL, mime_type: 'image/jpeg' });
    const response = await service.handleTurn(inboundWithImage(image, 'Es mi comprobante'));

    // The failed file-access attempt is retained, never dropped; the model
    // answers from the remaining evidence with the ref still persisted.
    const request = runtime.composeRequests[0];
    expect(request?.imageEvidence).toMatchObject({ status: 'unavailable', reason: 'image_unavailable' });
    expect(request?.imageFileAttachments ?? []).toEqual([]);
    const outputs = JSON.stringify(response.trace.tool_outputs);
    expect(outputs).toContain('reply_failed_file_access');
    expect(outputs).toContain('fallback_reply_received');
    expect(response.plan.image_attachments).toHaveLength(1);
  });

  it('propagates a reply credential failure instead of relabeling it as image unavailability', async () => {
    const runtime = new ImageStubRuntime();
    runtime.composeFailure = Object.assign(new Error('bad key'), {
      name: 'AuthenticationError',
      status: 401,
    });
    runtime.failComposeTimes = 10;
    const { service, imageStore } = serviceWith(runtime);
    const image = normalizeInboundImage({ data: JPEG_MINIMAL, mime_type: 'image/jpeg' });

    await expect(service.handleTurn(inboundWithImage(image, 'Es mi comprobante'))).rejects.toThrow('bad key');
    // No unavailable-evidence fallback was composed for a credential failure.
    expect(runtime.composeRequests).toHaveLength(0);
    // The fresh upload is cleaned up; no false durable success persists.
    expect(imageStore.deletions).toEqual(['file-test-image-1']);
  });

  it('propagates an extraction credential failure without composing', async () => {
    const runtime = new ImageStubRuntime();
    runtime.extractFailure = Object.assign(new Error('bad key'), {
      name: 'AuthenticationError',
      status: 401,
    });
    const { service } = serviceWith(runtime);
    const image = normalizeInboundImage({ data: JPEG_MINIMAL, mime_type: 'image/jpeg' });

    await expect(service.handleTurn(inboundWithImage(image, 'Es mi comprobante'))).rejects.toThrow('bad key');
    expect(runtime.composeRequests).toHaveLength(0);
  });

  it('propagates an upload credential failure instead of unavailable evidence', async () => {
    const runtime = new ImageStubRuntime();
    const { service, imageStore } = serviceWith(runtime);
    imageStore.failUpload = new ImageFileUploadError('bad key', {
      retryable: false,
      causeName: 'AuthenticationError',
    });
    const image = normalizeInboundImage({ data: JPEG_MINIMAL, mime_type: 'image/jpeg' });

    await expect(service.handleTurn(inboundWithImage(image, 'Hola'))).rejects.toThrow('bad key');
    expect(runtime.composeRequests).toHaveLength(0);
  });
});

/**
 * Model-selected thanks suppression in enforce mode: only gracias-like
 * closings suppress, every other text responds. No keyword routing in
 * production code; the stub stands in for the owner/extraction decision.
 */
class ThanksSuppressingClassifier implements MessageResponseClassifier {
  readonly mode = 'enforce' as const;

  async classify(args: {
    inboundText: string;
    plan: PersistedPlan;
    messages: AgentConversationMessage[];
    contextSource: 'agent_api' | 'local_plan';
  }): Promise<MessageResponseClassifierResult> {
    const suppress = /gracias/iu.test(args.inboundText);
    return {
      trace: {
        mode: 'enforce',
        classifier_profile: 'general',
        action: suppress ? 'suppress_acknowledgement' : 'respond',
        reason: suppress ? 'acknowledgement' : 'requires_response',
        would_suppress: suppress,
        context_source: args.contextSource,
        has_prior_outbound_message: args.messages.some((message) => message.direction === 'outbound'),
        fallback_used: false,
        conversation_health: 'progressing',
        health_reason: 'normal_progress',
        human_help_response: 'not_applicable',
        campaign_reply_kind: suppress ? 'acknowledgement_only' : 'not_applicable',
        automation_confidence: 'not_automated',
        automation_pattern: 'none',
        automation_scope: 'none_or_uncertain',
        prompt_bundle_id: null,
        prompt_file_paths: [],
      },
      tokenUsage: null,
    };
  }
}

describe('Inbound continuity sequences', () => {
  it('shares one continuity projection across text plus image in the same invocation', async () => {
    const runtime = new ImageStubRuntime();
    const { service } = serviceWith(runtime);
    const image = normalizeInboundImage({ data: PNG_1X1, mime_type: 'image/png' });
    const response = await service.handleTurn(inboundWithImage(image, 'Cuanto dice aqui?'));

    // One answer uses both parts: no greeting-only reply, no second
    // image-description answer.
    expect(runtime.composeRequests).toHaveLength(1);
    const request = runtime.composeRequests[0];
    expect(request?.userMessage).toBe('Cuanto dice aqui?');
    expect(request?.imageFileAttachments).toHaveLength(1);
    expect(request?.continuity).toMatchObject({
      pendingQuestion: null,
      pendingTask: null,
      hasPendingInformation: false,
      hasCompletedInformation: false,
      hasPriorOutbound: false,
    });
    expect(response.outbound.delivery).toMatchObject({ action: 'send' });
    expect(response.outbound.text).toBe('caption:Cuanto dice aqui?');
  });

  it('answers the question, persists the image silently, then answers the follow-up: two answers', async () => {
    const runtime = new ImageStubRuntime();
    const { service, planStore, imageStore } = serviceWith(runtime);
    const first = await service.handleTurn(
      textTurn('Tienen local en Miraflores?', 'wamid.q1', '2026-09-08T14:29:50Z'),
    );
    expect(first.outbound.delivery.action).toBe('send');
    expect(first.outbound.text).not.toBeNull();
    expect(runtime.composeRequests).toHaveLength(1);

    // The supplemental image over the answered thread persists silently: no
    // repeated explanation, no second answer for the same thread.
    const image = normalizeInboundImage({ data: JPEG_MINIMAL, mime_type: 'image/jpeg' });
    const second = await service.handleTurn(
      inboundWithImage(image, '', '2026-09-08T14:30:00Z'),
    );
    expect(second.outbound.text).toBeNull();
    expect(second.outbound.delivery).toMatchObject({
      action: 'suppress',
      reason: 'image_only_no_outstanding_task',
    });
    expect(runtime.composeRequests).toHaveLength(1);
    expect(imageStore.uploads).toBe(1);

    // The follow-up question is answered from the persisted pixels: the
    // image is not lost and the follow-up is not suppressed to force a
    // single answer across the conversation.
    runtime.scripted = {
      informationRequests: [{ kind: 'faq', query: 'Que monto ves ahi?' }],
      imageReference: { status: 'prior_single', referencedMessageIds: ['wamid.HBgLNTE5ODc2NTQzMjE'] },
    };
    const third = await service.handleTurn(
      textTurn('Que monto ves ahi?', 'wamid.followup1', '2026-09-08T14:30:10Z'),
    );
    expect(third.outbound.delivery.action).toBe('send');
    expect(third.outbound.text).not.toBeNull();
    expect(runtime.composeRequests).toHaveLength(2);
    expect(runtime.composeRequests[1]?.imageFileAttachments).toEqual([
      { fileId: 'file-test-image-1', messageId: 'wamid.HBgLNTE5ODc2NTQzMjE' },
    ]);
    // Follow-up turns share the same minimum projection shape: the pending
    // faq being answered is visible as typed state on that turn.
    expect(runtime.composeRequests[1]?.continuity).toMatchObject({
      hasPendingInformation: true,
    });

    // The reference survives the full chain for later turns.
    const reloaded = await planStore.getByExternalUser('whatsapp', 'whatsapp:+51987654321');
    expect(reloaded?.image_attachments).toHaveLength(1);
  });

  it('reuses a duplicate image delivery without a second upload', async () => {
    const runtime = new ImageStubRuntime();
    const { service, planStore, imageStore } = serviceWith(runtime);
    const image = normalizeInboundImage({ data: JPEG_MINIMAL, mime_type: 'image/jpeg' });
    const first = await service.handleTurn(
      inboundWithImage(image, '', '2026-09-08T14:30:00Z'),
    );
    expect(first.outbound.delivery).toMatchObject({ action: 'suppress' });

    // Same bytes and same message delivered again: no re-upload, still
    // silent on the answered thread, single stored reference.
    const second = await service.handleTurn(
      inboundWithImage(image, '', '2026-09-08T14:30:00Z'),
    );
    expect(second.outbound.delivery).toMatchObject({ action: 'suppress' });
    expect(imageStore.uploads).toBe(1);
    const reloaded = await planStore.getByExternalUser('whatsapp', 'whatsapp:+51987654321');
    expect(reloaded?.image_attachments).toHaveLength(1);
  });

  it('answers a persisted owner question when the fulfilling image arrives', async () => {
    const runtime = new ImageStubRuntime();
    const { service, planStore } = serviceWith(runtime);
    const seed = createEmptyPlan({
      planId: 'seed-pending-question',
      channel: 'whatsapp',
      externalUserId: 'whatsapp:+51987654321',
    });
    await planStore.save({
      plan: mergePlan(seed, {
        owner_pending_question: 'Que monto ves ahi?',
        open_questions: ['Que monto ves ahi?'],
      }),
      reason: 'test-seed',
    });
    const image = normalizeInboundImage({ data: JPEG_MINIMAL, mime_type: 'image/jpeg' });
    const response = await service.handleTurn(
      inboundWithImage(image, '', '2026-09-08T14:30:10Z'),
    );

    // The pending question travels on the shared projection and the image
    // answers it: one reply, pixels attached, reference stored.
    expect(runtime.composeRequests).toHaveLength(1);
    expect(runtime.composeRequests[0]?.continuity).toMatchObject({
      pendingQuestion: 'Que monto ves ahi?',
    });
    expect(runtime.composeRequests[0]?.imageFileAttachments).toHaveLength(1);
    expect(response.outbound.delivery.action).toBe('send');
    const reloaded = await planStore.getByExternalUser('whatsapp', 'whatsapp:+51987654321');
    expect(reloaded?.image_attachments).toHaveLength(1);
  });

  it('keeps a generation failure distinct and preserves the pending question', async () => {
    const runtime = new ImageStubRuntime();
    runtime.composeFailure = new Error('boom');
    runtime.failComposeTimes = 1;
    const { service, planStore, imageStore } = serviceWith(runtime);
    const seed = createEmptyPlan({
      planId: 'seed-pending-failure',
      channel: 'whatsapp',
      externalUserId: 'whatsapp:+51987654321',
    });
    await planStore.save({
      plan: mergePlan(seed, {
        owner_pending_question: 'Que monto ves ahi?',
        open_questions: ['Que monto ves ahi?'],
      }),
      reason: 'test-seed',
    });
    const image = normalizeInboundImage({ data: JPEG_MINIMAL, mime_type: 'image/jpeg' });

    // A failed turn throws instead of degrading to silence or a false
    // success: failures stay distinct from suppressions.
    await expect(
      service.handleTurn(inboundWithImage(image, 'Es mi comprobante', '2026-09-08T14:30:10Z')),
    ).rejects.toThrow('boom');
    expect(imageStore.deletions).toEqual(['file-test-image-1']);
    // The pending question is never marked answered by a failed turn.
    const reloaded = await planStore.getByExternalUser('whatsapp', 'whatsapp:+51987654321');
    expect(reloaded?.owner_pending_question).toBe('Que monto ves ahi?');
    expect(reloaded?.open_questions).toContain('Que monto ves ahi?');
    expect(reloaded?.image_attachments ?? []).toHaveLength(0);
  });

  it('keeps a suppressed thanks distinct from a failure and preserves the pending question', async () => {
    const runtime = new ImageStubRuntime();
    const classifier = new ThanksSuppressingClassifier();
    const { service, planStore } = serviceWith(runtime, undefined, classifier);
    const seed = createEmptyPlan({
      planId: 'seed-pending-suppress',
      channel: 'whatsapp',
      externalUserId: 'whatsapp:+51987654321',
    });
    await planStore.save({
      plan: mergePlan(seed, {
        owner_pending_question: 'Que monto ves ahi?',
        open_questions: ['Que monto ves ahi?'],
      }),
      reason: 'test-seed',
    });

    // Thanks with no task is legitimate silence: typed suppress, no text,
    // zero generations.
    const thanks = await service.handleTurn(
      textTurn('Gracias', 'wamid.thanks1', '2026-09-08T14:30:10Z'),
    );
    expect(thanks.outbound.text).toBeNull();
    expect(thanks.outbound.delivery).toMatchObject({
      action: 'suppress',
      reason: 'suppress_acknowledgement',
    });
    expect(runtime.composeRequests).toHaveLength(0);
    // The suppressed turn never marks the pending question answered.
    const reloaded = await planStore.getByExternalUser('whatsapp', 'whatsapp:+51987654321');
    expect(reloaded?.owner_pending_question).toBe('Que monto ves ahi?');
    expect(reloaded?.open_questions).toContain('Que monto ves ahi?');
  });

  it('answers an explicit repeat request instead of suppressing it as a duplicate', async () => {
    const runtime = new ImageStubRuntime();
    const classifier = new ThanksSuppressingClassifier();
    const { service } = serviceWith(runtime, undefined, classifier);
    const first = await service.handleTurn(
      textTurn('Tienen local en Miraflores?', 'wamid.q1', '2026-09-08T14:29:50Z'),
    );
    expect(first.outbound.delivery.action).toBe('send');

    const image = normalizeInboundImage({ data: JPEG_MINIMAL, mime_type: 'image/jpeg' });
    const second = await service.handleTurn(
      inboundWithImage(image, '', '2026-09-08T14:30:00Z'),
    );
    expect(second.outbound.delivery).toMatchObject({ action: 'suppress' });

    // An intentional requested repetition is not duplicate delivery: the
    // explicit request is answered, never suppressed for the prior answer.
    const third = await service.handleTurn(
      textTurn('Me lo puedes repetir por favor?', 'wamid.repeat1', '2026-09-08T14:30:10Z'),
    );
    expect(third.outbound.delivery.action).toBe('send');
    expect(third.outbound.text).not.toBeNull();
    expect(runtime.composeRequests).toHaveLength(2);
  });
});

describe('R2 question needs image continuity chain', () => {
  it('preserves the receipt question across turns and answers it when the image arrives', async () => {
    const runtime = new ImageStubRuntime();
    const { service, planStore, imageStore } = serviceWith(runtime);

    // Turn 1 (cold): the receipt question needs later evidence. The normal
    // path preserves the unresolved user question for its later image.
    runtime.scripted = {
      ambiguity: {
        status: 'ambiguous',
        clarificationQuestion: 'Quieres el estado o que revise el comprobante?',
        interpretations: [],
        candidateOperations: [],
        questionKey: 'status_or_proof_review',
      },
    };
    const first = await service.handleTurn(
      textTurn('Confirma el monto de mi comprobante', 'wamid.receiptq', '2026-09-08T14:29:50Z'),
    );
    expect(first.outbound.delivery.action).toBe('send');
    const afterQuestion = await planStore.getByExternalUser('whatsapp', 'whatsapp:+51987654321');
    expect(afterQuestion?.owner_pending_question).toBe('Confirma el monto de mi comprobante');

    // Turn 2: the image-only turn finds the pending question and answers it
    // from the pixels instead of persisting silently.
    runtime.scripted = {};
    const image = normalizeInboundImage({ data: JPEG_MINIMAL, mime_type: 'image/jpeg' });
    const second = await service.handleTurn(
      inboundWithImage(image, '', '2026-09-08T14:30:00Z'),
    );
    expect(second.outbound.delivery.action).toBe('send');
    expect(imageStore.uploads).toBe(1);
    expect(runtime.composeRequests).toHaveLength(2);
    expect(runtime.composeRequests[1]?.continuity).toMatchObject({
      pendingQuestion: 'Confirma el monto de mi comprobante',
    });
    expect(runtime.composeRequests[1]?.imageFileAttachments).toHaveLength(1);

    // The answered question clears and the latest response is recorded; the
    // reference survives for later turns.
    const reloaded = await planStore.getByExternalUser('whatsapp', 'whatsapp:+51987654321');
    expect(reloaded?.owner_pending_question).toBeNull();
    expect(reloaded?.last_outbound_context?.message_id).toBe('wamid.HBgLNTE5ODc2NTQzMjE');
    expect(reloaded?.image_attachments).toHaveLength(1);
  });
});
