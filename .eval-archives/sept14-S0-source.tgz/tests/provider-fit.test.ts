import { describe, expect, it } from 'vitest';

import type { ProviderSummary } from '../src/core/provider';
import {
  createProviderFitCriteria,
  isProviderEligibleForCriteria,
  normalizeBudgetTier,
  parseBudgetAmount,
  rankProvidersForCriteria,
} from '../src/runtime/provider-fit';

function createProvider(overrides: Partial<ProviderSummary> = {}): ProviderSummary {
  return {
    id: 1,
    title: 'Proveedor',
    category: 'Catering',
    location: 'Lima',
    priceLevel: 'mid',
    eventTypes: ['others'],
    description: 'Servicios para eventos.',
    serviceHighlights: [],
    termsHighlights: [],
    ...overrides,
  };
}

describe('provider fit normalization', () => {
  it('parses spanish budget amounts', () => {
    expect(parseBudgetAmount('mil soles')).toBe(1000);
    expect(parseBudgetAmount('S/ 1,000')).toBe(1000);
    expect(parseBudgetAmount('1000')).toBe(1000);
    expect(parseBudgetAmount(null)).toBeNull();
  });

  it('maps qualitative budget signals into ranking tiers', () => {
    expect(parseBudgetAmount('presupuesto mínimo')).toBe(1000);
    expect(parseBudgetAmount('presupuesto bajo')).toBe(3000);
    expect(parseBudgetAmount('presupuesto medio')).toBe(7500);
    expect(parseBudgetAmount('presupuesto medio-alto')).toBe(15000);
    expect(parseBudgetAmount('presupuesto alto')).toBe(20000);
  });

  it('normalizes budget tiers', () => {
    expect(normalizeBudgetTier(500)).toBe('very_low');
    expect(normalizeBudgetTier(1000)).toBe('very_low');
    expect(normalizeBudgetTier(1001)).toBe('low');
    expect(normalizeBudgetTier(5000)).toBe('low');
    expect(normalizeBudgetTier(5001)).toBe('medium');
    expect(normalizeBudgetTier(10000)).toBe('medium');
    expect(normalizeBudgetTier(10001)).toBe('high');
    expect(normalizeBudgetTier(25000)).toBe('high');
    expect(normalizeBudgetTier(25001)).toBe('very_high');
    expect(normalizeBudgetTier(null)).toBe('unknown');
  });

  it('builds criteria from extractor fields', () => {
    expect(createProviderFitCriteria({
      eventType: 'cumpleanos',
      needCategory: 'Catering',
      location: 'Miraflores',
      budgetSignal: 'mil soles',
      preferences: ['tablas de quesos'],
      hardConstraints: ['solo bodas'],
      rankingNotes: 'Priorizar comida para cumpleaños con bajo presupuesto.',
    })).toEqual({
      eventType: 'cumpleanos',
      needCategory: 'Catering',
      location: 'Miraflores',
      budgetAmount: 1000,
      budgetCurrency: 'PEN',
      mustHave: ['tablas de quesos'],
      shouldAvoid: ['solo bodas'],
      rankingNotes: 'Priorizar comida para cumpleaños con bajo presupuesto. prioriza proveedores flexibles para celebraciones sociales y grupos del tamaño indicado',
    });
  });
});

describe('rankProvidersForCriteria', () => {
  it('ranks birthday low-budget providers correctly', () => {
    const laBotaneria = createProvider({
      id: 17,
      title: 'La Botanería',
      category: 'Catering',
      priceLevel: 'mid',
      eventTypes: ['others'],
      description: 'Espacio gastronómico ideal para compartir.',
    });
    const farola = createProvider({
      id: 4,
      title: 'Farola',
      category: 'Catering',
      priceLevel: 'high',
      eventTypes: ['wedding', 'others'],
      description: 'Servicios enfocados en eventos.',
    });
    const dulcefina = createProvider({
      id: 94,
      title: 'Dulcefina',
      category: 'Catering',
      priceLevel: 'very_high',
      eventTypes: ['others'],
      description: 'Tortas de boda personalizadas.',
    });
    const paolaPuerta = createProvider({
      id: 135,
      title: 'Paola Puerta Catering',
      category: 'Catering',
      priceLevel: 'very_high',
      eventTypes: ['wedding'],
      description: 'Experiencias gastronómicas para matrimonios y eventos.',
    });
    const fourFoodies = createProvider({
      id: 136,
      title: '4Foodies',
      category: 'Catering',
      priceLevel: 'high',
      eventTypes: ['wedding', 'others'],
      description: 'Catering para eventos y tablas de quesos.',
    });

    const ranked = rankProvidersForCriteria(
      [laBotaneria, farola, dulcefina, paolaPuerta, fourFoodies],
      {
        eventType: 'cumpleanos',
        needCategory: 'Catering',
        location: 'Lima Miraflores',
        budgetAmount: 1000,
        budgetCurrency: 'PEN',
        mustHave: ['comida'],
        shouldAvoid: ['solo bodas'],
        rankingNotes: 'Priorizar comida para cumpleaños con bajo presupuesto.',
      },
    );

    expect(ranked[0].id).toBe(17);
    expect(ranked[ranked.length - 1].id).toBe(135);
    expect(ranked.find((p) => p.id === 135)?.fitWarnings).toContain(
      'Proveedor orientado principalmente a bodas.',
    );
  });

  it('uses retrieval relevance before provider id for equal fit scores', () => {
    const criteria = {
      eventType: 'boda' as const,
      needCategory: 'Catering',
      location: 'Lima',
      budgetAmount: null,
      budgetCurrency: null,
      mustHave: [],
      shouldAvoid: [],
      rankingNotes: '',
    };
    const ranked = rankProvidersForCriteria([
      createProvider({ id: 1, retrievalScore: 0.2 }),
      createProvider({ id: 2, retrievalScore: 0.9 }),
    ], criteria);
    expect(ranked.map((provider) => provider.id)).toEqual([2, 1]);
  });

  it('rejects severe low-budget and explicit avoid conflicts', () => {
    const criteria = {
      eventType: 'cumpleanos' as const,
      needCategory: 'Catering',
      location: 'Lima',
      budgetAmount: 1000,
      budgetCurrency: 'PEN' as const,
      mustHave: [],
      shouldAvoid: ['solo bodas'],
      rankingNotes: '',
    };
    const [expensive] = rankProvidersForCriteria([
      createProvider({
        priceLevel: 'high',
        description: 'Catering para eventos.',
      }),
    ], criteria);
    const [excluded] = rankProvidersForCriteria([
      createProvider({
        priceLevel: 'mid',
        description: 'Catering solo bodas.',
      }),
    ], criteria);

    expect(expensive && isProviderEligibleForCriteria(expensive, criteria)).toBe(false);
    expect(excluded && isProviderEligibleForCriteria(excluded, criteria)).toBe(false);
  });
});
