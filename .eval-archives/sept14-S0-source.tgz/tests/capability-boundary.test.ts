import { describe, expect, it } from 'vitest';
import fs from 'node:fs/promises';

import { createEmptyPlan } from '../src/core/plan';
import { resolveDynamicTools } from '../src/runtime/dynamic-agent-policy';
import {
  buildRuntimeCapabilityManifest,
  mergeRuntimeCapabilityManifests,
  resolveCapabilityDecision,
  runtimeOperationIds,
} from '../src/runtime/capability-manifest';
import {
  parseCapabilityBoundaryMessages,
} from '../src/runtime/capability-boundary-renderer';
import { projectSupportHandoffEvidence } from '../src/runtime/reply-evidence-projector';
import { runtimeToolOperationMap } from '../src/runtime/capability-manifest';

describe('runtime capability boundary', () => {
  it('keeps the v1 operation order stable', () => {
    expect(runtimeOperationIds.slice(0, 18)).toEqual([
      'faq.read',
      'event.association.read',
      'event.detail.read',
      'purchase.orders.read',
      'purchase.gift_detail.read',
      'rsvp.state.read',
      'rsvp.response.write',
      'provider.plan',
      'provider.search',
      'provider.quote.write',
      'auth.phone',
      'auth.email_otp',
      'human.takeover.write',
      'confirmation_document.send',
      'media.image.inspect',
      'payment_proof.verify',
      'purchase.modify',
      'refund_or_withdrawal.execute',
    ]);
    expect(runtimeOperationIds).toContain('provider.favorites.write');
    expect(runtimeOperationIds).toContain('auth.otp.send');
  });

  it('blocks customer writes in development while leaving reads available', () => {
    const manifest = buildRuntimeCapabilityManifest({
      configured: true,
      environment: 'development',
      allowCustomerWrites: false,
      featureFlags: {
        faq: true,
        purchaseInformation: true,
        rsvp: true,
        humanTakeover: true,
      },
    });

    expect(manifest['purchase.orders.read']).toMatchObject({ available: true, reason: 'enabled' });
    expect(manifest['rsvp.response.write']).toMatchObject({ available: false, reason: 'write_blocked' });
    expect(manifest['human.takeover.write']).toMatchObject({ available: false, reason: 'write_blocked' });
    expect(manifest['confirmation_document.send']).toMatchObject({ available: false, reason: 'not_implemented' });
    expect(manifest['media.image.inspect']).toMatchObject({ available: false, reason: 'media_unavailable' });
  });

  it('marks every operation unavailable for the no-op gateway manifest', () => {
    const manifest = buildRuntimeCapabilityManifest({ configured: false });
    expect(manifest.operations).toHaveLength(runtimeOperationIds.length);
    expect(manifest.operations.every((operation) => !operation.available)).toBe(true);
    expect(manifest.operations.find((operation) => operation.id === 'media.image.inspect')?.reason)
      .toBe('media_unavailable');
  });

  it('separates extraction intent from deterministic availability', () => {
    const manifest = buildRuntimeCapabilityManifest({
      configured: true,
      featureFlags: { purchaseInformation: true, humanTakeover: true },
    });
    expect(resolveCapabilityDecision({ requestedOperation: null, manifest })).toEqual({ status: 'not_applicable' });
    expect(resolveCapabilityDecision({ requestedOperation: 'purchase.orders.read', manifest })).toEqual({
      status: 'supported',
      operation: 'purchase.orders.read',
    });
    expect(resolveCapabilityDecision({
      requestedOperation: null,
      manifest,
      ambiguity: {
        status: 'ambiguous',
        candidateOperations: ['purchase.orders.read', 'confirmation_document.send'],
        questionKey: 'status_or_document',
      },
    })).toEqual({
      status: 'clarify',
      candidateOperations: ['purchase.orders.read', 'confirmation_document.send'],
      questionKey: 'status_or_document',
    });
    const allSupportedAmbiguityManifest = buildRuntimeCapabilityManifest({
      configured: true,
      allowCustomerWrites: true,
      featureFlags: { rsvp: true },
    });
    expect(resolveCapabilityDecision({
      requestedOperation: null,
      manifest: allSupportedAmbiguityManifest,
      ambiguity: {
        status: 'ambiguous',
        candidateOperations: ['rsvp.state.read', 'rsvp.response.write'],
        questionKey: 'type_missing',
      },
    })).toEqual({ status: 'not_applicable' });
    expect(resolveCapabilityDecision({ requestedOperation: 'confirmation_document.send', manifest })).toEqual({
      status: 'unsupported',
      operation: 'confirmation_document.send',
      reason: 'not_implemented',
      humanTakeoverAvailable: true,
    });
  });

  it('filters tools through the same manifest used by the service', () => {
    const plan = createEmptyPlan({ planId: 'capability-plan', channel: 'terminal', externalUserId: 'capability-user' });
    const manifest = buildRuntimeCapabilityManifest({
      configured: true,
      featureFlags: { providerPlanning: true, providerSearch: false },
    });
    const tools = resolveDynamicTools({
      plan,
      maximumTools: ['search_providers_from_plan', 'list_categories'],
      searchReady: true,
      providerResults: [],
      capabilityManifest: manifest,
    });
    expect(tools).toEqual(['list_categories']);
    expect(runtimeToolOperationMap.search_providers_from_plan).toBe('provider.search');
  });

  it('intersects configured features with the concrete gateway descriptor', () => {
    const configured = buildRuntimeCapabilityManifest({
      configured: true,
      featureFlags: { purchaseInformation: true, humanTakeover: true },
    });
    const gateway = buildRuntimeCapabilityManifest({
      configured: true,
      disabledOperations: ['purchase.orders.read', 'human.takeover.write'],
    });
    const merged = mergeRuntimeCapabilityManifests(configured, gateway);
    expect(merged['purchase.orders.read']).toMatchObject({
      available: false,
      reason: 'feature_disabled',
    });
    expect(merged['human.takeover.write']).toMatchObject({
      available: false,
      reason: 'feature_disabled',
    });
    expect(merged['purchase.gift_detail.read'].available).toBe(true);
  });
});

describe('capability boundary evidence', () => {
  it('parses the tracked boundary prompt structurally', async () => {
    const boundaryText = await fs.readFile(
      `${process.cwd()}/prompts/nodes/resolver_consultas_informativas/capability_boundary.txt`,
      'utf8',
    );
    const messages = parseCapabilityBoundaryMessages(boundaryText);
    for (const value of Object.values(messages)) {
      expect(value.length).toBeGreaterThan(0);
    }
  });

  it('projects honest handoff evidence without fixed replies', () => {
    const requested = projectSupportHandoffEvidence({
      result: { status: 'success', message: 'Requested.' },
      phonePresent: true,
      confirmedReceipt: true,
    });
    expect(requested.handoffOutcome).toBe('handoff_requested');
    expect(requested.effectConfirmed).toBe(true);
    expect(requested.requiresReplyModel).toBe(true);
    const failed = projectSupportHandoffEvidence({
      result: { status: 'failed', error: 'unavailable', retryable: true },
      phonePresent: true,
      confirmedReceipt: false,
    });
    expect(failed.handoffOutcome).toBe('handoff_failed');
    expect(failed.effectConfirmed).toBe(false);
    expect(failed.operationalNote).toContain('unavailable');
    const unknown = projectSupportHandoffEvidence({
      result: { status: 'failed', error: 'timeout', retryable: true, outcome: 'unknown' },
      phonePresent: true,
      confirmedReceipt: false,
    });
    expect(unknown.handoffOutcome).toBe('handoff_unknown');
    const skipped = projectSupportHandoffEvidence({
      result: { status: 'skipped', reason: 'missing_phone_number', message: 'Missing.' },
      phonePresent: false,
      confirmedReceipt: false,
    });
    expect(skipped.handoffOutcome).toBeNull();
    expect(skipped.identityAvailable).toBe(false);
    expect(skipped.effectConfirmed).toBe(false);
    for (const evidence of [requested, failed, unknown, skipped]) {
      expect(evidence.requiresReplyModel).toBe(true);
    }
  });
});
