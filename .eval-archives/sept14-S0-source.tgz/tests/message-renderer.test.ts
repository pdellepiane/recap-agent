import { describe, expect, it } from 'vitest';

import { WebChatMessageRenderer, WhatsAppMessageRenderer } from '../src/runtime/message-renderer';
import {
  multiNeedRecommendationMessageSchema,
  type StructuredMessage,
} from '../src/runtime/structured-message';
import type { ProviderSummary } from '../src/core/provider';

const renderer = new WhatsAppMessageRenderer();

function createProvider(overrides: Partial<ProviderSummary> = {}): ProviderSummary {
  return {
    id: 1,
    title: 'La Botanería',
    slug: 'la-botaneria',
    category: 'Catering',
    location: 'Lima, Perú',
    priceLevel: 'mid',
    rating: '4.5',
    reason: 'coincide con el plan',
    detailUrl: 'https://sinenvolturas.com/proveedores/la-botaneria',
    websiteUrl: null,
    minPrice: null,
    maxPrice: null,
    promoBadge: null,
    promoSummary: null,
    descriptionSnippet: 'Carta variada de comida y bebidas.',
    serviceHighlights: ['servicio de barra'],
    termsHighlights: [],
    ...overrides,
  };
}

describe('WhatsAppMessageRenderer', () => {
  describe('structured schemas', () => {
    it('accepts valid multi-need recommendation payloads', () => {
      const parsed = multiNeedRecommendationMessageSchema.parse({
        type: 'multi_need_recommendation',
        intro_es: 'Encontré opciones para comparar.',
        needs: [
          {
            category: 'Catering',
            summary_es: 'Para catering.',
            providers: [
              {
                provider_id: 1,
                rationale_es: 'Encaja por estilo.',
                caveat_es: null,
              },
            ],
          },
        ],
        next_step_es: 'Podemos revisar frente por frente.',
      });

      expect(parsed.needs).toHaveLength(1);
    });

    it('rejects empty multi-need recommendation needs', () => {
      expect(() =>
        multiNeedRecommendationMessageSchema.parse({
          type: 'multi_need_recommendation',
          intro_es: 'Encontré opciones para comparar.',
          needs: [],
          next_step_es: 'Podemos revisar frente por frente.',
        }),
      ).toThrow();
    });

    it('rejects malformed grouped provider references', () => {
      expect(() =>
        multiNeedRecommendationMessageSchema.parse({
          type: 'multi_need_recommendation',
          intro_es: 'Encontré opciones para comparar.',
          needs: [
            {
              category: 'Catering',
              summary_es: 'Para catering.',
              providers: [
                {
                  provider_id: '1',
                  rationale_es: 'Encaja por estilo.',
                  caveat_es: null,
                },
              ],
            },
          ],
          next_step_es: 'Podemos revisar frente por frente.',
        }),
      ).toThrow();
    });

    it('allows multiple providers per need for separate match components', () => {
      const parsed = multiNeedRecommendationMessageSchema.parse({
        type: 'multi_need_recommendation',
        intro_es: 'Encontré opciones para comparar.',
        needs: [
          {
            category: 'Catering',
            summary_es: 'Para catering.',
            providers: [
              { provider_id: 1, match_label_es: 'sushi', rationale_es: 'Primera.', caveat_es: null },
              { provider_id: 2, match_label_es: 'torta', rationale_es: 'Segunda.', caveat_es: null },
            ],
          },
        ],
        next_step_es: 'Podemos revisar frente por frente.',
      });

      expect(parsed.needs[0]?.providers).toHaveLength(2);
    });

  });

  describe('welcome messages', () => {
    it('renders a brief greeting, scope, and open question without lists', () => {
      const message: StructuredMessage = {
        type: 'welcome',
        greeting_es: '¡Hola! Soy el asistente de Sin Envolturas.',
        scope_es:
          'Puedo ayudarte con tu evento o responder una consulta sobre Sin Envolturas.',
        ask_es: '¿Qué necesitas hoy?',
      };

      const result = renderer.render({ message, providerResults: [] });

      expect(result).toBe(
        '¡Hola! Soy el asistente de Sin Envolturas.\n\nPuedo ayudarte con tu evento o responder una consulta sobre Sin Envolturas.\n\n¿Qué necesitas hoy?',
      );
    });

    it('omits an absent optional scope', () => {
      const message: StructuredMessage = {
        type: 'welcome',
        greeting_es: '¡Hola!',
        ask_es: '¿En qué te ayudo?',
      };

      const result = renderer.render({ message, providerResults: [] });

      expect(result).toBe('¡Hola!\n\n¿En qué te ayudo?');
    });
  });

  describe('recommendation messages', () => {
    it('renders provider cards with deterministic formatting', () => {
      const provider = createProvider();
      const message: StructuredMessage = {
        type: 'recommendation',
        intro_es: 'Encontré estas opciones para ti.',
        providers: [
          { provider_id: 1, rationale_es: 'Buena relación calidad-precio.', caveat_es: null },
        ],
      };

      const result = renderer.render({ message, providerResults: [provider] });

      expect(result).toContain('1. La Botanería');
      expect(result).toContain('Buena relación calidad-precio.');
      expect(result).toContain('Ubicación: Lima, Perú.');
      expect(result).toContain('Precio: $$.');
      expect(result).toContain('Ficha: https://sinenvolturas.com/proveedores/la-botaneria');
      expect(result).not.toContain('Elige un proveedor');
    });

    it('places Ficha link on its own line', () => {
      const provider = createProvider();
      const message: StructuredMessage = {
        type: 'recommendation',
        intro_es: 'Opciones:',
        providers: [
          { provider_id: 1, rationale_es: 'Opción destacada.', caveat_es: null },
        ],
      };

      const result = renderer.render({ message, providerResults: [provider] });
      const lines = result.split('\n');
      const fichaLine = lines.find((line) => line.includes('Ficha:'));

      expect(fichaLine).toBeDefined();
      expect(fichaLine?.trim()).toBe('Ficha: https://sinenvolturas.com/proveedores/la-botaneria');
    });

    it('renders caveat when present', () => {
      const provider = createProvider();
      const message: StructuredMessage = {
        type: 'recommendation',
        intro_es: 'Opciones:',
        providers: [
          {
            provider_id: 1,
            rationale_es: 'Excelente servicio.',
            caveat_es: 'No incluye decoración.',
          },
        ],
      };

      const result = renderer.render({ message, providerResults: [provider] });

      expect(result).toContain('Nota: No incluye decoración.');
    });

    it('renders promo when present', () => {
      const provider = createProvider({ promoBadge: '15% off' });
      const message: StructuredMessage = {
        type: 'recommendation',
        intro_es: 'Opciones:',
        providers: [
          { provider_id: 1, rationale_es: 'Con promo.', caveat_es: null },
        ],
      };

      const result = renderer.render({ message, providerResults: [provider] });

      expect(result).toContain('Promo: 15% off.');
    });

    it('skips providers not found in results', () => {
      const message: StructuredMessage = {
        type: 'recommendation',
        intro_es: 'Opciones:',
        providers: [
          { provider_id: 999, rationale_es: 'No existe.', caveat_es: null },
        ],
      };

      const result = renderer.render({ message, providerResults: [] });

      expect(result).toBe('Opciones:');
    });

    it('uses fallback location when provider has no location', () => {
      const provider = createProvider({ location: null });
      const message: StructuredMessage = {
        type: 'recommendation',
        intro_es: 'Opciones:',
        providers: [
          { provider_id: 1, rationale_es: 'Sin ubicación.', caveat_es: null },
        ],
      };

      const result = renderer.render({ message, providerResults: [provider] });

      expect(result).toContain('Ubicación: Ubicación no especificada.');
    });
  });

  describe('multi_need_recommendation messages', () => {
    it('renders grouped needs and provider cards deterministically', () => {
      const providers = [
        createProvider({ id: 1, title: 'La Botanería', category: 'Catering' }),
        createProvider({
          id: 2,
          title: 'Foto Clara',
          category: 'Fotografía y video',
          detailUrl: 'https://sinenvolturas.com/proveedores/foto-clara',
        }),
      ];
      const message: StructuredMessage = {
        type: 'multi_need_recommendation',
        intro_es: 'Busqué proveedores que encajan con tu plan.',
        needs: [
          {
            category: 'Catering',
            summary_es: 'Opciones para comida.',
            providers: [
              {
                provider_id: 1,
                match_label_es: 'sushi',
                rationale_es: 'Encaja por propuesta gastronómica.',
                caveat_es: null,
              },
            ],
          },
          {
            category: 'Fotografía y video',
            summary_es: 'Opciones para foto.',
            providers: [
              {
                provider_id: 2,
                rationale_es: 'Encaja por estilo natural.',
                caveat_es: 'Confirmar cobertura de fiesta',
              },
            ],
          },
        ],
        next_step_es: 'Podemos revisar frente por frente.',
      };

      const result = renderer.render({ message, providerResults: providers });

      expect(result).toContain('Busqué proveedores que encajan con tu plan.');
      expect(result).toContain(
        'Servicio de comida\nOpciones para comida.\n1. La Botanería - sushi (Lima, Perú · $$)',
      );
      expect(result).toContain(
        'Fotografía y video\nOpciones para foto.\n1. Foto Clara (Lima, Perú · $$)',
      );
      expect(result).toContain('Limitación: Confirmar cobertura de fiesta.');
      expect(result).toContain('Podemos revisar frente por frente.');
      expect(result).not.toContain('Ubicación:');
      expect(result).not.toContain('Precio:');
    });

    it('uses WebChat channel formatting without WhatsApp ficha labels', () => {
      const webRenderer = new WebChatMessageRenderer();
      const message: StructuredMessage = {
        type: 'multi_need_recommendation',
        intro_es: 'Encontré opciones para comparar.',
        needs: [
          {
            category: 'Catering',
            summary_es: 'Para catering.',
            providers: [
              {
                provider_id: 1,
                rationale_es: 'Tiene una propuesta alineada.',
                caveat_es: null,
              },
            ],
          },
        ],
        next_step_es: 'Revisemos el primer frente.',
      };

      const result = webRenderer.render({
        message,
        providerResults: [createProvider()],
      });

      expect(result).toContain('1. La Botanería (Lima, Perú · $$)');
      expect(result).toContain('https://sinenvolturas.com/proveedores/la-botaneria');
      expect(result).not.toContain('Ficha:');
    });

    it('skips missing provider IDs inside grouped needs', () => {
      const message: StructuredMessage = {
        type: 'multi_need_recommendation',
        intro_es: 'Encontré opciones para comparar.',
        needs: [
          {
            category: 'Catering',
            summary_es: 'Para catering.',
            providers: [
              {
                provider_id: 999,
                rationale_es: 'No debe renderizarse.',
                caveat_es: null,
              },
            ],
          },
        ],
        next_step_es: 'Revisemos el primer frente.',
      };

      const result = renderer.render({ message, providerResults: [] });

      expect(result).toBe('Encontré opciones para comparar.\n\nRevisemos el primer frente.');
    });

    it('does not render a provider under a mismatched need category', () => {
      const message: StructuredMessage = {
        type: 'multi_need_recommendation',
        intro_es: 'Encontré opciones para comparar.',
        needs: [
          {
            category: 'Locales',
            summary_es: 'Para el local.',
            providers: [
              {
                provider_id: 1,
                rationale_es: 'No corresponde a esta categoría.',
                caveat_es: null,
              },
            ],
          },
        ],
        next_step_es: 'Revisemos el primer frente.',
      };

      const result = renderer.render({
        message,
        providerResults: [createProvider({ category: 'Catering' })],
      });

      expect(result).toBe('Encontré opciones para comparar.\n\nRevisemos el primer frente.');
      expect(result).not.toContain('No corresponde a esta categoría.');
    });
  });

  describe('generic messages', () => {
    it('renders paragraphs without generated actions', () => {
      const message: StructuredMessage = {
        type: 'generic',
        paragraphs_es: ['Primera parte del mensaje.', 'Segunda parte.'],
      };

      const result = renderer.render({ message, providerResults: [] });

      expect(result).toContain('Primera parte del mensaje.');
      expect(result).toContain('Segunda parte.');
      expect(result).not.toContain('Ajustar criterios');
    });
  });

  describe('no Markdown output', () => {
    it('never outputs raw asterisks', () => {
      const provider = createProvider();
      const message: StructuredMessage = {
        type: 'recommendation',
        intro_es: 'Opciones:',
        providers: [
          { provider_id: 1, rationale_es: 'Razón.', caveat_es: null },
        ],
      };

      const result = renderer.render({ message, providerResults: [provider] });

      expect(result).not.toContain('**');
    });

    it('never outputs underscores or backticks', () => {
      const message: StructuredMessage = {
        type: 'generic',
        paragraphs_es: ['Texto de ejemplo.'],
      };

      const result = renderer.render({ message, providerResults: [] });

      expect(result).not.toContain('`');
    });
  });
});
