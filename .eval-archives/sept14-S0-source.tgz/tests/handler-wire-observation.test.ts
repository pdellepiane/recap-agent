import { describe, expect, it } from 'vitest';

import { hashPrivateOutput, observeOutputOrigin } from '../src/audit/output-origin';
import {
  lambdaTurnResponseSchema,
} from '../src/evals/case-schema';
import { independentlyObserveWireOutput } from '../src/evals/targets/live-lambda';
import { buildCliResponseBody } from '../src/lambda/handler';
import { createEmptyPlan } from '../src/core/plan';
import type { HandleTurnResponse } from '../src/runtime/agent-service';

const SENSITIVE_TEXT =
  'Tu referencia es ABC-123, escribe a persona@example.com o llama al +51973296571 con el codigo 847261.';

function sensitiveResponse(): HandleTurnResponse {
  const plan = createEmptyPlan({
    planId: 'wire-plan',
    channel: 'terminal_whatsapp',
    externalUserId: 'wire-user',
  });
  return {
    outbound: {
      text: SENSITIVE_TEXT,
      outputOrigin: observeOutputOrigin({
        candidateText: SENSITIVE_TEXT,
        deliveredText: SENSITIVE_TEXT,
        transformationVersion: 'transport-v1',
      }),
      delivery: { action: 'send', reason: 'reply_composed' },
      conversationId: 'conversation-wire',
    },
    plan,
    trace: validTrace(),
  } as unknown as HandleTurnResponse;
}

function suppressedResponse(): HandleTurnResponse {
  const plan = createEmptyPlan({
    planId: 'wire-silence-plan',
    channel: 'terminal_whatsapp',
    externalUserId: 'wire-silence-user',
  });
  return {
    outbound: {
      text: null,
      delivery: { action: 'suppress', reason: 'human_escalation_active' },
      conversationId: 'conversation-wire-silence',
    },
    plan,
    trace: validTrace(),
  } as unknown as HandleTurnResponse;
}

describe('handler-to-live-target wire observation', () => {
  it('verifies the original text before artifact redaction', () => {
    const body = buildCliResponseBody({
      response: sensitiveResponse(),
      perf: null,
      includeDiagnostics: true,
    });

    const redacted = body.message as string | null;
    expect(typeof redacted).toBe('string');
    expect(redacted).not.toContain('persona@example.com');
    expect(redacted).not.toContain('+51973296571');
    expect(redacted).not.toContain('847261');
    expect(body.message_original_sha256).toBe(hashPrivateOutput(SENSITIVE_TEXT));
    expect(body.message_redaction_applied).toBe(true);

    const parsed = lambdaTurnResponseSchema.parse(body);
    const observed = independentlyObserveWireOutput(parsed.message, parsed.output_origin, {
      originalSha256: parsed.message_original_sha256 ?? undefined,
      redactionApplied: parsed.message_redaction_applied ?? false,
    });
    expect(observed.status).toBe('verified');
    expect(observed.mismatchFields).toEqual([]);
    expect(observed.deliveredSha256).toBe(hashPrivateOutput(SENSITIVE_TEXT));
  });

  it('documents that hashing the redacted text alone cannot prove provenance', () => {
    const body = buildCliResponseBody({
      response: sensitiveResponse(),
      perf: null,
      includeDiagnostics: true,
    });
    const parsed = lambdaTurnResponseSchema.parse(body);
    const withoutWire = independentlyObserveWireOutput(parsed.message, parsed.output_origin);
    expect(withoutWire.status).toBe('mismatch');
    expect(withoutWire.mismatchFields).toContain('delivered_sha256');
  });

  it('keeps null output null and never presents it as verified', () => {
    const body = buildCliResponseBody({
      response: suppressedResponse(),
      perf: null,
      includeDiagnostics: true,
    });

    expect(body.message).toBeNull();
    expect(body.message_original_sha256).toBeNull();
    expect(body.message_redaction_applied).toBe(true);
    expect(() => lambdaTurnResponseSchema.parse(body)).not.toThrow();

    const parsed = lambdaTurnResponseSchema.parse(body);
    const wireOriginal = parsed.message_original_sha256 === undefined
      ? undefined
      : parsed.message_original_sha256;
    const observed = independentlyObserveWireOutput(parsed.message, parsed.output_origin, {
      originalSha256: wireOriginal,
      redactionApplied: parsed.message_redaction_applied ?? false,
    });
    expect(observed.status).toBe('missing');
    expect(observed.deliveredSha256).toBeNull();
  });

  it('leaves the original text untouched without diagnostics', () => {
    const body = buildCliResponseBody({
      response: sensitiveResponse(),
      perf: null,
      includeDiagnostics: false,
    });

    expect(body.message).toBe(SENSITIVE_TEXT);
    expect(body.message_original_sha256).toBe(hashPrivateOutput(SENSITIVE_TEXT));
    expect(body.message_redaction_applied).toBe(false);
  });
});

function validTrace() {
  return {
    trace_id: 'trace-wire',
    conversation_id: 'conversation-wire',
    plan_id: 'wire-plan',
    previous_node: 'contacto_inicial',
    next_node: 'deteccion_intencion',
    node_path: ['contacto_inicial', 'deteccion_intencion'],
    intent: null,
    missing_fields: [],
    search_ready: false,
    prompt_bundle_id: 'bundle-wire',
    prompt_file_paths: [],
    tools_considered: [],
    tools_called: [],
    tool_inputs: [],
    tool_outputs: [],
    provider_results: [],
    recommendation_funnel: {
      available_candidates: 0,
      context_candidates: 0,
      context_candidate_ids: [],
      presentation_limit: 5,
    },
    search_strategy: 'none',
    close_action_summary: { type: null, category: null, reason_preview: null },
    selection_resolution_summary: {
      selected_provider_references: [],
      selected_provider_hints_count: 0,
      provider_plan_operation_types: [],
      provider_plan_operation_categories: [],
    },
    contact_validation_summary: {
      status: 'not_provided',
      field: null,
      reason_preview: null,
      extraction_contact_fields_present: { name: false, email: false, phone: false },
      plan_contact_fields_present: { name: false, email: false, phone: false },
    },
    provider_candidate_audit: [],
    information_execution_summary: [],
    plan_persisted: true,
    plan_persist_reason: null,
    timing_ms: {
      total: 1,
      load_plan: 0,
      prepare_working_plan: 0,
      extraction: 0,
      apply_extraction: 0,
      compute_sufficiency: 0,
      provider_search: 0,
      provider_enrichment: 0,
      prompt_bundle_load: 0,
      compose_reply: 1,
      save_plan: 0,
    },
    token_usage: { extraction: null, reply: null, total: null },
  };
}
