import { describe, expect, it } from 'vitest';

import type { ComposeReplyResult } from '../src/runtime/contracts';
import type { StructuredMessage } from '../src/runtime/structured-message';
import type { ProviderSummary } from '../src/core/provider';
import { WhatsAppMessageRenderer } from '../src/runtime/message-renderer';
import {
  applyDocumentedTransportTransforms,
  assertModelOrigin,
  buildModelOriginReceipt,
  canonicalModelContent,
  deliveredContainsModelSpans,
  hashCanonicalModelContent,
  modelProviderIdsOf,
  modelSpansOf,
  snapshotProviderFields,
  ModelOriginViolationError,
} from '../src/runtime/model-composition';

const WELCOME_SPANS = {
  greeting_es: 'Hola, soy el faro verde de prueba.',
  scope_es: 'Te ayudo con tu evento y el ancla azul.',
  ask_es: '¿Qué necesitas hoy?',
};

const RECOMMENDATION_SPANS = {
  intro_es: 'Encontré el puente amarillo de siete tablones.',
  match_label_es: 'La mejor coincidencia para tu fecha.',
  rationale_es: 'Coincide con tu presupuesto y fecha.',
  caveat_es: 'Requiere reserva anticipada.',
};

function replyWith(message: StructuredMessage): ComposeReplyResult {
  return { text: '', structuredMessage: message };
}

function providerResult(overrides: Partial<ProviderSummary> = {}): ProviderSummary {
  return {
    id: 7,
    title: 'Casa Faro',
    slug: null,
    category: 'Locales',
    location: 'Lima',
    priceLevel: 'mid',
    rating: '4.8',
    reason: 'Motivo mecánico.',
    detailUrl: null,
    websiteUrl: null,
    minPrice: null,
    maxPrice: null,
    promoBadge: null,
    promoSummary: null,
    descriptionSnippet: null,
    serviceHighlights: [],
    termsHighlights: [],
    providerNotes: [],
    eventTypes: [],
    description: null,
    fitScore: null,
    fitWarnings: [],
    fitTags: [],
    retrievalScore: 0.9,
    retrievalSource: 'hybrid',
    ...overrides,
  };
}

function recommendationMessage(): StructuredMessage {
  return {
    type: 'recommendation',
    intro_es: RECOMMENDATION_SPANS.intro_es,
    providers: [{
      provider_id: 7,
      match_label_es: null,
      rationale_es: RECOMMENDATION_SPANS.rationale_es,
      caveat_es: RECOMMENDATION_SPANS.caveat_es,
    }],
  };
}

function labeledRecommendationMessage(): StructuredMessage {
  return {
    type: 'recommendation',
    intro_es: RECOMMENDATION_SPANS.intro_es,
    providers: [{
      provider_id: 7,
      match_label_es: RECOMMENDATION_SPANS.match_label_es,
      rationale_es: RECOMMENDATION_SPANS.rationale_es,
      caveat_es: RECOMMENDATION_SPANS.caveat_es,
    }],
  };
}

describe('structured-output origin spans', () => {
  it('traces welcome spans instead of refusing a receipt', () => {
    const spans = modelSpansOf({ type: 'welcome', ...WELCOME_SPANS });
    expect(spans).toEqual([
      WELCOME_SPANS.greeting_es,
      WELCOME_SPANS.scope_es,
      WELCOME_SPANS.ask_es,
    ]);
    const receipt = buildModelOriginReceipt(replyWith({ type: 'welcome', ...WELCOME_SPANS }), 'bundle-w');
    expect(receipt?.modelParagraphs).toEqual(spans);
  });

  it('traces planning spans in render order including match labels', () => {
    const spans = modelSpansOf(recommendationMessage());
    expect(spans).toEqual([
      RECOMMENDATION_SPANS.intro_es,
      RECOMMENDATION_SPANS.rationale_es,
      RECOMMENDATION_SPANS.caveat_es,
    ]);
    expect(modelSpansOf(labeledRecommendationMessage())).toEqual([
      RECOMMENDATION_SPANS.intro_es,
      RECOMMENDATION_SPANS.match_label_es,
      RECOMMENDATION_SPANS.rationale_es,
      RECOMMENDATION_SPANS.caveat_es,
    ]);
    const multi = modelSpansOf({
      type: 'multi_need_recommendation',
      intro_es: 'Intro multi.',
      needs: [{
        category: 'Locales',
        summary_es: 'Resumen del frente.',
        providers: [{
          provider_id: 9,
          match_label_es: 'Etiqueta del frente.',
          rationale_es: 'Ideal por ubicación.',
          caveat_es: null,
        }],
      }],
      next_step_es: 'Dime cuál prefieres.',
    });
    expect(multi).toEqual([
      'Intro multi.',
      'Resumen del frente.',
      'Etiqueta del frente.',
      'Ideal por ubicación.',
      'Dime cuál prefieres.',
    ]);
  });

  it('snapshots raw model output plus authorized provider fields with distinct hashes', () => {
    const message = recommendationMessage();
    const providers = [providerResult()];
    const receipt = buildModelOriginReceipt(replyWith(message), 'bundle-r', providers);
    expect(receipt?.modelMessage).toEqual(message);
    expect(receipt?.modelMessage).not.toBe(message);
    expect(receipt?.providerFields).toEqual(snapshotProviderFields(providers));
    const canonical = canonicalModelContent(message);
    expect(canonical).not.toBeNull();
    expect(receipt?.modelContentSha256).toBe(hashCanonicalModelContent(canonical as string));
    expect(modelProviderIdsOf(message)).toEqual([7]);
  });

  it('never fabricates a receipt from empty or mechanical-only content', () => {
    expect(modelSpansOf({ type: 'welcome' })).toBeNull();
    expect(modelSpansOf(undefined)).toBeNull();
    expect(buildModelOriginReceipt(replyWith({ type: 'welcome' }), 'bundle-w')).toBeNull();
    expect(buildModelOriginReceipt({ text: 'legado' }, 'bundle-x')).toBeNull();
  });

  it('accepts mechanically rendered delivery that keeps every span in order', () => {
    const message: StructuredMessage = { type: 'welcome', ...WELCOME_SPANS };
    const reply = replyWith(message);
    const origin = buildModelOriginReceipt(reply, 'bundle-w');
    const delivered = applyDocumentedTransportTransforms(
      new WhatsAppMessageRenderer().render({ message, providerResults: [] }),
    );
    expect(deliveredContainsModelSpans({ spans: origin?.modelParagraphs ?? [], deliveredText: delivered })).toBe(true);
    expect(() => assertModelOrigin({ origin, reply, deliveredText: delivered })).not.toThrow();
  });

  it('accepts a rendered recommendation whose provider cards surround the spans', () => {
    const message = recommendationMessage();
    const providers = [providerResult()];
    const reply = replyWith(message);
    const origin = buildModelOriginReceipt(reply, 'bundle-r', providers);
    const delivered = applyDocumentedTransportTransforms(
      new WhatsAppMessageRenderer().render({ message, providerResults: providers }),
    );
    expect(delivered).toContain(RECOMMENDATION_SPANS.intro_es);
    expect(() => assertModelOrigin({
      origin,
      reply,
      deliveredText: delivered,
      providerResults: providers,
    })).not.toThrow();
  });

  it('accepts a labeled single recommendation through full-render equality', () => {
    const message = labeledRecommendationMessage();
    const providers = [providerResult()];
    const reply = replyWith(message);
    const origin = buildModelOriginReceipt(reply, 'bundle-r', providers);
    const delivered = applyDocumentedTransportTransforms(
      new WhatsAppMessageRenderer().render({ message, providerResults: providers }),
    );
    expect(() => assertModelOrigin({
      origin,
      reply,
      deliveredText: delivered,
      providerResults: providers,
    })).not.toThrow();
  });

  it('accepts a rendered multi-need recommendation with verified provider ids', () => {
    const message: StructuredMessage = {
      type: 'multi_need_recommendation',
      intro_es: 'Intro multi.',
      needs: [{
        category: 'Locales',
        summary_es: 'Resumen del frente.',
        providers: [{
          provider_id: 9,
          match_label_es: null,
          rationale_es: 'Ideal por ubicación.',
          caveat_es: null,
        }],
      }],
      next_step_es: 'Dime cuál prefieres.',
    };
    const providers = [providerResult({ id: 9, title: 'Salón Norte' })];
    const reply = replyWith(message);
    const origin = buildModelOriginReceipt(reply, 'bundle-m', providers);
    const delivered = applyDocumentedTransportTransforms(
      new WhatsAppMessageRenderer().render({ message, providerResults: providers }),
    );
    expect(() => assertModelOrigin({
      origin,
      reply,
      deliveredText: delivered,
      providerResults: providers,
    })).not.toThrow();
  });

  it('fails when a span is dropped or reordered by post-generation code', () => {
    const reply = replyWith({ type: 'welcome', ...WELCOME_SPANS });
    const origin = buildModelOriginReceipt(reply, 'bundle-w');
    const dropped = `${WELCOME_SPANS.greeting_es}\n\n${WELCOME_SPANS.ask_es}`;
    expect(() => assertModelOrigin({ origin, reply, deliveredText: dropped })).toThrow(
      ModelOriginViolationError,
    );
    const replaced = {
      ...reply,
      structuredMessage: {
        type: 'welcome' as const,
        greeting_es: 'Texto fijo de respaldo.',
        scope_es: WELCOME_SPANS.scope_es,
        ask_es: WELCOME_SPANS.ask_es,
      },
    };
    expect(() => assertModelOrigin({
      origin,
      reply: replaced,
      deliveredText: 'Texto fijo de respaldo.',
    })).toThrow(ModelOriginViolationError);
  });

  it('fails when surrounding text is injected around intact spans', () => {
    const message = recommendationMessage();
    const providers = [providerResult()];
    const reply = replyWith(message);
    const origin = buildModelOriginReceipt(reply, 'bundle-r', providers);
    const pristine = applyDocumentedTransportTransforms(
      new WhatsAppMessageRenderer().render({ message, providerResults: providers }),
    );
    const injected = `${pristine}\n\nOferta especial: llama ahora mismo.`;
    expect(deliveredContainsModelSpans({
      spans: origin?.modelParagraphs ?? [],
      deliveredText: injected,
    })).toBe(true);
    expect(() => assertModelOrigin({
      origin,
      reply,
      deliveredText: injected,
      providerResults: providers,
    })).toThrow(ModelOriginViolationError);
  });

  it('fails when a match label is changed after generation', () => {
    const message = labeledRecommendationMessage();
    const providers = [providerResult()];
    const reply = replyWith(message);
    const origin = buildModelOriginReceipt(reply, 'bundle-r', providers);
    const mutated = replyWith({
      type: 'recommendation',
      intro_es: RECOMMENDATION_SPANS.intro_es,
      providers: [{
        provider_id: 7,
        match_label_es: 'Etiqueta reescrita por codigo.',
        rationale_es: RECOMMENDATION_SPANS.rationale_es,
        caveat_es: RECOMMENDATION_SPANS.caveat_es,
      }],
    });
    const delivered = applyDocumentedTransportTransforms(
      new WhatsAppMessageRenderer().render({
        message: mutated.structuredMessage as StructuredMessage,
        providerResults: providers,
      }),
    );
    expect(() => assertModelOrigin({
      origin,
      reply: mutated,
      deliveredText: delivered,
      providerResults: providers,
    })).toThrow(ModelOriginViolationError);
  });

  it('fails when provider ids are swapped or ungrounded', () => {
    const message = recommendationMessage();
    const providers = [providerResult()];
    const reply = replyWith(message);
    const origin = buildModelOriginReceipt(reply, 'bundle-r', providers);
    const swapped = replyWith({
      type: 'recommendation',
      intro_es: RECOMMENDATION_SPANS.intro_es,
      providers: [{
        provider_id: 77,
        match_label_es: RECOMMENDATION_SPANS.match_label_es,
        rationale_es: RECOMMENDATION_SPANS.rationale_es,
        caveat_es: RECOMMENDATION_SPANS.caveat_es,
      }],
    });
    const swappedProviders = [providerResult({ id: 77, title: 'Otro local' })];
    const delivered = applyDocumentedTransportTransforms(
      new WhatsAppMessageRenderer().render({
        message: swapped.structuredMessage as StructuredMessage,
        providerResults: swappedProviders,
      }),
    );
    expect(() => assertModelOrigin({
      origin,
      reply: swapped,
      deliveredText: delivered,
      providerResults: swappedProviders,
    })).toThrow(ModelOriginViolationError);
    expect(() => assertModelOrigin({
      origin,
      reply,
      deliveredText: applyDocumentedTransportTransforms(
        new WhatsAppMessageRenderer().render({ message, providerResults: providers }),
      ),
      providerResults: [],
    })).toThrow(ModelOriginViolationError);
  });

  it('fails closed on unknown transformation versions and tampered receipts', () => {
    const message = recommendationMessage();
    const providers = [providerResult()];
    const reply = replyWith(message);
    const origin = buildModelOriginReceipt(reply, 'bundle-r', providers);
    const delivered = applyDocumentedTransportTransforms(
      new WhatsAppMessageRenderer().render({ message, providerResults: providers }),
    );
    expect(() => assertModelOrigin({
      origin: origin === null ? origin : { ...origin, transformationVersion: 'transport-v9' as never },
      reply,
      deliveredText: delivered,
      providerResults: providers,
    })).toThrow(ModelOriginViolationError);
    expect(() => assertModelOrigin({
      origin: origin === null ? origin : {
        ...origin,
        modelMessage: {
          type: 'recommendation' as const,
          intro_es: 'Texto reescrito en el recibo.',
          providers: [],
        },
      },
      reply,
      deliveredText: delivered,
      providerResults: providers,
    })).toThrow(ModelOriginViolationError);
  });
});
