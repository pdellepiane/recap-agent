import fs from 'node:fs';
import path from 'node:path';

import { describe, expect, it } from 'vitest';

import { createEmptyPlan, mergePlan } from '../src/core/plan';
import type {
  AgentConversationMessage,
  AgentConversationGateway,
  AgentGatewayResult,
  AgentEventDetailResult,
  AgentGuestEventsResult,
  AgentGuestRsvpInput,
  AgentGuestRsvpResult,
  AgentMessageLogInput,
} from '../src/runtime/agent-conversation-gateway';
import { AgentService } from '../src/runtime/agent-service';
import type {
  AgentRuntime,
  ComposeReplyRequest,
  ComposeReplyResult,
  ExtractRequest,
  ExtractionResult,
} from '../src/runtime/contracts';
import { WhatsAppMessageRenderer } from '../src/runtime/message-renderer';
import { PromptLoader } from '../src/runtime/prompt-loader';
import {
  buildRuntimeCapabilityManifest,
  type RuntimeCapabilityManifest,
} from '../src/runtime/capability-manifest';
import type {
  ProviderGateway,
  UserEventLookupResult,
} from '../src/runtime/provider-gateway';
import { InMemoryPlanStore } from '../src/storage/in-memory-plan-store';

describe('AgentService RSVP flow', () => {
  it('a current state query neither inherits an old action nor offers another mutation', async () => {
    const store = new InMemoryPlanStore();
    const input = inbound('Consulta mi asistencia; no cambies mi respuesta');
    await store.save({ reason: 'fixture', plan: mergePlan(createEmptyPlan({
      planId: 'read-only-rsvp', channel: input.channel, externalUserId: input.externalUserId,
    }), { current_node: 'responder_invitacion', rsvp_state: {
      status: 'awaiting_event_selection', pending_action: 'attending', pending_plus_one_response: 'yes',
      candidates: [{ guest_id: 41, event_name: 'Matrimonio de Ana y Luis', event_date: null }],
      requested_at: '2026-09-01T15:00:00.000Z', selection_attempts: 0,
    } }) });
    const runtime = new RsvpRuntime([rsvpExtraction({ action: null, decisionSource: 'current_message', eventReference: 'Matrimonio de Ana y Luis' })]);
    const result = await createService(runtime, new RsvpGateway([]), store, [
      rsvpLookupInvitation({ guestId: 41, eventName: 'Matrimonio de Ana y Luis', hasResponded: false }),
    ]).handleTurn(input);
    expect(result.trace.tools_called).not.toContain('guest_rsvp');
    expect(result.plan.rsvp_state.status).toBe('none');
    expect(result.plan.rsvp_state.pending_action).toBeNull();
    expect(result.plan.rsvp_state.pending_plus_one_response).toBeNull();
    expect(runtime.composeRequests[0]?.errorMessage).not.toContain('Pregunta');
    expect(runtime.composeRequests[0]?.errorMessage).toContain('"invitation_state":"pending"');
  });
  it('allows an explicit RSVP topic switch despite a pending host-support question', async () => {
    const store = new InMemoryPlanStore();
    const input = inbound('Ahora quiero consultar mi asistencia a Matrimonio de Ana y Luis');
    await store.save({ reason: 'fixture', plan: mergePlan(createEmptyPlan({
      planId: 'host-to-rsvp', channel: input.channel, externalUserId: input.externalUserId,
    }), { current_node: 'resolver_consultas_informativas', information_state: {
      resume_node: null, pending_requests: [{ requestId: 'host', kind: 'faq',
        query: 'Retiro de fondos no recibido', hostWithdrawal: 'individual_status' }],
      selection_candidates: [], last_completed_request: null,
    } }) });
    const runtime = new RsvpRuntime([rsvpExtraction({ action: null, decisionSource: 'current_message', eventReference: 'Matrimonio de Ana y Luis' })]);
    const gateway = new RsvpGateway([]);
    const result = await createService(runtime, gateway, store).handleTurn(input);
    expect(result.trace.route_kind).toBe('rsvp');
    expect(result.trace.tools_called).toContain('lookup_rsvp_invitations');
    expect(result.trace.tools_called).not.toContain('guest_rsvp');
  });

  it('reconciles a read-only RSVP continuation before a development write boundary', async () => {
    const runtime = new RsvpRuntime([{
      ...rsvpExtraction({
        action: null,
        decisionSource: 'current_message',
        eventReference: 'Matrimonio de Ana y Luis',
      }),
      requestedOperation: 'rsvp.response.write',
    }]);
    const gateway = new RsvpGateway([]);
    const manifest = {
      ...buildRuntimeCapabilityManifest({
        configured: true,
        environment: 'development',
        allowCustomerWrites: false,
        featureFlags: { rsvp: true },
      }),
    } satisfies RuntimeCapabilityManifest;
    const result = await createService(
      runtime,
      gateway,
      new InMemoryPlanStore(),
      [rsvpLookupInvitation({ hasResponded: true, willAttend: true })],
      undefined,
      manifest,
    ).handleTurn(inbound('Hola, ya confirmé, gracias'));

    expect(result.trace.route_kind).toBe('rsvp');
    expect(result.trace.tools_called).toContain('lookup_rsvp_invitations');
    expect(result.trace.tools_called).not.toContain('guest_rsvp');
    expect(gateway.inputs).toEqual([]);
    expect(result.outbound.text).toBe('RSVP_MODEL_SENTINEL');
  });

  it('treats guest records with no event identity as unavailable, not as no invitation', async () => {
    const runtime = new RsvpRuntime([rsvpExtraction({ action: null })]);
    const gateway = new RsvpGateway([]);
    const result = await createService(runtime, gateway, new InMemoryPlanStore(), [
      { ...rsvpLookupInvitation({}), eventId: null, name: null },
    ]).handleTurn(inbound('¿Cuál es el estado de mis invitaciones?'));
    expect(result.trace.tools_called).not.toContain('guest_rsvp');
    expect(runtime.composeRequests[0]?.errorMessage).toContain('"outcome":"invitation_lookup_failed"');
  });
  it('keeps immediate RSVP changes in the RSVP-only prompt bundle', () => {
    const systemPrompt = fs.readFileSync(
      path.resolve(process.cwd(), 'prompts/nodes/responder_invitacion/system.txt'),
      'utf8',
    );
    expect(systemPrompt).toContain(
      'registra el cambio en ese turno',
    );
    expect(systemPrompt).not.toContain(
      'pide una sola confirmación antes de ejecutar el cambio',
    );
  });

  it.each([
    ['attending', '"outcome":"mutation_result"'],
    ['declining', '"outcome":"mutation_result"'],
  ] as const)('records an explicit %s response using only the trusted channel phone', async (
    action,
    expectedNote,
  ) => {
    const runtime = new RsvpRuntime([rsvpExtraction({ action })]);
    const gateway = new RsvpGateway([{
      status: 'responded',
      action,
      willAttend: action === 'attending',
      guestId: 41,
      eventName: 'Matrimonio de Ana y Luis',
      eventDate: '2026-09-12',
    }]);
    const service = createService(runtime, gateway);

    const result = await service.handleTurn(inbound('Confirmo mi respuesta'));

    expect(gateway.inputs).toEqual([{
      phone_extension: '+51',
      phone_number: '973296571',
      action,
      guest_id: 41,
    }]);
    expect(result.plan.current_node).toBe('responder_invitacion');
    expect(result.plan.rsvp_state.status).toBe('none');
    expect(result.plan.user_auth.status).toBe('none');
    expect(result.trace.route_kind).toBe('rsvp');
    expect(result.trace.tools_called).toContain('guest_rsvp');
    expect(result.trace.tools_called).toContain('lookup_guest_events_by_phone');
    expect(gateway.guestEventLookupCalls).toBe(1);
    expect(result.trace.timing_ms.rsvp_execution).toBeTypeOf('number');
    expect(runtime.composeRequests[0]?.errorMessage).toContain(expectedNote);
    expect(runtime.composeRequests[0]?.errorMessage).not.toContain('correo');
    expect(runtime.composeRequests[0]?.rsvpPhoneEvidence).toMatchObject({
      state: 'resolved_single',
      coverage: 'complete',
      resolution: 'authoritative_invitation',
      event: {
        event_name: 'Matrimonio de Ana y Luis',
        invitation_record: 'available',
        rsvp_state: action,
      },
    });
  });

  it('records one companion together with the guest without human escalation', async () => {
    const runtime = new RsvpRuntime([rsvpExtraction({
      action: 'attending',
      party: {
        scope: 'self_and_others',
        mentioned_names: ['María'],
        companion_count: 'one',
        plus_one_response: 'yes',
      },
    })]);
    const gateway = new RsvpGateway([{
      status: 'responded',
      action: 'attending',
      willAttend: true,
      guestId: 41,
      eventName: 'Matrimonio de Ana y Luis',
      eventDate: '2026-09-12',
      plusOne: { saved: true, response: 'yes', reason: null },
    }]);
    const service = createService(runtime, gateway);

    const result = await service.handleTurn(inbound('Confirmo mi asistencia y la de mi esposa María'));

    expect(gateway.inputs).toEqual([{
      phone_extension: '+51',
      phone_number: '973296571',
      action: 'attending',
      guest_id: 41,
      plus_one_response: 'yes',
    }]);
    expect(result.trace.tools_called).not.toContain('request_human_takeover');
    expect(result.outbound.text).toBe('RSVP_MODEL_SENTINEL');
    expect(runtime.composeRequests[0]?.errorMessage).toContain('"response":"yes"');
  });

  it('does not claim companion success when the backend declines to save it', async () => {
    const runtime = new RsvpRuntime([rsvpExtraction({
      action: null,
      party: {
        scope: 'self_and_others',
        mentioned_names: [],
        companion_count: 'one',
        plus_one_response: 'yes',
      },
    })]);
    const gateway = new RsvpGateway([{
      status: 'responded',
      action: null,
      willAttend: null,
      guestId: 41,
      eventName: 'Matrimonio de Ana y Luis',
      eventDate: '2026-09-12',
      plusOne: { saved: false, response: 'yes', reason: 'not_eligible' },
    }]);
    const service = createService(runtime, gateway, new InMemoryPlanStore(), [
      rsvpLookupInvitation({ hasResponded: true, willAttend: true }),
    ]);

    const result = await service.handleTurn(inbound('También irá mi acompañante'));

    expect(gateway.inputs).toEqual([{
      phone_extension: '+51',
      phone_number: '973296571',
      guest_id: 41,
      plus_one_response: 'yes',
    }]);
    expect(result.outbound.text).toBe('RSVP_MODEL_SENTINEL');
    expect(runtime.composeRequests[0]?.errorMessage).toContain('"saved":false');
    expect(runtime.composeRequests[0]?.errorMessage).not.toContain('not_eligible');
    expect(result.trace.tools_called).not.toContain('request_human_takeover');
  });

  it('preserves a companion response across one bounded event-selection turn', async () => {
    const runtime = new RsvpRuntime([
      rsvpExtraction({
        action: null,
        party: {
          scope: 'self_and_others',
          mentioned_names: [],
          companion_count: 'one',
          plus_one_response: 'yes',
        },
      }),
      rsvpExtraction({
        action: null,
        candidateGuestId: 42,
        eventReference: 'Cumpleaños de Marta',
      }),
    ]);
    const gateway = new RsvpGateway([{
      status: 'responded',
      action: null,
      willAttend: null,
      guestId: 42,
      eventName: 'Cumpleaños de Marta',
      eventDate: null,
      plusOne: { saved: true, response: 'yes', reason: null },
    }]);
    const store = new InMemoryPlanStore();
    const service = createService(runtime, gateway, store, [
      rsvpLookupInvitation({ guestId: 41, eventName: 'Matrimonio de Ana y Luis' }),
      rsvpLookupInvitation({ guestId: 42, eventName: 'Cumpleaños de Marta' }),
    ]);

    const first = await service.handleTurn(inbound('También asistirá mi acompañante'));
    const second = await service.handleTurn(inbound('Al cumpleaños de Marta'));

    expect(first.plan.rsvp_state).toMatchObject({
      status: 'awaiting_event_selection',
      pending_plus_one_response: 'yes',
    });
    expect(gateway.inputs).toEqual([{
      phone_extension: '+51',
      phone_number: '973296571',
      guest_id: 42,
      plus_one_response: 'yes',
    }]);
    expect(second.outbound.text).toBe('RSVP_MODEL_SENTINEL');
    expect(runtime.composeRequests[1]?.errorMessage).toContain('"response":"yes"');
  });

  it('persists multiple pending candidates and re-calls with only a validated selection', async () => {
    const runtime = new RsvpRuntime([
      rsvpExtraction({ action: 'attending' }),
      rsvpExtraction({
        action: null,
        candidateGuestId: 42,
        eventReference: 'Cumpleaños de Marta',
      }),
    ]);
    const gateway = new RsvpGateway([
      {
        status: 'responded',
        action: 'attending',
        willAttend: true,
        guestId: 42,
        eventName: 'Cumpleaños de Marta',
        eventDate: null,
      },
    ]);
    const store = new InMemoryPlanStore();
    const invitations = [
      rsvpLookupInvitation({ guestId: 41, eventName: 'Matrimonio de Ana y Luis' }),
      rsvpLookupInvitation({ guestId: 42, eventName: 'Cumpleaños de Marta' }),
    ];
    const service = createService(runtime, gateway, store, invitations);

    const first = await service.handleTurn(inbound('Sí, asistiré'));
    const second = await service.handleTurn(inbound('Al cumpleaños de Marta'));

    expect(first.plan.rsvp_state).toMatchObject({
      status: 'awaiting_event_selection',
      pending_action: 'attending',
      selection_attempts: 0,
    });
    expect(first.plan.rsvp_state.candidates).toHaveLength(2);
    expect(gateway.inputs[0]).toEqual({
      phone_extension: '+51',
      phone_number: '973296571',
      action: 'attending',
      guest_id: 42,
    });
    expect(second.plan.rsvp_state.status).toBe('none');
    expect(runtime.composeRequests[0]?.plan.rsvp_state.candidates).toHaveLength(2);
  });

  it('keeps an ambiguous RSVP continuation in selection state and renders grounded candidates', async () => {
    const store = new InMemoryPlanStore();
    const input = inbound('Ese.');
    await store.save({
      reason: 'seed-rsvp-selection',
      plan: mergePlan(createEmptyPlan({
        planId: 'plan-rsvp-ambiguous',
        channel: input.channel,
        externalUserId: input.externalUserId,
      }), {
        current_node: 'responder_invitacion',
        contact_phone: '51973296571',
        contact_phone_extension: '+51',
        contact_phone_number: '973296571',
        rsvp_state: {
          status: 'awaiting_event_selection',
          pending_action: 'attending',
          pending_plus_one_response: null,
          candidates: [
            {
              guest_id: 41,
              event_name: 'Matrimonio de Ana y Luis',
              event_date: '2026-09-12',
            },
            {
              guest_id: 42,
              event_name: 'Cumpleaños de Marta',
              event_date: '2026-09-19',
            },
          ],
          requested_at: '2026-08-13T15:00:00.000Z',
          selection_attempts: 0,
        },
      }),
    });
    const runtime = new RsvpRuntime([rsvpExtraction({
      action: null,
      decisionSource: 'current_message',
    })]);
    const gateway = new RsvpGateway([], [campaignMessage('Matrimonio de Ana y Luis')]);
    const service = createService(runtime, gateway, store, [
      { ...rsvpLookupInvitation({ guestId: 41, eventName: 'Matrimonio de Ana y Luis' }), eventId: 205 },
      { ...rsvpLookupInvitation({ guestId: 42, eventName: 'Cumpleaños de Marta' }), eventId: 206, datetime: '2026-09-19' },
    ]);

    const result = await service.handleTurn(input);

    expect(result.plan.rsvp_state).toMatchObject({
      status: 'awaiting_event_selection',
      pending_action: 'attending',
      selection_attempts: 1,
    });
    expect(gateway.inputs).toEqual([]);
    expect(result.trace.tools_called).not.toContain('guest_rsvp');
    expect(result.outbound.text).toBe('RSVP_MODEL_SENTINEL');
    expect(runtime.composeRequests[0]?.rsvpPhoneEvidence).toEqual({
      state: 'needs_event_selection',
      coverage: 'complete',
      resolution: 'authoritative_invitation',
      candidates: [
        {
          event_name: 'Matrimonio de Ana y Luis',
          event_date: '2026-09-12',
          invitation_record: 'available',
          rsvp_state: 'pending',
        },
        {
          event_name: 'Cumpleaños de Marta',
          event_date: '2026-09-19',
          invitation_record: 'available',
          rsvp_state: 'pending',
        },
      ],
    });
  });

  it('never calls the mutation when the extracted guest id is not a stored candidate', async () => {
    const runtime = new RsvpRuntime([rsvpExtraction({
      action: null,
      candidateGuestId: 999,
      eventReference: 'Ese evento',
    })]);
    const gateway = new RsvpGateway([]);
    const store = new InMemoryPlanStore();
    await store.save({
      reason: 'seed-rsvp',
      plan: mergePlan(createEmptyPlan({
        planId: 'plan-rsvp-seeded',
        channel: 'whatsapp',
        externalUserId: 'user-rsvp',
      }), {
        contact_phone: '51973296571',
        contact_phone_extension: '+51',
        contact_phone_number: '973296571',
        current_node: 'responder_invitacion',
        rsvp_state: {
          status: 'awaiting_event_selection',
          pending_action: 'declining',
          candidates: [
            {
              guest_id: 41,
              event_name: 'Matrimonio de Ana y Luis',
              event_date: '2026-09-12',
            },
            {
              guest_id: 42,
              event_name: 'Cumpleaños de Marta',
              event_date: null,
            },
          ],
          requested_at: '2026-08-13T15:00:00.000Z',
          selection_attempts: 0,
        },
      }),
    });
    const service = createService(runtime, gateway, store, [
      rsvpLookupInvitation({ guestId: 41, eventName: 'Matrimonio de Ana y Luis' }),
      rsvpLookupInvitation({ guestId: 42, eventName: 'Cumpleaños de Marta' }),
    ]);

    const result = await service.handleTurn(inbound('Ese evento'));

    expect(gateway.inputs).toEqual([]);
    expect(result.trace.tools_called).not.toContain('guest_rsvp');
    expect(result.plan.rsvp_state.selection_attempts).toBe(1);
    expect(runtime.composeRequests[0]?.errorMessage).toContain('"outcome":"event_selection_required"');
  });

  it('reports a pending invitation and offers confirmation without mutating it', async () => {
    const runtime = new RsvpRuntime([rsvpExtraction({ action: null })]);
    const gateway = new RsvpGateway([]);
    const service = createService(runtime, gateway);

    const result = await service.handleTurn(inbound('¿Cómo está mi invitación?'));

    expect(gateway.inputs).toEqual([]);
    expect(result.plan.rsvp_state).toMatchObject({
      status: 'awaiting_action',
      pending_action: 'attending',
    });
    expect((runtime.composeRequests[0]?.rsvpPhoneEvidence as unknown as { state: string; event: { rsvp_state: string } }).event.rsvp_state).toBe('pending');
    expect((runtime.composeRequests[0]?.rsvpPhoneEvidence as unknown as { state: string }).state).toBe('resolved_single');
    expect(runtime.composeRequests[0]?.errorMessage).toContain('"offer_action":true');
  });

  it('distinguishes a user-level not-found result from a lookup failure', async () => {
    const runtime = new RsvpRuntime([rsvpExtraction({ action: 'attending' })]);
    const gateway = new RsvpGateway([]);
    const service = createService(runtime, gateway, new InMemoryPlanStore(), null);

    await service.handleTurn(inbound('Sí, confirmo que asistiré'));

    expect(gateway.inputs).toEqual([]);
    expect(runtime.composeRequests[0]?.errorMessage).toContain('"outcome":"no_invitation_record"');
    expect(runtime.composeRequests[0]?.errorMessage).not.toContain(
      'No fue posible consultar',
    );
  });

  it('reports an already-confirmed invitation naturally without another mutation', async () => {
    const runtime = new RsvpRuntime([rsvpExtraction({ action: null })]);
    const gateway = new RsvpGateway([], [], {
      status: 'success',
      events: [{
        eventId: 205,
        name: 'Matrimonio de Ana y Luis',
        slug: 'matrimonio-ana-luis',
        url: null,
        datetime: '2026-09-12',
        type: null,
        typeDetail: null,
        stage: null,
        city: 'Lima',
        country: 'PE',
        currency: 'PEN',
      }],
    });
    const service = createService(runtime, gateway, new InMemoryPlanStore(), [
      rsvpLookupInvitation({ hasResponded: true, willAttend: true }),
    ]);

    await service.handleTurn(inbound('¿Mi asistencia está confirmada?'));

    expect(gateway.inputs).toEqual([]);
    expect((runtime.composeRequests[0]?.rsvpPhoneEvidence as unknown as { state: string; event: { rsvp_state: string } }).event.rsvp_state).toBe('attending');
    expect((runtime.composeRequests[0]?.rsvpPhoneEvidence as unknown as { state: string }).state).toBe('resolved_single');
    expect((runtime.composeRequests[0]?.rsvpPhoneEvidence as unknown as { event: { invitation_record: string } }).event.invitation_record).toBe(
      'available',
    );
    expect(runtime.composeRequests[0]?.errorMessage).toContain('"outcome":"current_state"');
  });

  it('applies an explicit RSVP reversal immediately without another confirmation turn', async () => {
    const runtime = new RsvpRuntime([
      rsvpExtraction({ action: 'attending' }),
    ]);
    const gateway = new RsvpGateway([{
      status: 'responded',
      action: 'attending',
      willAttend: true,
      guestId: 41,
      eventName: 'Matrimonio de Ana y Luis',
      eventDate: '2026-09-12',
    }]);
    const store = new InMemoryPlanStore();
    const service = createService(runtime, gateway, store, [
      rsvpLookupInvitation({ hasResponded: true, willAttend: false }),
    ]);

    const result = await service.handleTurn(inbound('Quiero confirmar que asistiré'));

    expect(result.plan.rsvp_state.status).toBe('none');
    expect(gateway.inputs).toHaveLength(1);
    expect(gateway.inputs[0]).toMatchObject({ action: 'attending', guest_id: 41 });
    expect((runtime.composeRequests[0]?.rsvpPhoneEvidence as unknown as { state: string; event: { rsvp_state: string } }).event.rsvp_state).toBe('attending');
    expect(runtime.composeRequests[0]?.errorMessage).toContain('"outcome":"mutation_result"');
  });

  it('never claims a declined invitation changed when the backend returns its current state', async () => {
    const runtime = new RsvpRuntime([rsvpExtraction({ action: 'attending' })]);
    const gateway = new RsvpGateway([{
      status: 'already_responded',
      currentAction: 'declining',
      requestedAction: 'attending',
      guestId: 41,
      eventName: 'Matrimonio de Ana y Luis',
      eventDate: null,
    }]);
    const store = new InMemoryPlanStore();
    await store.save({
      reason: 'seed-confirmed-change',
      plan: mergePlan(createEmptyPlan({
        planId: 'plan-rsvp-change',
        channel: 'whatsapp',
        externalUserId: 'user-rsvp',
      }), {
        contact_phone: '51973296571',
        contact_phone_extension: '+51',
        contact_phone_number: '973296571',
        current_node: 'responder_invitacion',
        rsvp_state: {
          status: 'awaiting_action',
          pending_action: 'attending',
          candidates: [{
            guest_id: 41,
            event_name: 'Matrimonio de Ana y Luis',
            event_date: null,
          }],
          requested_at: '2026-08-17T15:00:00.000Z',
          selection_attempts: 0,
        },
      }),
    });
    const service = createService(runtime, gateway, store, [
      rsvpLookupInvitation({ hasResponded: true, willAttend: false }),
    ]);

    await service.handleTurn(inbound('Sí'));

    expect((runtime.composeRequests[0]?.rsvpPhoneEvidence as unknown as { state: string; event: { rsvp_state: string } }).event.rsvp_state).toBe('declining');
    expect(runtime.composeRequests[0]?.errorMessage).toContain('"status":"already_responded"');
    expect(runtime.composeRequests[0]?.errorMessage).not.toContain('quedó registrada');
  });

  it.each([
    [{
      status: 'already_responded',
      currentAction: null,
      requestedAction: 'attending',
      guestId: null,
      eventName: null,
      eventDate: null,
    }, 'already_responded'],
    [{ status: 'no_pending' }, 'no_pending'],
    [{ status: 'phone_mismatch' }, 'phone_mismatch'],
    [{ status: 'failed', error: 'timeout', retryable: true }, 'failed'],
  ] satisfies Array<[AgentGuestRsvpResult, string]>)('reports %o without inventing success', async (
    gatewayResult,
    expectedNote,
  ) => {
    const runtime = new RsvpRuntime([rsvpExtraction({ action: 'attending' })]);
    const gateway = new RsvpGateway([gatewayResult]);
    const service = createService(runtime, gateway, new InMemoryPlanStore(), [
      rsvpLookupInvitation({ guestId: 41, eventName: 'Gia Antonella' }),
    ]);

    const result = await service.handleTurn(inbound('Sí asistiré'));

    expect(result.plan.rsvp_state.status).toBe('none');
    expect(runtime.composeRequests[0]?.errorMessage).toContain(`"status":"${expectedNote}"`);
    expect(runtime.composeRequests[0]?.errorMessage).not.toContain(
      'quedó registrada',
    );
  });

  it('does not erase a campaign-grounded invitation when the user lookup has no current record', async () => {
    const runtime = new RsvpRuntime([
      rsvpExtraction({
        action: 'attending',
        eventReference: 'Gia Antonella',
      }),
    ]);
    const gateway = new RsvpGateway([], [campaignMessage('Gia Antonella')]);
    const service = createService(runtime, gateway, new InMemoryPlanStore(), []);

    const result = await service.handleTurn(inbound('Sí confirmamos la asistencia'));

    expect(runtime.composeRequests.length).toBe(1);
    expect(result.plan.human_escalation.status).toBe('requested');
    expect(result.outbound.text).toBe('RSVP_MODEL_SENTINEL');
    expect(runtime.composeRequests[0]?.errorMessage).toContain('"outcome":"invitation_lookup_mismatch"');
    expect(result.trace.tools_called).toContain('lookup_rsvp_invitations');
    expect(result.trace.tools_called).not.toContain('guest_rsvp');
  });

  it('uses the trusted-phone event read fallback instead of falsely denying an associated invitation', async () => {
    const runtime = new RsvpRuntime([
      rsvpExtraction({
        action: 'attending',
        eventReference: 'Michelle & Jorge',
      }),
    ]);
    const guestEvent = {
        eventId: 37218,
        name: 'Michelle & Jorge',
        slug: 'michellejorge',
        url: 'https://sinenvolturas.com/michellejorge',
        datetime: '2026-10-10T19:00:00.000Z',
        type: 'wedding',
        typeDetail: null,
        stage: 'active',
        city: 'Lima',
        country: 'PE',
        currency: 'PEN',
      };
    const gateway = new RsvpGateway(
      [],
      [],
      { status: 'success', events: [guestEvent] },
      undefined,
      {
        status: 'success',
        event: {
          ...guestEvent,
          withTime: true,
          timezone: 'America/Lima',
          celebrateds: [],
          moments: [],
          dresscode: null,
          commonAsked: [],
          contactInfo: [],
          attendance: {
            guestId: 584352,
            name: 'Cristian Abarca',
            hasResponded: true,
            willAttend: true,
            responseDate: '2026-08-25T00:00:00.000Z',
          },
          purchases: [],
        },
      },
    );
    const service = createService(runtime, gateway, new InMemoryPlanStore(), []);

    const result = await service.handleTurn(inbound('Hola, ya confirmé, gracias'));

    expect(gateway.inputs).toEqual([]);
    expect(gateway.guestEventLookupCalls).toBe(1);
    expect(result.trace.tools_called).toContain('lookup_rsvp_invitations');
    expect(result.trace.tools_called).toContain('lookup_guest_events_by_phone');
    expect(result.trace.tools_called).toContain('get_guest_event_detail');
    expect(result.trace.tools_called).not.toContain('guest_rsvp');
    expect(runtime.composeRequests[0]?.rsvpPhoneEvidence).toEqual({
      state: 'resolved_single',
      coverage: 'complete',
      resolution: 'authoritative_invitation',
      event: {
        event_name: 'Michelle & Jorge',
        event_date: '2026-10-10T19:00:00.000Z',
        invitation_record: 'available',
        rsvp_state: 'attending',
      },
    });
    expect(runtime.composeRequests[0]?.errorMessage).toContain('"outcome":"current_state"');
    expect(runtime.composeRequests[0]?.errorMessage).toContain('"invitation_state":"attending"');
    expect(runtime.composeRequests[0]?.errorMessage).not.toContain(
      'no encontró ninguna invitación',
    );
  });

  it('preserves the authoritative server date when phone enrichment omits it', async () => {
    const runtime = new RsvpRuntime([rsvpExtraction({ action: null })]);
    const guestEvent = {
      eventId: 37218,
      name: 'Michelle & Jorge',
      slug: 'michellejorge',
      url: null,
      datetime: null,
      type: 'wedding',
      typeDetail: null,
      stage: 'active',
      city: 'Lima',
      country: 'PE',
      currency: 'PEN',
    };
    const gateway = new RsvpGateway(
      [],
      [],
      { status: 'success', events: [guestEvent] },
      undefined,
      {
        status: 'success',
        event: {
          ...guestEvent,
          withTime: true,
          timezone: 'America/Lima',
          celebrateds: [],
          moments: [],
          dresscode: null,
          commonAsked: [],
          contactInfo: [],
          attendance: {
            guestId: 584352,
            name: 'Cristian Abarca',
            hasResponded: true,
            willAttend: true,
            responseDate: '2026-08-25T00:00:00.000Z',
          },
          purchases: [],
        },
      },
    );
    const service = createService(runtime, gateway, new InMemoryPlanStore(), [
      {
        ...rsvpLookupInvitation({
          guestId: 584352,
          eventName: 'Michelle & Jorge',
          hasResponded: true,
          willAttend: true,
        }),
        eventId: 37218,
        datetime: '10/10/2026 20:15',
      },
    ]);

    const result = await service.handleTurn(inbound('Hola buen día, ya confirmé, gracias'));

    expect(gateway.inputs).toEqual([]);
    expect(result.outbound.text).toBe('RSVP_MODEL_SENTINEL');
    expect(runtime.composeRequests[0]?.rsvpPhoneEvidence).toMatchObject({
      state: 'resolved_single',
      event: {
        event_name: 'Michelle & Jorge',
        event_date: '10/10/2026 20:15',
        rsvp_state: 'attending',
      },
    });
  });

  it('starts both phone lookups before either result is reconciled', async () => {
    const sequence: string[] = [];
    const runtime = new RsvpRuntime([rsvpExtraction({ action: null })]);
    const gateway = new RsvpGateway(
      [],
      [],
      { status: 'not_found' },
      () => sequence.push('guest-events-start'),
    );
    const providerGateway = {
      async lookupUserEventContext(): Promise<UserEventLookupResult> {
        sequence.push('user-context-start');
        await new Promise((resolve) => setTimeout(resolve, 10));
        sequence.push('user-context-end');
        return {
          lookup: { email: null, phone: '973296571' },
          user: null,
          events: [rsvpLookupInvitation({})],
          counts: {
            ownerEvents: 0,
            guestEvents: 1,
            hostEvents: 0,
            celebratedEvents: 0,
            recentOrders: 0,
          },
        };
      },
    } as unknown as ProviderGateway;
    const service = createService(
      runtime,
      gateway,
      new InMemoryPlanStore(),
      [],
      providerGateway,
    );

    await service.handleTurn(inbound('¿Cómo está mi invitación?'));

    expect(sequence).toEqual([
      'user-context-start',
      'guest-events-start',
      'user-context-end',
    ]);
  });

  it('marks reconciled evidence partial when one phone lookup fails', async () => {
    const runtime = new RsvpRuntime([rsvpExtraction({ action: null })]);
    const gateway = new RsvpGateway(
      [],
      [],
      { status: 'not_found' },
      () => {
        throw new Error('guest-event read unavailable');
      },
    );
    const service = createService(runtime, gateway);

    await service.handleTurn(inbound('¿Cómo está mi invitación?'));

    expect(runtime.composeRequests[0]?.rsvpPhoneEvidence).toMatchObject({
      state: 'resolved_single',
      coverage: 'partial',
      resolution: 'authoritative_invitation',
      event: { invitation_record: 'available', rsvp_state: 'pending' },
    });
    expect(runtime.composeRequests[0]?.errorMessage).toContain('"evidence_coverage":"partial"');
  });
});

class RsvpRuntime implements AgentRuntime {
  readonly composeRequests: ComposeReplyRequest[] = [];

  constructor(private readonly extractions: ExtractionResult[]) {}

  async extract(request: ExtractRequest): Promise<ExtractionResult> {
    void request;
    const extraction = this.extractions.shift();
    if (!extraction) {
      throw new Error('No RSVP extraction queued.');
    }
    return extraction;
  }

  async composeReply(request: ComposeReplyRequest): Promise<ComposeReplyResult> {
    this.composeRequests.push(request);
    return {
      text: 'RSVP_MODEL_SENTINEL',
      structuredMessage: { type: 'generic', paragraphs_es: ['RSVP_MODEL_SENTINEL'] },
    };
  }
}

class RsvpGateway implements AgentConversationGateway {
  readonly inputs: AgentGuestRsvpInput[] = [];
  guestEventLookupCalls = 0;

  constructor(
    private readonly results: AgentGuestRsvpResult[],
    private readonly messages: AgentConversationMessage[] = [],
    private readonly guestEvents: AgentGuestEventsResult = { status: 'not_found' },
    private readonly onGuestEventLookup?: () => void,
    private readonly eventDetail: AgentEventDetailResult = { status: 'not_found' },
  ) {}

  async logMessage(input: AgentMessageLogInput): Promise<AgentGatewayResult> {
    void input;
    return { status: 'skipped', reason: 'disabled', message: 'Disabled.' };
  }

  async getRecentMessages(): Promise<{
    status: 'success';
    messages: AgentConversationMessage[];
  }> {
    return { status: 'success', messages: this.messages };
  }

  async requestHumanTakeover(): Promise<AgentGatewayResult> {
    return { status: 'success', message: 'Requested.' };
  }

  async authByPhone(): Promise<{
    status: 'failed';
    error: string;
    retryable: false;
  }> {
    return { status: 'failed', error: 'Unused.', retryable: false };
  }

  async updatePhone(): Promise<{ status: 'success' }> {
    return { status: 'success' };
  }

  async getGuestEventsByPhone(): Promise<AgentGuestEventsResult> {
    this.guestEventLookupCalls += 1;
    this.onGuestEventLookup?.();
    return this.guestEvents;
  }

  async getEventDetail(): Promise<AgentEventDetailResult> {
    return this.eventDetail;
  }

  async guestRsvp(input: AgentGuestRsvpInput): Promise<AgentGuestRsvpResult> {
    this.inputs.push(input);
    const result = this.results.shift();
    if (!result) {
      throw new Error('No RSVP gateway result queued.');
    }
    return result;
  }
}

function campaignMessage(eventName: string): AgentConversationMessage {
  return {
    id: 1,
    direction: 'outbound',
    source: 'admin_campaign',
    body: `Este es un recordatorio del evento: ${eventName}`,
    status: 'delivered',
    whatsappMessageId: null,
    sentAt: '2026-08-13T14:00:00.000Z',
    createdAt: '2026-08-13T14:00:00.000Z',
  };
}

function rsvpExtraction(args: {
  action: 'attending' | 'declining' | null;
  decisionSource?: 'current_message' | 'plan_state' | null;
  candidateGuestId?: number | null;
  eventReference?: string | null;
  party?: {
    scope: 'self' | 'self_and_others';
    mentioned_names: string[];
    companion_count?: 'one' | 'multiple' | 'unknown';
    plus_one_response?: 'yes' | 'no' | 'unknown';
  } | null;
}): ExtractionResult {
  return {
    actionIntent: 'responder_invitacion',
    informationRequests: [],
    rsvpAction: args.action,
    rsvpDecisionSource: args.decisionSource ?? (args.action ? 'current_message' : 'plan_state'),
    rsvpCandidateGuestId: args.candidateGuestId ?? null,
    rsvpEventReference: args.eventReference ?? null,
    rsvpParty: args.party ?? null,
    intentConfidence: 0.98,
    ambiguity: {
      status: 'clear',
      clarificationQuestion: null,
      interpretations: [],
    },
    eventType: null,
    vendorCategory: null,
    vendorCategories: [],
    activeNeedCategory: null,
    location: null,
    budgetSignal: null,
    guestRange: null,
    preferences: [],
    hardConstraints: [],
    assumptions: [],
    conversationSummary: 'La persona responde una invitación.',
    selectedProviderHints: [],
    selectedProviderReferences: [],
    closeAction: null,
    pauseRequested: false,
    contactName: null,
    contactEmail: null,
    contactPhone: null,
    providerFitCriteria: null,
    providerQueryIntents: [],
    providerPlanOperations: [],
    providerExplanationRequest: null,
    providerDetailRequest: null,
  };
}

function createService(
  runtime: AgentRuntime,
  gateway: AgentConversationGateway,
  store = new InMemoryPlanStore(),
  invitations: UserEventLookupResult['events'] | null = [rsvpLookupInvitation({})],
  providerGateway?: ProviderGateway,
  capabilityManifest?: RuntimeCapabilityManifest,
): AgentService {
  return new AgentService({
    planStore: store,
    runtime,
    providerGateway: providerGateway ?? {
      async lookupUserEventContext(): Promise<UserEventLookupResult | null> {
        if (invitations === null) {
          return null;
        }
        return {
          lookup: { email: null, phone: '973296571' },
          user: null,
          events: invitations,
          counts: {
            ownerEvents: 0,
            guestEvents: invitations.length,
            hostEvents: 0,
            celebratedEvents: 0,
            recentOrders: 0,
          },
        };
      },
    } as unknown as ProviderGateway,
    agentConversationGateway: gateway,
    capabilityManifest,
    promptLoader: new PromptLoader(path.resolve(process.cwd(), 'prompts')),
    renderers: { whatsapp: new WhatsAppMessageRenderer() },
  });
}

function rsvpLookupInvitation(args: {
  guestId?: number;
  eventName?: string;
  hasResponded?: boolean;
  willAttend?: boolean | null;
}): UserEventLookupResult['events'][number] {
  return {
    relation: 'guest',
    guestId: args.guestId ?? 41,
    eventId: 205,
    slug: null,
    url: null,
    name: args.eventName ?? 'Matrimonio de Ana y Luis',
    place: null,
    type: null,
    datetime: '2026-09-12',
    stage: null,
    isVisible: null,
    isPublic: null,
    currency: null,
    country: null,
    guestStatus: {
      hasResponded: args.hasResponded ?? false,
      willAttend: args.willAttend ?? null,
      hasCouple: null,
      responseDate: null,
    },
    hostType: null,
    hostPermission: null,
    hostStatus: null,
    celebratedType: null,
    amountCollected: null,
    amountTransferred: null,
    transactionsCount: null,
    invitedGuestCount: null,
    confirmedGuestCount: null,
    orders: [],
  };
}

function inbound(text: string) {
  return {
    channel: 'whatsapp',
    externalUserId: 'user-rsvp',
    text,
    messageId: `message-${text}`,
    receivedAt: '2026-08-13T15:00:00.000Z',
    contactPhone: '+51973296571',
  };
}
