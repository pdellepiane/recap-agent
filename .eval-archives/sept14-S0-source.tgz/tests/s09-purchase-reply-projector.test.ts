import { describe, expect, it } from 'vitest';

import type {
  CartInformation,
  PurchaseAspect,
  PurchaseInformation,
} from '../src/core/information';
import {
  projectCompletedPurchaseForModel,
  projectPurchaseReplyForModel,
  selectPurchaseReplyOutcome,
} from '../src/runtime/purchase-reply-projector';

function order(overrides: Partial<PurchaseInformation> = {}): PurchaseInformation {
  return {
    orderId: 'order-alex-pending-250',
    paymentStatus: 'pending',
    shippingStatus: null,
    grandTotal: 250,
    paymentMethod: 'Yape_o_Plin',
    eventName: 'Luis Raul and Carmen del Rosario',
    eventDate: '2026-09-15',
    eventUrl: null,
    createdAt: '2026-08-28 10:00:00',
    items: [],
    ...overrides,
  };
}

function cart(overrides: Partial<CartInformation> = {}): CartInformation {
  return {
    cartId: 'cart-alex-001',
    status: 'active',
    wasAbandoned: false,
    eventId: 2001,
    eventName: 'Luis Raul and Carmen del Rosario',
    eventDate: '2026-09-15',
    subtotal: 250,
    giftsQuantity: 1,
    createdAt: '2026-08-28 09:00:00',
    items: [],
    ...overrides,
  };
}

function aspects(...values: PurchaseAspect[]): PurchaseAspect[] {
  return values;
}

describe('S09 purchase reply projector keeps carts distinct from orders', () => {
  it('projects a cart-only outcome with its own record type and no order amount or status', () => {
    const outcome = selectPurchaseReplyOutcome({
      purchases: [],
      carts: [cart()],
      needsSelection: false,
      coverage: 'partial',
      referenceResolution: 'not_requested',
      requestedAspects: aspects('summary'),
      referenceAuthorized: false,
      userReported: {},
    });
    expect(outcome.kind).toBe('cart_only');
    if (outcome.kind !== 'cart_only') return;
    expect(outcome.cart.recordType).toBe('cart');
    expect(outcome.cart).not.toHaveProperty('grandTotal');
    // C1: the cart carries explicit nulls (never order values) for payment
    // state and amount so the reply keeps them on the order record.
    expect(outcome.cart.paymentStatus).toBeNull();
    expect(outcome.cart.amount).toBeNull();
    expect(outcome.cart).not.toHaveProperty('subtotal');
    expect(outcome.cart).not.toHaveProperty('amountDisclosure');
  });

  it('keeps same-event order and cart distinct without attaching order amount or status to the cart', () => {
    const outcome = selectPurchaseReplyOutcome({
      purchases: [order()],
      carts: [cart()],
      needsSelection: false,
      coverage: 'complete',
      referenceResolution: 'not_requested',
      requestedAspects: aspects('summary', 'payment_status'),
      referenceAuthorized: false,
      userReported: {},
    });
    expect(outcome.kind).toBe('order_plus_cart');
    if (outcome.kind !== 'order_plus_cart') return;
    expect(outcome.order.recordType).toBe('order');
    expect(outcome.cart.recordType).toBe('cart');
    expect(outcome.cart).not.toHaveProperty('grandTotal');
    // C1: explicit nulls keep order payment state and amount off the cart.
    expect(outcome.cart.paymentStatus).toBeNull();
    expect(outcome.cart.amount).toBeNull();
    expect(outcome.order.paymentStatus).toBe('pending');
  });
});

describe('S09 reported amounts never become settlement evidence', () => {
  it('records a disputed amount as user-reported without overwriting the trusted total', () => {
    const outcome = selectPurchaseReplyOutcome({
      purchases: [order({ grandTotal: 63.85 })],
      carts: [],
      needsSelection: false,
      coverage: 'complete',
      referenceResolution: 'not_requested',
      requestedAspects: aspects('summary', 'payment_status'),
      referenceAuthorized: false,
      userReported: { amount: 60 },
    });
    expect(outcome.kind).toBe('order_unique');
    if (outcome.kind !== 'order_unique') return;
    expect(outcome.order.amount?.total).toBe(63.85);
    expect(outcome.order.amountMismatch?.reported).toBe(60);
    expect(outcome.order.amountMismatch?.recorded).toBe(63.85);
    expect(outcome.order.userReported.amount).toBe(60);
  });

  it('keeps a shortfall report pending without approval or a computed balance', () => {
    const outcome = selectPurchaseReplyOutcome({
      purchases: [order({ orderId: 'order-maria-pending-63', grandTotal: 63.85, paymentStatus: 'pending' })],
      carts: [],
      needsSelection: false,
      coverage: 'complete',
      referenceResolution: 'not_requested',
      requestedAspects: aspects('summary', 'payment_status'),
      referenceAuthorized: false,
      userReported: { amount: 3.85 },
    });
    expect(outcome.kind).toBe('order_unique');
    if (outcome.kind !== 'order_unique') return;
    expect(outcome.order.paymentStatus).toBe('pending');
    expect(outcome.order.amount?.total).toBe(63.85);
    expect(outcome.order).not.toHaveProperty('balance');
  });
});

describe('S09 purchase facts reach the reply model', () => {
  it('selects a unique record without inventing a reference', () => {
    const outcome = selectPurchaseReplyOutcome({
      purchases: [order({ customerTransactionNumber: null })],
      carts: [],
      needsSelection: false,
      coverage: 'complete',
      referenceResolution: 'unavailable',
      requestedAspects: aspects('summary', 'payment_status'),
      referenceAuthorized: true,
      userReported: {},
    });
    expect(outcome.kind).toBe('order_unique');
    if (outcome.kind !== 'order_unique') return;
    expect(outcome.order.transactionReference).toBeNull();
    expect(projectPurchaseReplyForModel(outcome)).toMatchObject({
      recordType: 'order',
      order: { paymentStatus: 'pending' },
    });
  });

  it('keeps candidate resolution and reference status as structured facts', () => {
    const outcome = selectPurchaseReplyOutcome({
      purchases: [
        order({ orderId: 'order-martha-01', eventName: 'Evento Familiar Norte' }),
        order({ orderId: 'order-martha-02', eventName: null }),
      ],
      carts: [],
      needsSelection: true,
      coverage: 'complete',
      referenceResolution: 'unavailable',
      requestedAspects: aspects('summary', 'payment_status'),
      referenceAuthorized: false,
      userReported: {},
    });
    expect(outcome.kind).toBe('selection');
    const result = {
      requestId: 'purchase-1',
      kind: 'purchase',
      status: 'completed',
      resource: 'orders',
      purchases: [
        order({ eventName: 'Evento Familiar Norte' }),
        order({ eventName: null }),
      ],
      carts: [],
      needsSelection: true,
      coverage: 'complete',
      referenceResolution: 'unavailable',
      requestedCustomerTransactionNumber: 'COD-missing',
    } as never;
    const evidence = projectCompletedPurchaseForModel(result, {
      requestedAspects: aspects('summary', 'payment_status'),
      referenceAuthorized: false,
    });
    expect(evidence).toMatchObject({
      outcome_kind: 'selection',
      reference_status: {
        requested: true,
        resolution: 'unavailable',
        authorized: false,
        candidate_count: 2,
      },
      permitted_next_action: 'select_purchase',
    });
    const disclosures = evidence.disclosures as { denied: unknown[] };
    const missingInputs = evidence.missing_inputs as unknown[];
    expect(disclosures.denied).toEqual(
      expect.arrayContaining(['transaction_reference', 'internal_identifiers']),
    );
    expect(missingInputs).toEqual(expect.arrayContaining(['purchase_selection']));
    const serialized = JSON.stringify(evidence);
    expect(serialized).not.toContain('order-martha-01');
  });

  it('keeps a cart separate from an order and preserves reported amount provenance', () => {
    const outcome = selectPurchaseReplyOutcome({
      purchases: [order({ grandTotal: 63.85 })],
      carts: [cart()],
      needsSelection: false,
      coverage: 'complete',
      referenceResolution: 'not_requested',
      requestedAspects: aspects('summary', 'payment_status'),
      referenceAuthorized: false,
      userReported: { amount: 60 },
    });
    expect(outcome.kind).toBe('order_plus_cart');
    if (outcome.kind !== 'order_plus_cart') return;
    expect(outcome.order.amount?.total).toBe(63.85);
    expect(outcome.order.amountMismatch).toEqual({ reported: 60, recorded: 63.85 });
    expect(outcome.cart.recordType).toBe('cart');
    const modelInput = projectPurchaseReplyForModel(outcome);
    expect(modelInput).toMatchObject({
      recordType: 'order_plus_cart',
      order: { amountMismatch: { reported: 60, recorded: 63.85 } },
      cart: { recordType: 'cart' },
    });
  });

  it('omits withheld currency and internal payment data from model facts', () => {
    const outcome = selectPurchaseReplyOutcome({
      purchases: [order({
        payment: {
          method: 'Transferencia',
          amount: 63.85,
          paidAt: '2026-08-28 12:00:00',
          paymentId: 'pay-1',
          destinationAccount: { holder: 'h', bank: 'b', number: 'n', cci: 'c', type: 't' },
          voucherImage: 'voucher.png',
        },
        currency: null,
      })],
      carts: [],
      needsSelection: false,
      coverage: 'complete',
      referenceResolution: 'not_requested',
      requestedAspects: aspects('summary', 'payment_status'),
      referenceAuthorized: true,
      userReported: { currency: 'USD', paidAt: '2026-08-28 12:00:00' },
    });
    const serialized = JSON.stringify(projectPurchaseReplyForModel(outcome));
    expect(serialized).not.toContain('pay-1');
    expect(serialized).not.toContain('voucher.png');
    expect(serialized).not.toContain('destinationAccount');
    expect(serialized).toContain('USD');
    expect(serialized).toContain('2026-08-28 12:00:00');
  });

  it('projects conflict and empty outcomes without a fabricated status', () => {
    const conflict = selectPurchaseReplyOutcome({
      purchases: [order()], carts: [], needsSelection: false,
      coverage: 'inconsistent', referenceResolution: 'not_requested',
      requestedAspects: aspects('summary'), referenceAuthorized: false, userReported: {},
    });
    const empty = selectPurchaseReplyOutcome({
      purchases: [], carts: [], needsSelection: false,
      coverage: 'complete', referenceResolution: 'not_requested',
      requestedAspects: aspects('summary'), referenceAuthorized: false, userReported: {},
    });
    expect(projectPurchaseReplyForModel(conflict)).toEqual({ recordType: 'conflict' });
    expect(projectPurchaseReplyForModel(empty)).toEqual({ recordType: 'empty' });
  });
});
