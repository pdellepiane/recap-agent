import type { EvalTurnResult, SilenceObservation } from './case-schema';

/**
 * Typed acceptance path for legitimate outbound silence.
 *
 * A suppressed turn carries `deliveredText: null` with
 * `delivery.action === 'suppress'`. Silence is exempt from the
 * output-origin gate only when suppression evidence is legitimate:
 * an established pause reason (human escalation soft-pause) or a
 * model-selected classifier suppression observed in enforce mode.
 * Failed generation, missing receipts, and forged suppression claims
 * never use this exemption (fail closed).
 */
export const ESTABLISHED_SUPPRESSION_REASONS = [
  'human_escalation_active',
] as const;

export const MODEL_SELECTED_SUPPRESSION_REASONS = [
  'suppress_acknowledgement',
  'suppress_reaction',
  'suppress_automated_response',
] as const;

/**
 * F2 canonical image-only silence disposition. An image-only turn with no
 * outstanding task persists the attachment reference and delivers typed
 * silence with this exact reason. This path is explicit and standalone:
 * the image reason is never added to the acknowledgement/reaction/automated
 * helper above, and no other reason may spoof the image path.
 */
export const IMAGE_ONLY_SILENCE_REASON = 'image_only_no_outstanding_task';

const IMAGE_SILENCE_PERSIST_REASONS: readonly string[] = [
  'image_file_silence',
  'image_url_silence',
];

export type SilenceExemption = {
  exempt: boolean;
  reason: string;
};

type SilenceCandidate = Pick<
  EvalTurnResult,
  'deliveredText' | 'outputText' | 'delivery' | 'outputOrigin' | 'trace' | 'plan' | 'input'
>;

export function validateSilenceExemption(turn: SilenceCandidate): SilenceExemption {
  if (turn.deliveredText !== null) {
    return { exempt: false, reason: 'nonempty delivered text is not silence' };
  }
  if (turn.outputOrigin?.status === 'generation_failed') {
    return { exempt: false, reason: 'failed generation must never use the silence exemption' };
  }
  if (turn.outputOrigin?.status === 'mismatch') {
    return { exempt: false, reason: 'mismatched origin must never use the silence exemption' };
  }
  if (turn.outputOrigin?.status === 'verified') {
    return { exempt: false, reason: 'verified origin with null text is incoherent' };
  }
  if (turn.delivery?.action !== 'suppress') {
    return { exempt: false, reason: 'missing suppress delivery action' };
  }
  const reason = turn.delivery.reason;
  if ((ESTABLISHED_SUPPRESSION_REASONS as readonly string[]).includes(reason)) {
    return { exempt: true, reason: `established suppression: ${reason}` };
  }
  if ((MODEL_SELECTED_SUPPRESSION_REASONS as readonly string[]).includes(reason)) {
    const classifier = turn.trace.response_classifier;
    if (classifier?.would_suppress === true && classifier.mode === 'enforce') {
      return { exempt: true, reason: `model-selected suppression: ${reason}` };
    }
    return { exempt: false, reason: 'suppression claim lacks model-selected enforce evidence' };
  }
  return { exempt: false, reason: `unknown suppression reason: ${reason}` };
}

/**
 * F2 successful image-ref save proof. Persisted-silence text alone
 * (`plan_persist_reason`) never proves the upload: at least one stored
 * attachment ref must carry real linkage (a message id plus a file or url
 * identity). Forged persist-reason text with no saved ref stays a failure.
 */
export function hasSuccessfulImageRefSave(turn: SilenceCandidate): boolean {
  const attachments = (turn.plan as { image_attachments?: unknown } | undefined)?.image_attachments;
  if (!Array.isArray(attachments) || attachments.length === 0) return false;
  return attachments.some((entry) => {
    if (!entry || typeof entry !== 'object' || Array.isArray(entry)) return false;
    const record = entry as Record<string, unknown>;
    const messageId = record['messageId'] ?? record['message_id'];
    if (typeof messageId !== 'string' || messageId.trim().length === 0) return false;
    const fileId = record['fileId'] ?? record['file_id'] ?? record['fileID'];
    if (typeof fileId === 'string' && fileId.trim().length > 0) return true;
    const url = record['url'] ?? record['ref'];
    if (typeof url === 'string' && url.trim().length > 0) return true;
    return false;
  });
}

/**
 * F2 explicit image-only silence validation. Every conjunct is required:
 * the observed suppress disposition with the exact image-silence reason, no
 * assistant text on the wire, a missing (never failed/mismatched/verified)
 * origin, a persisted plan carrying a successful image ref save, and an
 * image-only input (empty text with an image). A question-bearing turn or a
 * failed generation fails closed through the normal gate.
 */
export function validateImageOnlySilence(turn: SilenceCandidate): SilenceExemption {
  if (turn.delivery?.action !== 'suppress') {
    return { exempt: false, reason: 'missing suppress delivery action' };
  }
  if (turn.delivery?.reason !== IMAGE_ONLY_SILENCE_REASON) {
    return { exempt: false, reason: `not the image-silence disposition: ${turn.delivery?.reason ?? 'missing reason'}` };
  }
  if (turn.deliveredText !== null && turn.deliveredText !== undefined) {
    return { exempt: false, reason: 'image silence carries no delivered text' };
  }
  if ((turn.outputText ?? '') !== '') {
    return { exempt: false, reason: 'image silence carries no assistant text' };
  }
  const originStatus = turn.outputOrigin?.status;
  if (originStatus !== 'missing') {
    return { exempt: false, reason: `image silence requires missing origin, observed ${originStatus ?? 'none'}` };
  }
  if (turn.trace?.plan_persisted !== true) {
    return { exempt: false, reason: 'unpersisted image silence is a failure, never silence' };
  }
  const persistReason = turn.trace?.plan_persist_reason;
  if (typeof persistReason !== 'string' || !IMAGE_SILENCE_PERSIST_REASONS.includes(persistReason)) {
    return { exempt: false, reason: `unexpected image persist reason: ${persistReason ?? 'none'}` };
  }
  if (!hasSuccessfulImageRefSave(turn)) {
    return { exempt: false, reason: 'persist-reason text alone never proves an image save: no stored attachment ref' };
  }
  const inputText = (turn.input as { text?: unknown } | undefined)?.text;
  if (typeof inputText !== 'string' || inputText.trim().length > 0) {
    return { exempt: false, reason: 'question-bearing turns must answer, never silence' };
  }
  const inputImage = (turn.input as { image?: unknown } | undefined)?.image;
  if (inputImage === undefined || inputImage === null) {
    return { exempt: false, reason: 'image silence requires a current image input' };
  }
  return { exempt: true, reason: `persisted image-only silence: ${turn.delivery.reason}` };
}

function baseObservation(turn: EvalTurnResult | undefined): {
  dispositionAction: string | null;
  dispositionReason: string | null;
  deliveredNull: boolean;
  originStatus: string | null;
  imageRefSaved: boolean;
} {
  return {
    dispositionAction: turn?.delivery?.action ?? null,
    dispositionReason: turn?.delivery?.reason ?? null,
    deliveredNull: turn?.deliveredText === null || turn?.deliveredText === undefined,
    originStatus: turn?.outputOrigin?.status ?? null,
    imageRefSaved: turn ? hasSuccessfulImageRefSave(turn) : false,
  };
}

/**
 * F2 validated silence observation for semantic judging. Runs BEFORE any
 * blanket empty-text rejection so legitimate thanks and supplemental-image
 * silence reach the judge with a structured disposition instead of an
 * automatic failure, while hard failures (generation failure, origin
 * mismatch, missing turn, empty send, unknown suppression, unpersisted
 * image) stay failures. Speech turns route back to normal text judging.
 */
export function observeSilenceForJudge(turn: EvalTurnResult | undefined): SilenceObservation {
  const base = baseObservation(turn);
  if (!turn) {
    return { route: 'failure', path: null, reason: 'missing turn', ...base };
  }
  if (turn.outputOrigin?.status === 'generation_failed') {
    return { route: 'failure', path: null, reason: 'failed generation must never use the silence exemption', ...base };
  }
  if (turn.outputOrigin?.status === 'mismatch') {
    return { route: 'failure', path: null, reason: 'mismatched origin must never use the silence exemption', ...base };
  }
  const outputText = turn.outputText ?? '';
  if (outputText.trim().length > 0) {
    return { route: 'speech', path: null, reason: 'delivered text present', ...base };
  }
  if (turn.deliveredText !== null && turn.deliveredText !== undefined) {
    return { route: 'failure', path: null, reason: 'empty send must never use the silence exemption', ...base };
  }
  if (turn.delivery?.action === 'send') {
    return { route: 'failure', path: null, reason: 'empty send must never use the silence exemption', ...base };
  }
  const exemption = validateSilenceExemption(turn);
  if (exemption.exempt) {
    const path = (ESTABLISHED_SUPPRESSION_REASONS as readonly string[]).includes(turn.delivery?.reason ?? '')
      ? 'established' as const
      : 'model_selected' as const;
    return { route: 'silence', path, reason: exemption.reason, ...base };
  }
  const imageSilence = validateImageOnlySilence(turn);
  if (imageSilence.exempt) {
    return { route: 'silence', path: 'image_only', reason: imageSilence.reason, ...base };
  }
  if (
    turn.delivery?.action === 'suppress' &&
    turn.delivery?.reason === IMAGE_ONLY_SILENCE_REASON
  ) {
    return { route: 'failure', path: null, reason: `unpersisted image silence is a failure: ${imageSilence.reason}`, ...base };
  }
  if (turn.delivery?.action === 'suppress') {
    return { route: 'failure', path: null, reason: exemption.reason, ...base };
  }
  return { route: 'failure', path: null, reason: exemption.reason, ...base };
}
