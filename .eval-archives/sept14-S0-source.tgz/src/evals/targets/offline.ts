import { ulid } from 'ulid';

import { AgentService } from '../../runtime/agent-service';
import { normalizeInboundImage } from '../../core/inbound-image';
import { redactImageUrlForLog } from '../../core/image-attachments';
import { createEmptyPlan, mergePlan, planSchema } from '../../core/plan';
import type {
  AgentRuntime,
  ComposeReplyRequest,
  ComposeReplyResult,
  ExtractResult,
  ExtractRequest,
} from '../../runtime/contracts';
import { PromptLoader } from '../../runtime/prompt-loader';
import type {
  CategoryLocationProviderSearchInput,
  CreateProviderReviewInput,
  FavoriteRequestInput,
  KeywordProviderSearchInput,
  MarketplaceCategory,
  MarketplaceLocation,
  ProviderGateway,
  ProviderGatewaySearchResult,
  ProviderReview,
  QueryIntentProviderSearchInput,
  QuoteRequestInput,
  UserEventLookupInput,
  UserEventLookupResult,
} from '../../runtime/provider-gateway';
import { InMemoryPlanStore } from '../../storage/in-memory-plan-store';
import type { EvalCase, EvalRunConfig, EvalTurnResult, OfflineFixture } from '../case-schema';
import { lambdaTurnResponseSchema } from '../case-schema';
import type { ProviderDetail, ProviderSummary } from '../../core/provider';
import { WhatsAppMessageRenderer } from '../../runtime/message-renderer';
import {
  projectSafePlan,
  projectSafeTrace,
  redactArtifactText,
} from '../../runtime/artifact-redaction';
import { attachEvaluationState, buildCumulativeFixtureEffectSummaries } from '../evaluation-state';

export async function runOfflineCase(args: {
  currentCase: EvalCase;
  config: EvalRunConfig;
  artifactDir: string;
}): Promise<{
  turns: EvalTurnResult[];
  status: 'passed' | 'failed' | 'errored' | 'skipped';
}> {
  const planStore = new InMemoryPlanStore();
  const fixture = args.currentCase.fixtures?.offline;
  const service = new AgentService({
    planStore,
    runtime: new FixtureRuntime(fixture),
    providerGateway: new FixtureProviderGateway(fixture),
    promptLoader: new PromptLoader('prompts'),
    renderers: {
      whatsapp: new WhatsAppMessageRenderer(),
      terminal_whatsapp: new WhatsAppMessageRenderer(),
      terminal_whatsapp_eval: new WhatsAppMessageRenderer(),
    },
  });
  const userId = `offline-${args.currentCase.id}`;
  const turns: EvalTurnResult[] = [];

  if (args.currentCase.seedPlan) {
    await planStore.save({
      plan: mergePlan(
        createSeedPlan(inputChannel(args.currentCase), inputUser(args.currentCase, userId)),
        args.currentCase.seedPlan,
      ),
      reason: 'eval-seed',
    });
  }

  for (const [turnIndex, input] of args.currentCase.inputs.entries()) {
    const startedAt = Date.now();
    const offlineImage = input.image && 'redacted' in input.image
      ? undefined
      : input.image
        ? normalizeInboundImage(input.image)
        : undefined;
    const response = await service.handleTurn({
      channel: input.channel ?? 'terminal_whatsapp_eval',
      externalUserId: input.externalUserId ?? userId,
      text: input.text,
      ...(offlineImage ? { image: offlineImage } : {}),
      messageId: `${args.currentCase.id}-${turnIndex}`,
      receivedAt: input.receivedAt ?? new Date().toISOString(),
      sessionId: input.sessionId ?? args.currentCase.id,
    });
    const typedTrace = lambdaTurnResponseSchema.shape.trace.parse(response.trace);
    const typedPlan = planSchema.parse(response.plan);
    const turn: EvalTurnResult = {
      turnIndex,
      input: redactOfflineInput(input),
      outputText: redactArtifactText(response.outbound.text ?? ''),
      deliveredText: response.outbound.text,
      delivery: { ...response.outbound.delivery },
      currentNode: response.plan.current_node,
      trace: projectSafeTrace(typedTrace) as EvalTurnResult['trace'],
      plan: projectSafePlan(typedPlan),
      latencyMs: Date.now() - startedAt,
    };
    attachEvaluationState(turn, {
      plan: response.plan,
      input: turn.input,
      outputText: response.outbound.text ?? '',
      fixtureEffects: [],
    });
    turns.push(turn);
  }
  for (const turn of turns) {
    const { getEvaluationPlan } = await import('../evaluation-state');
    attachEvaluationState(turn, {
      plan: getEvaluationPlan(turn),
      input: turn.input,
      outputText: turn.outputText,
      fixtureEffects: buildCumulativeFixtureEffectSummaries(turns, turn.turnIndex),
    });
  }

  return {
    turns,
    status: 'passed',
  };
}

function redactOfflineInput(input: EvalTurnResult['input']): EvalTurnResult['input'] {
  return {
    ...input,
    text: redactArtifactText(input.text),
    ...(input.image && 'data' in input.image
      ? {
        image: {
          redacted: true as const,
          mime_type: input.image.mime_type,
          byte_length: Buffer.byteLength(input.image.data, 'utf8'),
        },
      }
      : {}),
    ...(input.image && 'url' in input.image
      ? {
        image: {
          redacted: true as const,
          url_host_redacted: redactImageUrlForLog(input.image.url),
          url_bytes: Buffer.byteLength(input.image.url, 'utf8'),
        },
      }
      : {}),
    ...(input.externalUserId
      ? { externalUserId: input.externalUserId }
      : {}),
    ...(input.contactPhone !== undefined ? { contactPhone: null } : {}),
  };
}

function createSeedPlan(channel: string, externalUserId: string) {
  return createEmptyPlan({
    planId: ulid(),
    channel,
    externalUserId,
  });
}

function inputChannel(currentCase: EvalCase): string {
  return currentCase.inputs[0]?.channel ?? 'terminal_whatsapp_eval';
}

function inputUser(currentCase: EvalCase, fallbackUserId: string): string {
  return currentCase.inputs[0]?.externalUserId ?? fallbackUserId;
}

class FixtureRuntime implements AgentRuntime {
  private extractionIndex = 0;
  private replyIndex = 0;

  constructor(private readonly fixture: OfflineFixture | undefined) {}

  async extract(request: ExtractRequest): Promise<ExtractResult> {
    void request;
    const configured = this.fixture?.extractionsByTurn?.[this.extractionIndex];
    this.extractionIndex += 1;

    if (configured) {
      return {
        extraction: {
          providerFitCriteria: {
            eventType: null,
            needCategory: null,
            location: null,
            budgetAmount: null,
            budgetCurrency: null,
            mustHave: [],
            shouldAvoid: [],
            rankingNotes: 'Fixture did not provide provider fit criteria.',
          },
          ...configured,
        },
        tokenUsage: null,
      };
    }

    return {
      extraction: {
        actionIntent: 'buscar_proveedores',
        informationRequests: [],
        intentConfidence: 0.9,
        eventType: null,
        vendorCategory: null,
        vendorCategories: [],
        activeNeedCategory: null,
        location: null,
        budgetSignal: null,
        guestRange: null,
        preferences: [],
        hardConstraints: [],
        assumptions: [],
        conversationSummary: 'Offline fixture did not provide an extraction result.',
        selectedProviderHints: [],
        pauseRequested: false,
        contactName: null,
        contactEmail: null,
        contactPhone: null,
        providerFitCriteria: {
          eventType: null,
          needCategory: null,
          location: null,
          budgetAmount: null,
          budgetCurrency: null,
          mustHave: [],
          shouldAvoid: [],
          rankingNotes: 'Offline fixture did not provide provider fit criteria.',
        },
        providerQueryIntents: [],
        providerPlanOperations: [],
        providerExplanationRequest: null,
        providerDetailRequest: null,
      },
      tokenUsage: null,
    };
  }

  async composeReply(request: ComposeReplyRequest): Promise<ComposeReplyResult> {
    void request;
    const configured = this.fixture?.repliesByTurn?.[this.replyIndex];
    this.replyIndex += 1;

    return {
      text: configured ?? `offline-reply-${this.replyIndex}`,
      tokenUsage: null,
    };
  }
}

class FixtureProviderGateway implements ProviderGateway {
  private searchTurnIndex = 0;
  private queryIntentTurnIndex = 0;

  constructor(private readonly fixture: OfflineFixture | undefined) {}

  async listCategories(): Promise<MarketplaceCategory[]> {
    return this.fixture?.providerGateway?.listCategories ?? [];
  }

  async getCategoryBySlug(slug: string): Promise<MarketplaceCategory | null> {
    return this.fixture?.providerGateway?.categoriesBySlug?.[slug] ?? null;
  }

  async listLocations(): Promise<MarketplaceLocation[]> {
    return this.fixture?.providerGateway?.listLocations ?? [];
  }

  async searchProviders(): Promise<ProviderGatewaySearchResult> {
    const configured =
      this.fixture?.providerGateway?.searchProvidersByTurn?.[this.searchTurnIndex];
    this.searchTurnIndex += 1;

    if (configured && 'error' in configured) {
      throw new Error(configured.error);
    }

    return configured?.value ?? { providers: [] };
  }

  async searchProvidersByKeyword(
    input: KeywordProviderSearchInput,
  ): Promise<ProviderGatewaySearchResult> {
    void input;
    const configured = this.fixture?.providerGateway?.searchProvidersByKeyword;
    if (configured && 'error' in configured) {
      throw new Error(configured.error);
    }

    return configured?.value ?? { providers: [] };
  }

  async searchProvidersByCategoryLocation(
    input: CategoryLocationProviderSearchInput,
  ): Promise<ProviderGatewaySearchResult> {
    void input;
    const configured = this.fixture?.providerGateway?.searchProvidersByCategoryLocation;
    if (configured && 'error' in configured) {
      throw new Error(configured.error);
    }

    return configured?.value ?? { providers: [] };
  }

  async searchProvidersByQueryIntent(
    input: QueryIntentProviderSearchInput,
  ): Promise<ProviderGatewaySearchResult> {
    const configured =
      this.fixture?.providerGateway?.searchProvidersByQueryIntentByTurn?.[
        this.queryIntentTurnIndex
      ];
    this.queryIntentTurnIndex += 1;
    if (configured && 'error' in configured) {
      throw new Error(configured.error);
    }
    if (configured) {
      return configured.value;
    }

    return this.searchProvidersByCategoryLocation({
      category: input.category,
      location: input.location,
      page: 1,
    });
  }

  async getRelevantProviders(): Promise<ProviderSummary[]> {
    return this.fixture?.providerGateway?.relevantProviders ?? [];
  }

  async getProviderDetail(providerId: number): Promise<ProviderDetail | null> {
    const configured = this.fixture?.providerGateway?.providerDetailsById?.[String(providerId)];
    if (configured && 'error' in configured) {
      throw new Error(configured.error);
    }
    return configured?.value ?? null;
  }

  async getProviderDetailAndTrackView(providerId: number): Promise<ProviderDetail | null> {
    return this.getProviderDetail(providerId);
  }

  async getRelatedProviders(providerId: number): Promise<ProviderSummary[]> {
    return this.fixture?.providerGateway?.relatedProvidersById?.[String(providerId)] ?? [];
  }

  async listProviderReviews(providerId: number): Promise<ProviderReview[]> {
    return this.fixture?.providerGateway?.reviewsById?.[String(providerId)] ?? [];
  }

  async getEventVendorContext(eventId: number): Promise<Record<string, unknown> | null> {
    void eventId;
    return null;
  }

  async listEventFavoriteProviders(args: {
    eventId: number;
    sortBy?: string | null;
    page?: number | null;
    categoryId?: number | null;
  }): Promise<ProviderSummary[]> {
    void args;
    return [];
  }

  async listUserEventsVendorContext(userId: number): Promise<Record<string, unknown>[]> {
    void userId;
    return [];
  }

  async lookupUserEventContext(
    input: UserEventLookupInput,
  ): Promise<UserEventLookupResult | null> {
    return {
      lookup: input,
      user: {
        id: null,
        fullName: null,
        email: input.email ?? null,
        fullPhone: input.phone ?? null,
      },
      events: [],
      counts: {
        ownerEvents: 0,
        guestEvents: 0,
        hostEvents: 0,
        celebratedEvents: 0,
        recentOrders: 0,
      },
    };
  }

  async requestUserLoginCode(): Promise<{ status: 'sent' }> {
    return { status: 'sent' };
  }

  async verifyUserLoginCode(): Promise<{
    status: 'authenticated';
    token: string;
    tokenExpiresAt: string;
  }> {
    return {
      status: 'authenticated',
      token: 'offline-token',
      tokenExpiresAt: new Date(Date.now() + 24 * 60 * 60 * 1000).toISOString(),
    };
  }

  async lookupAuthenticatedUserEvents(args: {
    token: string;
    email: string;
  }): Promise<UserEventLookupResult | null> {
    void args.token;
    return {
      lookup: { email: args.email, phone: null },
      user: {
        id: null,
        fullName: null,
        email: args.email,
        fullPhone: null,
      },
      events: [],
      counts: {
        ownerEvents: 0,
        guestEvents: 0,
        hostEvents: 0,
        celebratedEvents: 0,
        recentOrders: 0,
      },
    };
  }

  async createQuoteRequest(input: QuoteRequestInput): Promise<Record<string, unknown>> {
    return { ok: true, requestId: ulid(), input };
  }

  async addVendorToEventFavorites(
    input: FavoriteRequestInput,
  ): Promise<Record<string, unknown>> {
    return { ok: true, requestId: ulid(), input };
  }

  async createProviderReview(
    input: CreateProviderReviewInput,
  ): Promise<Record<string, unknown>> {
    return { ok: true, requestId: ulid(), input };
  }
}
