import crypto from 'node:crypto';
import { CloudFormationClient, DescribeStacksCommand } from '@aws-sdk/client-cloudformation';
import { DynamoDBClient } from '@aws-sdk/client-dynamodb';
import { DynamoDBDocumentClient, GetCommand } from '@aws-sdk/lib-dynamodb';

import { configureRequiredLocalAwsProfile } from '../../aws/local-profile';
import { assertRequiredLocalAwsIdentity } from '../../aws/local-identity';
import { resolveDevelopmentTarget, type DevelopmentStackOutputs } from '../../aws/development-target';

import { createEmptyPlan, mergePlan, normalizeRawPlan, planIntentValues, planSchema } from '../../core/plan';
import { getConfig } from '../../runtime/config';
import { DynamoPlanStore } from '../../storage/dynamo-plan-store';
import type {
  EvalCase,
  EvalRunConfig,
  EvalTurnResult,
  LambdaTurnResponse,
  OutputOriginEvidence,
} from '../case-schema';
import { lambdaTurnResponseSchema } from '../case-schema';
import {
  redactArtifactText,
  projectSafePlan,
  projectSafeRecord,
  projectSafeTrace,
} from '../../runtime/artifact-redaction';
import { attachEvaluationState, buildCumulativeFixtureEffectSummaries, getEvaluationPlan } from '../evaluation-state';
import { conversationPartitionKey } from '../../storage/conversation-key';
import { parseTurnCoordinationHeaders, runOverlappingTurns } from '../concurrent-turns';
import { hashPrivateOutput, OUTPUT_TRANSFORMATION_VERSION } from '../../audit/output-origin';
import { redactImageUrlForLog } from '../../core/image-attachments';

export async function runLiveLambdaCase(args: {
  currentCase: EvalCase;
  config: EvalRunConfig;
  artifactDir: string;
}): Promise<{
  turns: EvalTurnResult[];
  status: 'passed' | 'failed' | 'errored' | 'skipped';
}> {
  configureRequiredLocalAwsProfile({
    profile: process.env.AWS_PROFILE,
    region: process.env.AWS_REGION,
  });

  assertRequiredLocalAwsIdentity();
  const liveDefaults = await resolveLiveLambdaDefaults(args);
  const functionUrl = liveDefaults.functionUrl;
  if (!functionUrl) {
    return {
      turns: [],
      status: 'skipped',
    };
  }
  const channelApiKey = process.env.DEV_CHANNEL_API_KEY;
  if (!channelApiKey) {
    throw new Error('DEV_CHANNEL_API_KEY is required for live Lambda evaluations.');
  }

  const channel =
    args.currentCase.configOverrides?.liveLambda?.channel ??
    args.config.liveLambda?.channel ??
    process.env.TERMINAL_CHANNEL ??
    'terminal_whatsapp';
  const planStore = new DynamoPlanStore(liveDefaults.plansTableName, {
    region: liveDefaults.region,
  });
  const externalUserId = `${channel}-${args.config.label}-${args.currentCase.id}-${crypto
    .randomUUID()
    .slice(0, 8)}`;
  const seedChannel = args.currentCase.inputs[0]?.channel ?? channel;
  const seedExternalUserId =
    args.currentCase.inputs[0]?.externalUserId ?? externalUserId;
  if (args.currentCase.seedPlan) {
    try {
      await planStore.save({
        plan: mergePlan(
          createEmptyPlan({
            planId: crypto.randomUUID(),
            channel: seedChannel,
            externalUserId: seedExternalUserId,
          }),
          args.currentCase.seedPlan,
        ),
        reason: 'eval-seed',
      });
    } catch (error) {
      throw new Error(
        `Unable to seed the live evaluation plan for ${args.currentCase.id}: ${
          error instanceof Error ? error.message : String(error)
        }`,
      );
    }
  }
  const runTurn = async (turnIndex: number): Promise<EvalTurnResult> => {
    const input = args.currentCase.inputs[turnIndex];
    if (!input) throw new Error('Missing live evaluation turn.');
    const startedAt = Date.now();
    const selectedScenario = input.backendFixture?.scenario ?? args.currentCase.backendFixture?.scenario ?? null;
    const effectiveFixture = selectedScenario ? { scenario: selectedScenario } : null;
    const outboundImage = input.image && 'redacted' in input.image ? undefined : input.image;
    const response = await fetch(functionUrl, {
      method: 'POST',
      headers: {
        'content-type': 'application/json',
        authorization: `Bearer ${channelApiKey}`,
      },
      body: JSON.stringify({
        channel: input.channel ?? channel,
        user_id: input.externalUserId ?? externalUserId,
        text: input.text,
        ...(outboundImage ? { image: outboundImage } : {}),
        message_id: `${args.currentCase.id}-${turnIndex}`,
        received_at: input.receivedAt ?? new Date().toISOString(),
        session_id: input.sessionId ?? args.currentCase.id,
        contact_phone: resolveConfiguredContactPhone(input.contactPhone),
        client_mode: 'cli',
        ...(effectiveFixture ? { backendFixture: effectiveFixture } : {}),
      }),
      signal: AbortSignal.timeout(95_000),
    });

    if (!response.ok) {
      const errorBody = await response.text();
      throw new Error(
        `Live Lambda returned HTTP ${response.status}: ${errorBody.slice(0, 500)}`,
      );
    }

    const raw = await response.json();
    const parsed = lambdaTurnResponseSchema.parse(raw);
    const typedTrace = lambdaTurnResponseSchema.shape.trace.parse(parsed.trace);
    const coordination = parseTurnCoordinationHeaders(response.headers);
    if (coordination) typedTrace.turn_coordination = coordination;
    const typedPerf = parsed.perf === undefined || parsed.perf === null
      ? parsed.perf
      : lambdaTurnResponseSchema.shape.perf.parse(parsed.perf);
    let turnPlan = parsed.plan ? planSchema.parse(parsed.plan) : null;
    if (!turnPlan) {
      try {
        turnPlan = await planStore.getByExternalUser(
          input.channel ?? channel,
          input.externalUserId ?? externalUserId,
        );
      } catch {
        turnPlan = null;
      }
    }
    const evaluationPlan = turnPlan ??
      planSchema.parse(
        normalizeRawPlan({
          ...seedPlanFallback(input.channel ?? channel, input.externalUserId ?? externalUserId),
          ...normalizePlanFromTrace(
            parsed,
            input.channel ?? channel,
            input.externalUserId ?? externalUserId,
          ),
        }),
      );
    const wireOriginalSha256 = parsed.message_original_sha256 === undefined
      ? undefined
      : parsed.message_original_sha256;
    const outputOrigin = independentlyObserveWireOutput(
      parsed.message,
      parsed.output_origin,
      {
        originalSha256: wireOriginalSha256,
        redactionApplied: parsed.message_redaction_applied ?? false,
      },
    );
    const turn: EvalTurnResult = {
      turnIndex,
      input: redactLiveInput(input),
      outputText: parsed.message ?? '',
      deliveredText: parsed.message,
      ...(parsed.delivery ? { delivery: { ...parsed.delivery } } : {}),
      outputOrigin,
      currentNode: parsed.current_node,
      trace: projectSafeTrace(typedTrace) as LambdaTurnResponse['trace'],
      perf:
        typedPerf === undefined || typedPerf === null
          ? typedPerf
          : projectSafeRecord(typedPerf),
      plan: projectSafePlan(evaluationPlan),
      latencyMs: Date.now() - startedAt,
    };
    attachEvaluationState(turn, {
      plan: evaluationPlan,
      input: turn.input,
      outputText: parsed.message ?? '',
      fixtureEffects: [],
    });
    return turn;
  };

  const turns: EvalTurnResult[] = [];
  if (args.currentCase.concurrentFirstTwoTurns) {
    const [first, second] = args.currentCase.inputs;
    if (!first || !second
      || (first.channel ?? channel) !== (second.channel ?? channel)
      || (first.externalUserId ?? externalUserId) !== (second.externalUserId ?? externalUserId)) {
      throw new Error('Concurrent live cases require two turns for the same conversation.');
    }
    const lockClient = DynamoDBDocumentClient.from(new DynamoDBClient({ region: liveDefaults.region }));
    try {
      turns.push(...await runOverlappingTurns({
        first: () => runTurn(0),
        second: () => runTurn(1),
        firstLockIsHeld: async () => {
          const result = await lockClient.send(new GetCommand({
            TableName: liveDefaults.plansTableName,
            Key: { pk: conversationPartitionKey(seedChannel, seedExternalUserId), sk: 'TURN_LOCK' },
            ConsistentRead: true,
            ProjectionExpression: 'lease_until_ms',
          }));
          const expiry: unknown = result.Item?.lease_until_ms;
          return typeof expiry === 'number' && expiry > Date.now();
        },
      }));
    } finally {
      lockClient.destroy();
    }
  }
  for (let index = turns.length; index < args.currentCase.inputs.length; index += 1) {
    turns.push(await runTurn(index));
  }
  for (const turn of turns) {
    attachEvaluationState(turn, {
      plan: getEvaluationPlan(turn),
      input: turn.input,
      outputText: turn.outputText,
      fixtureEffects: buildCumulativeFixtureEffectSummaries(turns, turn.turnIndex),
    });
  }

  return {
    turns,
    status: 'passed',
  };
}

/**
 * Independent wire-output observation for the live target.
 * The declared candidate hash is never trusted: a verified receipt is only
 * preserved when the declared candidate hash equals the independently
 * recomputed wire-delivered hash. Raw model paragraphs stay at the producer
 * (R01 hash-only evidence); this function distinguishes producer-side raw
 * divergence ('model_paragraphs', carried in declared mismatch fields) from
 * wire-side divergence ('candidate_sha256', 'delivered_sha256',
 * 'delivered_text', recomputed here).
 *
 * When the handler applied artifact redaction, `wire.originalSha256` carries
 * the hash of the original delivered text computed before redaction. The
 * redacted public representation must never be hashed as model-provenance
 * proof: declared hashes are verified against the original hash, and the
 * expected redacted-text divergence is recorded without failing the turn.
 * Without wire evidence (or without redaction), the message itself is hashed
 * exactly as before.
 */
export function independentlyObserveWireOutput(
  message: string | null,
  declared: OutputOriginEvidence | undefined,
  wire?: {
    originalSha256?: string | null;
    redactionApplied?: boolean;
  },
): OutputOriginEvidence {
  const redactionApplied = wire?.redactionApplied === true;
  if (redactionApplied && wire?.originalSha256 === undefined) {
    return {
      status: 'mismatch',
      candidateSha256: declared?.candidateSha256 ?? null,
      deliveredSha256: message === null ? null : hashPrivateOutput(message),
      transformationVersion: declared?.transformationVersion ?? null,
      mismatchFields: [...(declared?.mismatchFields ?? []), 'original_sha256'],
    };
  }
  const deliveredSha256 = redactionApplied
    ? (wire?.originalSha256 ?? null)
    : (message === null ? null : hashPrivateOutput(message));
  if (!declared) {
    return { status: 'missing', candidateSha256: null, deliveredSha256, transformationVersion: null, mismatchFields: ['candidate_output_origin'] };
  }
  const mismatchFields = [...declared.mismatchFields];
  const mark = (field: string): void => {
    if (!mismatchFields.includes(field)) mismatchFields.push(field);
  };
  if (declared.deliveredSha256 !== deliveredSha256) {
    mark('delivered_sha256');
  }
  if (declared.status === 'missing' || declared.status === 'generation_failed') {
    return { ...declared, deliveredSha256, mismatchFields };
  }
  if (message === null) {
    if (declared.status === 'verified') mark('delivered_text');
  } else if (declared.status === 'verified') {
    if (declared.candidateSha256 !== deliveredSha256) {
      mark('candidate_sha256');
    }
    if (declared.transformationVersion !== OUTPUT_TRANSFORMATION_VERSION) {
      mark('transformation_version');
    }
    if (declared.mismatchFields.length > 0) {
      mark('declared_mismatch');
    }
  } else if (declared.transformationVersion !== OUTPUT_TRANSFORMATION_VERSION && declared.transformationVersion !== null) {
    mark('transformation_version');
  }
  return { ...declared, status: mismatchFields.length > 0 ? 'mismatch' : declared.status, deliveredSha256, mismatchFields };
}

function redactLiveInput(input: EvalTurnResult['input']): EvalTurnResult['input'] {
  return {
    ...input,
    text: redactArtifactText(input.text),
    // Image bytes never reach evaluation reports: only MIME/size-bucket
    // facts are retained. URL inputs keep redacted shape evidence only.
    ...(input.image && 'data' in input.image
      ? {
        image: {
          redacted: true as const,
          mime_type: input.image.mime_type,
          byte_length: Buffer.byteLength(input.image.data, 'utf8'),
        },
      }
      : {}),
    ...(input.image && 'url' in input.image
      ? {
        image: {
          redacted: true as const,
          url_host_redacted: redactImageUrlForLog(input.image.url),
          url_bytes: Buffer.byteLength(input.image.url, 'utf8'),
        },
      }
      : {}),
    ...(input.externalUserId
      ? { externalUserId: input.externalUserId }
      : {}),
    ...(input.contactPhone !== undefined ? { contactPhone: null } : {}),
  };
}

function resolveConfiguredContactPhone(value: string | null | undefined): string | null {
  if (!value) {
    return null;
  }
  if (!value.startsWith('$')) {
    return value;
  }
  const variableName = value.slice(1);
  const configured = process.env[variableName];
  if (!configured) {
    throw new Error(`${variableName} is required for this live phone-auth case.`);
  }
  return configured;
}

async function resolveLiveLambdaDefaults(args: {
  currentCase: EvalCase;
  config: EvalRunConfig;
}): Promise<{
  functionUrl: string | null;
  plansTableName: string;
  region: string;
}> {
  const appConfig = getConfig();
  const region = process.env.AWS_REGION ?? appConfig.aws.region;
  const stackName = process.env.DEV_STACK_NAME ?? 'recap-agent-runtime-dev';
  const directFunctionUrl =
    args.currentCase.configOverrides?.liveLambda?.functionUrl ??
    args.config.liveLambda?.functionUrl ??
    process.env.DEV_AGENT_FUNCTION_URL ??
    null;
  const directPlansTableName = process.env.DEV_PLANS_TABLE_NAME ?? null;
  const outputs = await getStackOutputs(stackName, region);
  const { functionUrl, plansTableName } = resolveDevelopmentTarget(outputs, {
    functionUrl: directFunctionUrl, plansTableName: directPlansTableName,
  });

  return {
    functionUrl,
    plansTableName,
    region,
  };
}

async function getStackOutputs(stackName: string, region: string) {
  const client = new CloudFormationClient({ region });
  const response = await client.send(
    new DescribeStacksCommand({
      StackName: stackName,
    }),
  );
  const outputs = response.Stacks?.[0]?.Outputs ?? [];
  return Object.fromEntries(
    outputs
      .filter((item) => item.OutputKey && item.OutputValue)
      .map((item) => [item.OutputKey as string, item.OutputValue as string]),
  ) as DevelopmentStackOutputs;
}

function seedPlanFallback(channel: string, externalUserId: string) {
  return {
    plan_id: 'unknown',
    channel,
    external_user_id: externalUserId,
    conversation_id: null,
    lifecycle_state: 'active',
    contact_name: null,
    contact_email: null,
    current_node: 'contacto_inicial',
    intent: null,
    intent_confidence: null,
    event_type: null,
    vendor_category: null,
    active_need_category: null,
    location: null,
    budget_signal: null,
    guest_range: null,
    preferences: [],
    hard_constraints: [],
    missing_fields: [],
    provider_needs: [],
    recommended_provider_ids: [],
    recommended_providers: [],
    selected_provider_ids: [],
    selected_provider_hints: [],
    assumptions: [],
    conversation_summary: '',
    last_user_goal: null,
    open_questions: [],
    updated_at: new Date(0).toISOString(),
  };
}

function normalizePlanFromTrace(
  response: LambdaTurnResponse,
  channel: string,
  externalUserId: string,
) {
  const normalizedIntent = planIntentValues.includes(
    response.trace.intent as (typeof planIntentValues)[number],
  )
    ? (response.trace.intent as (typeof planIntentValues)[number])
    : null;

  return {
    plan_id: response.plan_id,
    channel,
    external_user_id: externalUserId,
    conversation_id: response.conversation_id,
    current_node: response.current_node,
    intent: normalizedIntent,
    missing_fields: response.trace.missing_fields,
    recommended_providers: response.trace.provider_results,
    recommended_provider_ids: response.trace.provider_results.map((provider) => provider.id),
    updated_at: new Date().toISOString(),
  };
}
