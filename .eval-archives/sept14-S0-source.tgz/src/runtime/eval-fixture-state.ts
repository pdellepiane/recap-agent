import { DynamoDBClient, type DynamoDBClientConfig } from '@aws-sdk/client-dynamodb';
import { DynamoDBDocumentClient, GetCommand, PutCommand, QueryCommand } from '@aws-sdk/lib-dynamodb';

export const EVAL_FIXTURE_TTL_SECONDS = 7 * 24 * 60 * 60;

export type FixtureEffectOperation =
  | 'otp.request'
  | 'otp.verify'
  | 'rsvp.write'
  | 'handoff.write'
  | 'provider.quote.write'
  | 'provider.favorite.write'
  | 'provider.review.write';

export type FixtureEffectReceipt = {
  readonly runId: string;
  readonly caseId: string;
  readonly scenario: string;
  readonly operation: FixtureEffectOperation;
  readonly attempt: number;
  readonly args: Record<string, unknown>;
  readonly resultStatus: string;
  readonly syntheticId: string;
  readonly createdAt: string;
  readonly ttl: number;
  readonly replayed: boolean;
};

export type FixtureStateKey = {
  readonly pk: string;
  readonly sk: string;
};

function requireIdentity(value: string, field: 'runId' | 'caseId' | 'scenario'): string {
  const trimmed = value.trim();
  if (trimmed.length === 0 || trimmed.length > 128) {
    throw new Error(`Fixture ${field} must be 1-128 chars.`);
  }
  return trimmed;
}

export function buildFixtureStateKey(runId: string, caseId: string, operation: FixtureEffectOperation): FixtureStateKey {
  const run = requireIdentity(runId, 'runId');
  const kase = requireIdentity(caseId, 'caseId');
  return {
    pk: `EVAL_FIXTURE#${run}#${kase}`,
    sk: `OP#${operation}`,
  };
}

export function syntheticEffectId(scenario: string, operation: FixtureEffectOperation, runId: string, attempt: number): string {
  const safeScenario = scenario.trim().length > 0 ? scenario.trim() : 'unknown';
  const safeRun = runId.trim().length > 0 ? runId.trim().slice(0, 8) : 'local';
  return `fixture-${operation}-${safeScenario}-${safeRun}-${attempt}`;
}

export function ttlForFixtureState(nowMs: number = Date.now()): number {
  return Math.floor(nowMs / 1000) + EVAL_FIXTURE_TTL_SECONDS;
}

export function assertFixtureAllowed(environment: string): void {
  if (environment === 'production') {
    throw new Error('Backend fixtures are available only in development.');
  }
}

export type FixtureMessageDirection = 'inbound' | 'outbound';

/**
 * Delivery truth for a logged fixture message. Only 'received' (an inbound
 * turn that actually arrived) and 'sent' (an outbound receipt backed by
 * actual delivered model text) may enter merged history. 'unverified'
 * outbound claims, 'suppressed' turns and 'failed' sends are retained for
 * audit but never surface as conversation context: fixtures must not
 * pretend suppressed/failed turns were sent.
 */
export type FixtureMessageDelivery = 'received' | 'sent' | 'unverified' | 'suppressed' | 'failed';

export type FixtureLoggedMessage = {
  readonly runId: string;
  readonly caseId: string;
  readonly scenario: string;
  /** Display phone as logged. */
  readonly phone: string;
  /** All lookup forms derived at log time (national, ext:national, concatenated, digits). */
  readonly phoneKeys: readonly string[];
  readonly direction: FixtureMessageDirection;
  /** Text only. Never image bytes, captions-as-pixels, or descriptions. */
  readonly body: string;
  readonly whatsappMessageId: string | null;
  readonly sentAt: string | null;
  readonly delivery: FixtureMessageDelivery;
  readonly seq: number;
  readonly recordedAt: string;
};

export interface EvalFixtureStateStore {
  record(args: {
    runId: string;
    caseId: string;
    scenario: string;
    operation: FixtureEffectOperation;
    args: Record<string, unknown>;
    resultStatus: string;
    replayed?: boolean;
  }): Promise<FixtureEffectReceipt>;
  count(runId: string, caseId: string, operation: FixtureEffectOperation): Promise<number>;
  list(runId: string, caseId: string, operation?: FixtureEffectOperation): Promise<FixtureEffectReceipt[]>;
  lastReceipt(runId: string, caseId: string, operation: FixtureEffectOperation): Promise<FixtureEffectReceipt | null>;
  recordMessage(args: {
    runId: string;
    caseId: string;
    scenario: string;
    phone: string;
    phoneKeys: readonly string[];
    direction: FixtureMessageDirection;
    body: string;
    whatsappMessageId?: string | null;
    sentAt?: string | null;
    delivery: FixtureMessageDelivery;
  }): Promise<FixtureLoggedMessage>;
  listMessages(runId: string, caseId: string, scenario: string): Promise<FixtureLoggedMessage[]>;
  resetForTesting(): Promise<void>;
}

function storeKey(runId: string, caseId: string, operation: FixtureEffectOperation): string {
  return `${runId}\u0000${caseId}\u0000${operation}`;
}

function messageStoreKey(runId: string, caseId: string, scenario: string): string {
  return `${runId}\u0000${caseId}\u0000MSG\u0000${scenario}`;
}

function messagePartitionKey(runId: string, caseId: string): string {
  return buildFixtureStateKey(runId, caseId, 'otp.request').pk;
}

export class InMemoryEvalFixtureStateStore implements EvalFixtureStateStore {
  private readonly receipts = new Map<string, FixtureEffectReceipt[]>();
  private readonly messages = new Map<string, FixtureLoggedMessage[]>();

  async record(args: {
    runId: string;
    caseId: string;
    scenario: string;
    operation: FixtureEffectOperation;
    args: Record<string, unknown>;
    resultStatus: string;
    replayed?: boolean;
  }): Promise<FixtureEffectReceipt> {
    const runId = requireIdentity(args.runId, 'runId');
    const caseId = requireIdentity(args.caseId, 'caseId');
    const scenario = requireIdentity(args.scenario, 'scenario');
    const key = storeKey(runId, caseId, args.operation);
    const existing = this.receipts.get(key) ?? [];
    const attempt = existing.length + 1;
    const receipt: FixtureEffectReceipt = {
      runId,
      caseId,
      scenario,
      operation: args.operation,
      attempt,
      args: { ...args.args },
      resultStatus: args.resultStatus,
      syntheticId: syntheticEffectId(scenario, args.operation, runId, attempt),
      createdAt: new Date().toISOString(),
      ttl: ttlForFixtureState(),
      replayed: args.replayed ?? false,
    };
    existing.push(receipt);
    this.receipts.set(key, existing);
    return receipt;
  }

  async count(runId: string, caseId: string, operation: FixtureEffectOperation): Promise<number> {
    return (this.receipts.get(storeKey(runId, caseId, operation)) ?? []).length;
  }

  async list(runId: string, caseId: string, operation?: FixtureEffectOperation): Promise<FixtureEffectReceipt[]> {
    if (operation) {
      return [...(this.receipts.get(storeKey(runId, caseId, operation)) ?? [])];
    }
    const out: FixtureEffectReceipt[] = [];
    for (const [key, values] of this.receipts) {
      if (key.startsWith(`${runId}\u0000${caseId}\u0000`)) {
        out.push(...values);
      }
    }
    return out.sort((left, right) => left.createdAt.localeCompare(right.createdAt));
  }

  async lastReceipt(runId: string, caseId: string, operation: FixtureEffectOperation): Promise<FixtureEffectReceipt | null> {
    const values = this.receipts.get(storeKey(runId, caseId, operation)) ?? [];
    return values.length > 0 ? values[values.length - 1] : null;
  }

  async recordMessage(args: {
    runId: string;
    caseId: string;
    scenario: string;
    phone: string;
    phoneKeys: readonly string[];
    direction: FixtureMessageDirection;
    body: string;
    whatsappMessageId?: string | null;
    sentAt?: string | null;
    delivery: FixtureMessageDelivery;
  }): Promise<FixtureLoggedMessage> {
    const runId = requireIdentity(args.runId, 'runId');
    const caseId = requireIdentity(args.caseId, 'caseId');
    const scenario = requireIdentity(args.scenario, 'scenario');
    const key = messageStoreKey(runId, caseId, scenario);
    const existing = this.messages.get(key) ?? [];
    const seq = existing.length + 1;
    const record: FixtureLoggedMessage = {
      runId,
      caseId,
      scenario,
      phone: args.phone,
      phoneKeys: [...args.phoneKeys],
      direction: args.direction,
      body: args.body,
      whatsappMessageId: args.whatsappMessageId ?? null,
      sentAt: args.sentAt ?? null,
      delivery: args.delivery,
      seq,
      recordedAt: new Date().toISOString(),
    };
    existing.push(record);
    this.messages.set(key, existing);
    return record;
  }

  async listMessages(runId: string, caseId: string, scenario: string): Promise<FixtureLoggedMessage[]> {
    return [...(this.messages.get(messageStoreKey(runId, caseId, scenario)) ?? [])];
  }

  async resetForTesting(): Promise<void> {
    this.receipts.clear();
    this.messages.clear();
  }
}

export class DynamoEvalFixtureStateStore implements EvalFixtureStateStore {
  private readonly documentClient: DynamoDBDocumentClient;

  constructor(
    private readonly tableName: string,
    config?: DynamoDBClientConfig,
  ) {
    const client = new DynamoDBClient(config ?? {});
    this.documentClient = DynamoDBDocumentClient.from(client, {
      marshallOptions: { removeUndefinedValues: true },
    });
  }

  async record(args: {
    runId: string;
    caseId: string;
    scenario: string;
    operation: FixtureEffectOperation;
    args: Record<string, unknown>;
    resultStatus: string;
    replayed?: boolean;
  }): Promise<FixtureEffectReceipt> {
    const runId = requireIdentity(args.runId, 'runId');
    const caseId = requireIdentity(args.caseId, 'caseId');
    const scenario = requireIdentity(args.scenario, 'scenario');
    const key = buildFixtureStateKey(runId, caseId, args.operation);
    const existing = await this.count(runId, caseId, args.operation);
    const attempt = existing + 1;
    const receipt: FixtureEffectReceipt = {
      runId,
      caseId,
      scenario,
      operation: args.operation,
      attempt,
      args: { ...args.args },
      resultStatus: args.resultStatus,
      syntheticId: syntheticEffectId(scenario, args.operation, runId, attempt),
      createdAt: new Date().toISOString(),
      ttl: ttlForFixtureState(),
      replayed: args.replayed ?? false,
    };
    await this.documentClient.send(
      new PutCommand({
        TableName: this.tableName,
        Item: {
          pk: key.pk,
          sk: `${key.sk}#${attempt}`,
          ...receipt,
        },
      }),
    );
    return receipt;
  }

  async count(runId: string, caseId: string, operation: FixtureEffectOperation): Promise<number> {
    const receipts = await this.list(runId, caseId, operation);
    return receipts.length;
  }

  async list(runId: string, caseId: string, operation?: FixtureEffectOperation): Promise<FixtureEffectReceipt[]> {
    const key = buildFixtureStateKey(runId, caseId, operation ?? 'otp.request');
    const response = await this.documentClient.send(
      new QueryCommand({
        TableName: this.tableName,
        KeyConditionExpression: 'pk = :pk' + (operation ? ' AND begins_with(sk, :sk)' : ''),
        ExpressionAttributeValues: operation
          ? { ':pk': key.pk, ':sk': key.sk }
          : { ':pk': key.pk },
      }),
    );
    const items = (response.Items ?? []) as Array<FixtureEffectReceipt & { pk: string; sk: string }>;
    return items
      .map((item) => ({
        runId: item.runId,
        caseId: item.caseId,
        scenario: item.scenario,
        operation: item.operation,
        attempt: item.attempt,
        args: item.args,
        resultStatus: item.resultStatus,
        syntheticId: item.syntheticId,
        createdAt: item.createdAt,
        ttl: item.ttl,
        replayed: item.replayed,
      }))
      .sort((left, right) => left.attempt - right.attempt);
  }

  async lastReceipt(runId: string, caseId: string, operation: FixtureEffectOperation): Promise<FixtureEffectReceipt | null> {
    const receipts = await this.list(runId, caseId, operation);
    return receipts.length > 0 ? receipts[receipts.length - 1] : null;
  }

  private messageSkPrefix(scenario: string): string {
    return `MSG#${scenario}#`;
  }

  async recordMessage(args: {
    runId: string;
    caseId: string;
    scenario: string;
    phone: string;
    phoneKeys: readonly string[];
    direction: FixtureMessageDirection;
    body: string;
    whatsappMessageId?: string | null;
    sentAt?: string | null;
    delivery: FixtureMessageDelivery;
  }): Promise<FixtureLoggedMessage> {
    const runId = requireIdentity(args.runId, 'runId');
    const caseId = requireIdentity(args.caseId, 'caseId');
    const scenario = requireIdentity(args.scenario, 'scenario');
    const existing = await this.listMessages(runId, caseId, scenario);
    const seq = existing.length + 1;
    const record: FixtureLoggedMessage = {
      runId,
      caseId,
      scenario,
      phone: args.phone,
      phoneKeys: [...args.phoneKeys],
      direction: args.direction,
      body: args.body,
      whatsappMessageId: args.whatsappMessageId ?? null,
      sentAt: args.sentAt ?? null,
      delivery: args.delivery,
      seq,
      recordedAt: new Date().toISOString(),
    };
    await this.documentClient.send(
      new PutCommand({
        TableName: this.tableName,
        Item: {
          pk: messagePartitionKey(runId, caseId),
          sk: `${this.messageSkPrefix(scenario)}${String(seq).padStart(10, '0')}`,
          ...record,
          phoneKeys: [...record.phoneKeys],
        },
      }),
    );
    return record;
  }

  async listMessages(runId: string, caseId: string, scenario: string): Promise<FixtureLoggedMessage[]> {
    const response = await this.documentClient.send(
      new QueryCommand({
        TableName: this.tableName,
        KeyConditionExpression: 'pk = :pk AND begins_with(sk, :sk)',
        ExpressionAttributeValues: { ':pk': messagePartitionKey(runId, caseId), ':sk': this.messageSkPrefix(scenario) },
      }),
    );
    const items = (response.Items ?? []) as Array<{
      phoneKeys?: unknown;
    } & Omit<FixtureLoggedMessage, 'phoneKeys'>>;
    return items
      .map((item) => ({
        runId: item.runId,
        caseId: item.caseId,
        scenario: item.scenario,
        phone: item.phone,
        phoneKeys: Array.isArray(item.phoneKeys)
          ? (item.phoneKeys as unknown[]).filter((entry): entry is string => typeof entry === 'string')
          : [],
        direction: item.direction,
        body: item.body,
        whatsappMessageId: item.whatsappMessageId,
        sentAt: item.sentAt,
        delivery: item.delivery,
        seq: item.seq,
        recordedAt: item.recordedAt,
      }))
      .sort((left, right) => left.seq - right.seq);
  }

  async resetForTesting(): Promise<void> {
    throw new Error('DynamoEvalFixtureStateStore does not support resetForTesting.');
  }

  async readReceipt(runId: string, caseId: string, operation: FixtureEffectOperation, attempt: number): Promise<FixtureEffectReceipt | null> {
    const key = buildFixtureStateKey(runId, caseId, operation);
    const response = await this.documentClient.send(
      new GetCommand({
        TableName: this.tableName,
        Key: { pk: key.pk, sk: `${key.sk}#${attempt}` },
        ConsistentRead: true,
      }),
    );
    if (!response.Item) {
      return null;
    }
    const item = response.Item as FixtureEffectReceipt;
    return {
      runId: item.runId,
      caseId: item.caseId,
      scenario: item.scenario,
      operation: item.operation,
      attempt: item.attempt,
      args: item.args,
      resultStatus: item.resultStatus,
      syntheticId: item.syntheticId,
      createdAt: item.createdAt,
      ttl: item.ttl,
      replayed: item.replayed,
    };
  }
}

export function createEvalFixtureStateStoreFromEnv(): EvalFixtureStateStore | null {
  const tableName = process.env.EVAL_FIXTURE_TABLE_NAME?.trim();
  if (!tableName) {
    return null;
  }
  const region = process.env.AWS_REGION?.trim() || 'us-east-1';
  return new DynamoEvalFixtureStateStore(tableName, { region });
}
