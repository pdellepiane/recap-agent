export type CapabilityBoundaryMessageKey =
  | 'unsupported_human_once'
  | 'unsupported_human_failed'
  | 'unsupported_human_repeat'
  | 'unsupported_operation_once'
  | 'unsupported_operation_failed'
  | 'status_or_document'
  | 'status_or_proof_review'
  | 'type_missing'
  | 'image_limitation'
  | 'proof_limitation';

export type CapabilityBoundaryMessages = Readonly<
  Record<CapabilityBoundaryMessageKey, string>
>;

/** Parses the key/value prompt resource without introducing free-text routing. */
export function parseCapabilityBoundaryMessages(
  content: string,
): CapabilityBoundaryMessages {
  const entries = new Map<CapabilityBoundaryMessageKey, string>();
  for (const line of content.split(/\r?\n/u)) {
    const separator = line.indexOf('=');
    if (separator <= 0) continue;
    const key = line.slice(0, separator).trim() as CapabilityBoundaryMessageKey;
    const value = line.slice(separator + 1).trim();
    if (
      value.length > 0 &&
      (key === 'unsupported_human_once' ||
        key === 'unsupported_human_failed' ||
        key === 'unsupported_human_repeat' ||
        key === 'unsupported_operation_once' ||
        key === 'unsupported_operation_failed' ||
        key === 'status_or_document' ||
        key === 'status_or_proof_review' ||
        key === 'type_missing' ||
        key === 'image_limitation' ||
        key === 'proof_limitation')
    ) {
      entries.set(key, value);
    }
  }
  if (entries.size !== 10) {
    throw new Error('Capability boundary prompt is incomplete.');
  }
  return {
    unsupported_human_once: entries.get('unsupported_human_once') as string,
    unsupported_human_failed: entries.get('unsupported_human_failed') as string,
    unsupported_human_repeat: entries.get('unsupported_human_repeat') as string,
    unsupported_operation_once: entries.get('unsupported_operation_once') as string,
    unsupported_operation_failed: entries.get('unsupported_operation_failed') as string,
    status_or_document: entries.get('status_or_document') as string,
    status_or_proof_review: entries.get('status_or_proof_review') as string,
    type_missing: entries.get('type_missing') as string,
    image_limitation: entries.get('image_limitation') as string,
    proof_limitation: entries.get('proof_limitation') as string,
  };
}
