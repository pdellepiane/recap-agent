import type { PersistedPlan } from '../core/plan';
import type { ProviderCategory } from '../core/provider-category';
import type { ProviderDetail, ProviderSummary } from '../core/provider';
import type { ProviderFitCriteria } from './provider-fit';

export type ProviderGatewaySearchResult = {
  providers: ProviderSummary[];
};

export type ProviderSearchMode = 'api' | 'vector' | 'hybrid';

export type KeywordProviderSearchInput = {
  keyword: string;
  page?: number | null;
};

export type CategoryLocationProviderSearchInput = {
  category: ProviderCategory;
  location?: string | null;
  page?: number | null;
};

export type QueryIntentProviderSearchInput = {
  category: ProviderCategory;
  queryStrings: string[];
  location: string | null;
  fitCriteria: ProviderFitCriteria;
};

export type MarketplaceCategory = {
  id: number | null;
  name: string;
  slug: string | null;
  color: string | null;
  eventTypes: string[];
  raw: Record<string, unknown>;
};

export type MarketplaceLocation = {
  cityId: number | null;
  countryId: number | null;
  city: string | null;
  country: string | null;
  raw: Record<string, unknown>;
};

export type ProviderReview = {
  id: number | null;
  name: string | null;
  rating: number | null;
  comment: string | null;
  createdAt: string | null;
  raw: Record<string, unknown>;
};

export type QuoteRequestInput = {
  providerId: number;
  userId?: number | null;
  name: string;
  email: string;
  phone: string;
  phoneExtension: string;
  eventDate: string;
  guestsRange: string;
  description: string;
};

export type FavoriteRequestInput = {
  providerId: number;
  userId: number;
  eventId: number;
};

export type CreateProviderReviewInput = {
  providerId: number;
  userId: number;
  name: string;
  rating: number;
  comment?: string | null;
};

export type UserEventLookupInput =
  | {
      email: string;
      phone?: null;
    }
  | {
      email?: null;
      phone: string;
    };

export type UserEventRelation =
  | 'owner'
  | 'guest'
  | 'host'
  | 'celebrated'
  | 'order';

export type UserEventGuestStatus = {
  hasResponded: boolean | null;
  willAttend: boolean | null;
  hasCouple: boolean | null;
  responseDate: string | null;
};

export type UserEventOrderSummary = {
  id: number | null;
  incrementId: string | null;
  giftType: string | null;
  grandTotal: number | null;
  paymentStatus: string | null;
  shippingStatus: string | null;
  createdAt: string | null;
  paymentMethod: string | null;
};

export type UserEventSummary = {
  relation: UserEventRelation;
  guestId: number | null;
  eventId: number | null;
  slug: string | null;
  url: string | null;
  name: string | null;
  place: string | null;
  type: string | null;
  datetime: string | null;
  stage: string | null;
  isVisible: boolean | null;
  isPublic: boolean | null;
  currency: string | null;
  country: string | null;
  guestStatus: UserEventGuestStatus | null;
  hostType: string | null;
  hostPermission: string | null;
  hostStatus: string | null;
  celebratedType: string | null;
  amountCollected: number | null;
  amountTransferred: number | null;
  transactionsCount: number | null;
  invitedGuestCount: number | null;
  confirmedGuestCount: number | null;
  orders: UserEventOrderSummary[];
  detail?: {
    withTime: boolean;
    timezone: string | null;
    city: string | null;
    celebrateds: Array<{
      name: string;
      type: string | null;
    }>;
    moments: Array<{
      label: string;
      description: string | null;
      datetime: string | null;
      withTime: boolean;
      locationDescription: string | null;
      locationReference: string | null;
      locationUrl: string | null;
      locationCoords: string | null;
      position: number;
    }>;
    dresscode: {
      type: string | null;
      description: string | null;
    } | null;
    commonAsked: Array<{
      question: string;
      answer: string;
    }>;
    contactInfo: Array<{
      label: string;
      value: string;
    }>;
  };
};

export type UserEventLookupResult = {
  lookup: UserEventLookupInput;
  user: {
    id: number | null;
    fullName: string | null;
    email: string | null;
    fullPhone: string | null;
  } | null;
  events: UserEventSummary[];
  counts: {
    ownerEvents: number;
    guestEvents: number;
    hostEvents: number;
    celebratedEvents: number;
    recentOrders: number;
  };
};

export type UserLoginCodeRequestResult =
  | {
      status: 'sent';
      httpStatus?: number;
      requestId?: string | null;
    }
  | {
      status: 'email_not_found' | 'rate_limited' | 'unavailable' | 'failed';
      error: string;
      httpStatus?: number;
      requestId?: string | null;
    };

export type UserLoginCodeVerificationResult =
  | {
      status: 'authenticated';
      token: string;
      tokenExpiresAt: string;
      httpStatus?: number;
      requestId?: string | null;
    }
  | {
      status:
        | 'invalid_code'
        | 'email_not_verified'
        | 'validation_failed'
        | 'rate_limited'
        | 'unavailable'
        | 'failed';
      error: string;
      httpStatus?: number;
      requestId?: string | null;
    };

export interface ProviderGateway {
  listCategories(): Promise<MarketplaceCategory[]>;
  getCategoryBySlug(slug: string): Promise<MarketplaceCategory | null>;
  listLocations(): Promise<MarketplaceLocation[]>;
  searchProviders(plan: PersistedPlan): Promise<ProviderGatewaySearchResult>;
  searchProvidersByKeyword(
    input: KeywordProviderSearchInput,
  ): Promise<ProviderGatewaySearchResult>;
  searchProvidersByCategoryLocation(
    input: CategoryLocationProviderSearchInput,
  ): Promise<ProviderGatewaySearchResult>;
  searchProvidersByQueryIntent(
    input: QueryIntentProviderSearchInput,
  ): Promise<ProviderGatewaySearchResult>;
  getRelevantProviders(): Promise<ProviderSummary[]>;
  getProviderDetail(providerId: number): Promise<ProviderDetail | null>;
  getProviderDetailAndTrackView(providerId: number): Promise<ProviderDetail | null>;
  getRelatedProviders(providerId: number): Promise<ProviderSummary[]>;
  listProviderReviews(providerId: number): Promise<ProviderReview[]>;
  getEventVendorContext(eventId: number): Promise<Record<string, unknown> | null>;
  listEventFavoriteProviders(args: {
    eventId: number;
    sortBy?: string | null;
    page?: number | null;
    categoryId?: number | null;
  }): Promise<ProviderSummary[]>;
  listUserEventsVendorContext(userId: number): Promise<Record<string, unknown>[]>;
  lookupUserEventContext(input: UserEventLookupInput): Promise<UserEventLookupResult | null>;
  requestUserLoginCode(email: string): Promise<UserLoginCodeRequestResult>;
  verifyUserLoginCode(
    email: string,
    code: string,
  ): Promise<UserLoginCodeVerificationResult>;
  lookupAuthenticatedUserEvents(args: {
    token: string;
    email: string;
  }): Promise<UserEventLookupResult | null>;
  createQuoteRequest(input: QuoteRequestInput): Promise<Record<string, unknown>>;
  addVendorToEventFavorites(input: FavoriteRequestInput): Promise<Record<string, unknown>>;
  createProviderReview(input: CreateProviderReviewInput): Promise<Record<string, unknown>>;
}
